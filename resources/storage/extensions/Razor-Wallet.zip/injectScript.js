var tf = Object.defineProperty;
var nf = (t, e, n) => e in t ? tf(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n;
var Gn = (t, e, n) => (nf(t, typeof e != "symbol" ? e + "" : e, n), n), Ji = (t, e, n) => {
  if (!e.has(t))
    throw TypeError("Cannot " + n);
};
var te = (t, e, n) => (Ji(t, e, "read from private field"), n ? n.call(t) : e.get(t)), he = (t, e, n) => {
  if (e.has(t))
    throw TypeError("Cannot add the same private member more than once");
  e instanceof WeakSet ? e.add(t) : e.set(t, n);
}, lt = (t, e, n, r) => (Ji(t, e, "write to private field"), r ? r.call(t, n) : e.set(t, n), n);
var kt = (t, e, n) => (Ji(t, e, "access private method"), n);
var rf = function(t, e, n, r, i) {
  if (r === "m")
    throw new TypeError("Private method is not writable");
  if (r === "a" && !i)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof e == "function" ? t !== e || !i : !e.has(t))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return r === "a" ? i.call(t, n) : i ? i.value = n : e.set(t, n), n;
}, sf = function(t, e, n, r) {
  if (n === "a" && !r)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof e == "function" ? t !== e || !r : !e.has(t))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return n === "m" ? r : n === "a" ? r.call(t) : r ? r.value : e.get(t);
}, Ur;
function xo(t) {
  const e = ({ register: n }) => n(t);
  try {
    window.dispatchEvent(new of(e));
  } catch (n) {
    console.error(`wallet-standard:register-wallet event could not be dispatched
`, n);
  }
  try {
    window.addEventListener("wallet-standard:app-ready", ({ detail: n }) => e(n));
  } catch (n) {
    console.error(`wallet-standard:app-ready event listener could not be added
`, n);
  }
}
class of extends Event {
  constructor(e) {
    super("wallet-standard:register-wallet", {
      bubbles: !1,
      cancelable: !1,
      composed: !1
    }), Ur.set(this, void 0), rf(this, Ur, e, "f");
  }
  get detail() {
    return sf(this, Ur, "f");
  }
  get type() {
    return "wallet-standard:register-wallet";
  }
  /** @deprecated */
  preventDefault() {
    throw new Error("preventDefault cannot be called");
  }
  /** @deprecated */
  stopImmediatePropagation() {
    throw new Error("stopImmediatePropagation cannot be called");
  }
  /** @deprecated */
  stopPropagation() {
    throw new Error("stopPropagation cannot be called");
  }
}
Ur = /* @__PURE__ */ new WeakMap();
var En = function(t, e, n, r, i) {
  if (r === "m")
    throw new TypeError("Private method is not writable");
  if (r === "a" && !i)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof e == "function" ? t !== e || !i : !e.has(t))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return r === "a" ? i.call(t, n) : i ? i.value = n : e.set(t, n), n;
}, vn = function(t, e, n, r) {
  if (n === "a" && !r)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof e == "function" ? t !== e || !r : !e.has(t))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return n === "m" ? r : n === "a" ? r.call(t) : r ? r.value : e.get(t);
}, Cr, Pr, Or, Rr, kr, Nr;
class Ii {
  /**
   * Create and freeze a read-only account.
   *
   * @param account Account to copy properties from.
   */
  constructor(e) {
    Cr.set(this, void 0), Pr.set(this, void 0), Or.set(this, void 0), Rr.set(this, void 0), kr.set(this, void 0), Nr.set(this, void 0), new.target === Ii && Object.freeze(this), En(this, Cr, e.address, "f"), En(this, Pr, e.publicKey.slice(), "f"), En(this, Or, e.chains.slice(), "f"), En(this, Rr, e.features.slice(), "f"), En(this, kr, e.label, "f"), En(this, Nr, e.icon, "f");
  }
  /** Implementation of {@link "@wallet-standard/base".WalletAccount.address | WalletAccount::address} */
  get address() {
    return vn(this, Cr, "f");
  }
  /** Implementation of {@link "@wallet-standard/base".WalletAccount.publicKey | WalletAccount::publicKey} */
  get publicKey() {
    return vn(this, Pr, "f").slice();
  }
  /** Implementation of {@link "@wallet-standard/base".WalletAccount.chains | WalletAccount::chains} */
  get chains() {
    return vn(this, Or, "f").slice();
  }
  /** Implementation of {@link "@wallet-standard/base".WalletAccount.features | WalletAccount::features} */
  get features() {
    return vn(this, Rr, "f").slice();
  }
  /** Implementation of {@link "@wallet-standard/base".WalletAccount.label | WalletAccount::label} */
  get label() {
    return vn(this, kr, "f");
  }
  /** Implementation of {@link "@wallet-standard/base".WalletAccount.icon | WalletAccount::icon} */
  get icon() {
    return vn(this, Nr, "f");
  }
}
Cr = /* @__PURE__ */ new WeakMap(), Pr = /* @__PURE__ */ new WeakMap(), Or = /* @__PURE__ */ new WeakMap(), Rr = /* @__PURE__ */ new WeakMap(), kr = /* @__PURE__ */ new WeakMap(), Nr = /* @__PURE__ */ new WeakMap();
let Tr;
const af = new Uint8Array(16);
function cf() {
  if (!Tr && (Tr = typeof crypto < "u" && crypto.getRandomValues && crypto.getRandomValues.bind(crypto), !Tr))
    throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
  return Tr(af);
}
const We = [];
for (let t = 0; t < 256; ++t)
  We.push((t + 256).toString(16).slice(1));
function uf(t, e = 0) {
  return We[t[e + 0]] + We[t[e + 1]] + We[t[e + 2]] + We[t[e + 3]] + "-" + We[t[e + 4]] + We[t[e + 5]] + "-" + We[t[e + 6]] + We[t[e + 7]] + "-" + We[t[e + 8]] + We[t[e + 9]] + "-" + We[t[e + 10]] + We[t[e + 11]] + We[t[e + 12]] + We[t[e + 13]] + We[t[e + 14]] + We[t[e + 15]];
}
const ff = typeof crypto < "u" && crypto.randomUUID && crypto.randomUUID.bind(crypto), _o = {
  randomUUID: ff
};
function An(t, e, n) {
  if (_o.randomUUID && !e && !t)
    return _o.randomUUID();
  t = t || {};
  const r = t.random || (t.rng || cf)();
  if (r[6] = r[6] & 15 | 64, r[8] = r[8] & 63 | 128, e) {
    n = n || 0;
    for (let i = 0; i < 16; ++i)
      e[n + i] = r[i];
    return e;
  }
  return uf(r);
}
const hn = {
  ETHEREUM: "ETHEREUM",
  APTOS: "APTOS",
  SUI: "SUI",
  COMMON: "COMMON"
}, ut = {
  REQUEST__WEB_TO_CONTENT_SCRIPT: "REQUEST__WEB_TO_CONTENT_SCRIPT",
  RESPONSE__WEB_TO_CONTENT_SCRIPT: "RESPONSE__WEB_TO_CONTENT_SCRIPT",
  REQUEST__CONTENT_SCRIPT_TO_BACKGROUND: "REQUEST__CONTENT_SCRIPT_TO_BACKGROUND",
  RESPONSE__CONTENT_SCRIPT_TO_BACKGROUND: "RESPONSE__CONTENT_SCRIPT_TO_BACKGROUND",
  REQUEST__BACKGROUND_TO_POPUP: "REQUEST__BACKGROUND_TO_POPUP",
  RESPONSE__BACKGROUND_TO_POPUP: "RESPONSE__BACKGROUND_TO_POPUP"
};
var mo = "aptos:devnet", bo = "aptos:testnet", Eo = "aptos:mainnet", lf = ((t) => (t[t.Unauthorized = 4100] = "Unauthorized", t[t.InternalError = -30001] = "InternalError", t))(lf || {}), dn = ((t) => (t.APPROVED = "Approved", t.REJECTED = "Rejected", t))(dn || {});
function oa(t) {
  return { all: t = t || /* @__PURE__ */ new Map(), on: function(e, n) {
    var r = t.get(e);
    r ? r.push(n) : t.set(e, [n]);
  }, off: function(e, n) {
    var r = t.get(e);
    r && (n ? r.splice(r.indexOf(n) >>> 0, 1) : t.set(e, []));
  }, emit: function(e, n) {
    var r = t.get(e);
    r && r.slice().map(function(i) {
      i(n);
    }), (r = t.get("*")) && r.slice().map(function(i) {
      i(e, n);
    });
  } };
}
var os = function(t, e) {
  return os = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(n, r) {
    n.__proto__ = r;
  } || function(n, r) {
    for (var i in r)
      Object.prototype.hasOwnProperty.call(r, i) && (n[i] = r[i]);
  }, os(t, e);
};
function Bs(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
  os(t, e);
  function n() {
    this.constructor = t;
  }
  t.prototype = e === null ? Object.create(e) : (n.prototype = e.prototype, new n());
}
function df(t, e, n, r) {
  function i(o) {
    return o instanceof n ? o : new n(function(c) {
      c(o);
    });
  }
  return new (n || (n = Promise))(function(o, c) {
    function f(_) {
      try {
        w(r.next(_));
      } catch (m) {
        c(m);
      }
    }
    function y(_) {
      try {
        w(r.throw(_));
      } catch (m) {
        c(m);
      }
    }
    function w(_) {
      _.done ? o(_.value) : i(_.value).then(f, y);
    }
    w((r = r.apply(t, e || [])).next());
  });
}
function aa(t, e) {
  var n = { label: 0, sent: function() {
    if (o[0] & 1)
      throw o[1];
    return o[1];
  }, trys: [], ops: [] }, r, i, o, c;
  return c = { next: f(0), throw: f(1), return: f(2) }, typeof Symbol == "function" && (c[Symbol.iterator] = function() {
    return this;
  }), c;
  function f(w) {
    return function(_) {
      return y([w, _]);
    };
  }
  function y(w) {
    if (r)
      throw new TypeError("Generator is already executing.");
    for (; c && (c = 0, w[0] && (n = 0)), n; )
      try {
        if (r = 1, i && (o = w[0] & 2 ? i.return : w[0] ? i.throw || ((o = i.return) && o.call(i), 0) : i.next) && !(o = o.call(i, w[1])).done)
          return o;
        switch (i = 0, o && (w = [w[0] & 2, o.value]), w[0]) {
          case 0:
          case 1:
            o = w;
            break;
          case 4:
            return n.label++, { value: w[1], done: !1 };
          case 5:
            n.label++, i = w[1], w = [0];
            continue;
          case 7:
            w = n.ops.pop(), n.trys.pop();
            continue;
          default:
            if (o = n.trys, !(o = o.length > 0 && o[o.length - 1]) && (w[0] === 6 || w[0] === 2)) {
              n = 0;
              continue;
            }
            if (w[0] === 3 && (!o || w[1] > o[0] && w[1] < o[3])) {
              n.label = w[1];
              break;
            }
            if (w[0] === 6 && n.label < o[1]) {
              n.label = o[1], o = w;
              break;
            }
            if (o && n.label < o[2]) {
              n.label = o[2], n.ops.push(w);
              break;
            }
            o[2] && n.ops.pop(), n.trys.pop();
            continue;
        }
        w = e.call(t, n);
      } catch (_) {
        w = [6, _], i = 0;
      } finally {
        r = o = 0;
      }
    if (w[0] & 5)
      throw w[1];
    return { value: w[0] ? w[1] : void 0, done: !0 };
  }
}
function Jn(t) {
  var e = typeof Symbol == "function" && Symbol.iterator, n = e && t[e], r = 0;
  if (n)
    return n.call(t);
  if (t && typeof t.length == "number")
    return {
      next: function() {
        return t && r >= t.length && (t = void 0), { value: t && t[r++], done: !t };
      }
    };
  throw new TypeError(e ? "Object is not iterable." : "Symbol.iterator is not defined.");
}
function Xn(t, e) {
  var n = typeof Symbol == "function" && t[Symbol.iterator];
  if (!n)
    return t;
  var r = n.call(t), i, o = [], c;
  try {
    for (; (e === void 0 || e-- > 0) && !(i = r.next()).done; )
      o.push(i.value);
  } catch (f) {
    c = { error: f };
  } finally {
    try {
      i && !i.done && (n = r.return) && n.call(r);
    } finally {
      if (c)
        throw c.error;
    }
  }
  return o;
}
function Wr(t, e, n) {
  if (n || arguments.length === 2)
    for (var r = 0, i = e.length, o; r < i; r++)
      (o || !(r in e)) && (o || (o = Array.prototype.slice.call(e, 0, r)), o[r] = e[r]);
  return t.concat(o || Array.prototype.slice.call(e));
}
function In(t) {
  return this instanceof In ? (this.v = t, this) : new In(t);
}
function hf(t, e, n) {
  if (!Symbol.asyncIterator)
    throw new TypeError("Symbol.asyncIterator is not defined.");
  var r = n.apply(t, e || []), i, o = [];
  return i = {}, c("next"), c("throw"), c("return"), i[Symbol.asyncIterator] = function() {
    return this;
  }, i;
  function c(I) {
    r[I] && (i[I] = function(z) {
      return new Promise(function(k, N) {
        o.push([I, z, k, N]) > 1 || f(I, z);
      });
    });
  }
  function f(I, z) {
    try {
      y(r[I](z));
    } catch (k) {
      m(o[0][3], k);
    }
  }
  function y(I) {
    I.value instanceof In ? Promise.resolve(I.value.v).then(w, _) : m(o[0][2], I);
  }
  function w(I) {
    f("next", I);
  }
  function _(I) {
    f("throw", I);
  }
  function m(I, z) {
    I(z), o.shift(), o.length && f(o[0][0], o[0][1]);
  }
}
function pf(t) {
  if (!Symbol.asyncIterator)
    throw new TypeError("Symbol.asyncIterator is not defined.");
  var e = t[Symbol.asyncIterator], n;
  return e ? e.call(t) : (t = typeof Jn == "function" ? Jn(t) : t[Symbol.iterator](), n = {}, r("next"), r("throw"), r("return"), n[Symbol.asyncIterator] = function() {
    return this;
  }, n);
  function r(o) {
    n[o] = t[o] && function(c) {
      return new Promise(function(f, y) {
        c = t[o](c), i(f, y, c.done, c.value);
      });
    };
  }
  function i(o, c, f, y) {
    Promise.resolve(y).then(function(w) {
      o({ value: w, done: f });
    }, c);
  }
}
function Re(t) {
  return typeof t == "function";
}
function ca(t) {
  var e = function(r) {
    Error.call(r), r.stack = new Error().stack;
  }, n = t(e);
  return n.prototype = Object.create(Error.prototype), n.prototype.constructor = n, n;
}
var Xi = ca(function(t) {
  return function(n) {
    t(this), this.message = n ? n.length + ` errors occurred during unsubscription:
` + n.map(function(r, i) {
      return i + 1 + ") " + r.toString();
    }).join(`
  `) : "", this.name = "UnsubscriptionError", this.errors = n;
  };
});
function vo(t, e) {
  if (t) {
    var n = t.indexOf(e);
    0 <= n && t.splice(n, 1);
  }
}
var Ss = function() {
  function t(e) {
    this.initialTeardown = e, this.closed = !1, this._parentage = null, this._finalizers = null;
  }
  return t.prototype.unsubscribe = function() {
    var e, n, r, i, o;
    if (!this.closed) {
      this.closed = !0;
      var c = this._parentage;
      if (c)
        if (this._parentage = null, Array.isArray(c))
          try {
            for (var f = Jn(c), y = f.next(); !y.done; y = f.next()) {
              var w = y.value;
              w.remove(this);
            }
          } catch (N) {
            e = { error: N };
          } finally {
            try {
              y && !y.done && (n = f.return) && n.call(f);
            } finally {
              if (e)
                throw e.error;
            }
          }
        else
          c.remove(this);
      var _ = this.initialTeardown;
      if (Re(_))
        try {
          _();
        } catch (N) {
          o = N instanceof Xi ? N.errors : [N];
        }
      var m = this._finalizers;
      if (m) {
        this._finalizers = null;
        try {
          for (var I = Jn(m), z = I.next(); !z.done; z = I.next()) {
            var k = z.value;
            try {
              To(k);
            } catch (N) {
              o = o ?? [], N instanceof Xi ? o = Wr(Wr([], Xn(o)), Xn(N.errors)) : o.push(N);
            }
          }
        } catch (N) {
          r = { error: N };
        } finally {
          try {
            z && !z.done && (i = I.return) && i.call(I);
          } finally {
            if (r)
              throw r.error;
          }
        }
      }
      if (o)
        throw new Xi(o);
    }
  }, t.prototype.add = function(e) {
    var n;
    if (e && e !== this)
      if (this.closed)
        To(e);
      else {
        if (e instanceof t) {
          if (e.closed || e._hasParent(this))
            return;
          e._addParent(this);
        }
        (this._finalizers = (n = this._finalizers) !== null && n !== void 0 ? n : []).push(e);
      }
  }, t.prototype._hasParent = function(e) {
    var n = this._parentage;
    return n === e || Array.isArray(n) && n.includes(e);
  }, t.prototype._addParent = function(e) {
    var n = this._parentage;
    this._parentage = Array.isArray(n) ? (n.push(e), n) : n ? [n, e] : e;
  }, t.prototype._removeParent = function(e) {
    var n = this._parentage;
    n === e ? this._parentage = null : Array.isArray(n) && vo(n, e);
  }, t.prototype.remove = function(e) {
    var n = this._finalizers;
    n && vo(n, e), e instanceof t && e._removeParent(this);
  }, t.EMPTY = function() {
    var e = new t();
    return e.closed = !0, e;
  }(), t;
}();
Ss.EMPTY;
function ua(t) {
  return t instanceof Ss || t && "closed" in t && Re(t.remove) && Re(t.add) && Re(t.unsubscribe);
}
function To(t) {
  Re(t) ? t() : t.unsubscribe();
}
var fa = {
  onUnhandledError: null,
  onStoppedNotification: null,
  Promise: void 0,
  useDeprecatedSynchronousErrorHandling: !1,
  useDeprecatedNextContext: !1
}, la = {
  setTimeout: function(t, e) {
    for (var n = [], r = 2; r < arguments.length; r++)
      n[r - 2] = arguments[r];
    return setTimeout.apply(void 0, Wr([t, e], Xn(n)));
  },
  clearTimeout: function(t) {
    var e = la.delegate;
    return ((e == null ? void 0 : e.clearTimeout) || clearTimeout)(t);
  },
  delegate: void 0
};
function da(t) {
  la.setTimeout(function() {
    throw t;
  });
}
function Bo() {
}
function Af(t) {
  t();
}
var Is = function(t) {
  Bs(e, t);
  function e(n) {
    var r = t.call(this) || this;
    return r.isStopped = !1, n ? (r.destination = n, ua(n) && n.add(r)) : r.destination = xf, r;
  }
  return e.create = function(n, r, i) {
    return new as(n, r, i);
  }, e.prototype.next = function(n) {
    this.isStopped || this._next(n);
  }, e.prototype.error = function(n) {
    this.isStopped || (this.isStopped = !0, this._error(n));
  }, e.prototype.complete = function() {
    this.isStopped || (this.isStopped = !0, this._complete());
  }, e.prototype.unsubscribe = function() {
    this.closed || (this.isStopped = !0, t.prototype.unsubscribe.call(this), this.destination = null);
  }, e.prototype._next = function(n) {
    this.destination.next(n);
  }, e.prototype._error = function(n) {
    try {
      this.destination.error(n);
    } finally {
      this.unsubscribe();
    }
  }, e.prototype._complete = function() {
    try {
      this.destination.complete();
    } finally {
      this.unsubscribe();
    }
  }, e;
}(Ss), yf = Function.prototype.bind;
function Zi(t, e) {
  return yf.call(t, e);
}
var wf = function() {
  function t(e) {
    this.partialObserver = e;
  }
  return t.prototype.next = function(e) {
    var n = this.partialObserver;
    if (n.next)
      try {
        n.next(e);
      } catch (r) {
        Br(r);
      }
  }, t.prototype.error = function(e) {
    var n = this.partialObserver;
    if (n.error)
      try {
        n.error(e);
      } catch (r) {
        Br(r);
      }
    else
      Br(e);
  }, t.prototype.complete = function() {
    var e = this.partialObserver;
    if (e.complete)
      try {
        e.complete();
      } catch (n) {
        Br(n);
      }
  }, t;
}(), as = function(t) {
  Bs(e, t);
  function e(n, r, i) {
    var o = t.call(this) || this, c;
    if (Re(n) || !n)
      c = {
        next: n ?? void 0,
        error: r ?? void 0,
        complete: i ?? void 0
      };
    else {
      var f;
      o && fa.useDeprecatedNextContext ? (f = Object.create(n), f.unsubscribe = function() {
        return o.unsubscribe();
      }, c = {
        next: n.next && Zi(n.next, f),
        error: n.error && Zi(n.error, f),
        complete: n.complete && Zi(n.complete, f)
      }) : c = n;
    }
    return o.destination = new wf(c), o;
  }
  return e;
}(Is);
function Br(t) {
  da(t);
}
function gf(t) {
  throw t;
}
var xf = {
  closed: !0,
  next: Bo,
  error: gf,
  complete: Bo
}, Us = function() {
  return typeof Symbol == "function" && Symbol.observable || "@@observable";
}();
function _f(t) {
  return t;
}
function mf(t) {
  return t.length === 0 ? _f : t.length === 1 ? t[0] : function(n) {
    return t.reduce(function(r, i) {
      return i(r);
    }, n);
  };
}
var rn = function() {
  function t(e) {
    e && (this._subscribe = e);
  }
  return t.prototype.lift = function(e) {
    var n = new t();
    return n.source = this, n.operator = e, n;
  }, t.prototype.subscribe = function(e, n, r) {
    var i = this, o = Ef(e) ? e : new as(e, n, r);
    return Af(function() {
      var c = i, f = c.operator, y = c.source;
      o.add(f ? f.call(o, y) : y ? i._subscribe(o) : i._trySubscribe(o));
    }), o;
  }, t.prototype._trySubscribe = function(e) {
    try {
      return this._subscribe(e);
    } catch (n) {
      e.error(n);
    }
  }, t.prototype.forEach = function(e, n) {
    var r = this;
    return n = So(n), new n(function(i, o) {
      var c = new as({
        next: function(f) {
          try {
            e(f);
          } catch (y) {
            o(y), c.unsubscribe();
          }
        },
        error: o,
        complete: i
      });
      r.subscribe(c);
    });
  }, t.prototype._subscribe = function(e) {
    var n;
    return (n = this.source) === null || n === void 0 ? void 0 : n.subscribe(e);
  }, t.prototype[Us] = function() {
    return this;
  }, t.prototype.pipe = function() {
    for (var e = [], n = 0; n < arguments.length; n++)
      e[n] = arguments[n];
    return mf(e)(this);
  }, t.prototype.toPromise = function(e) {
    var n = this;
    return e = So(e), new e(function(r, i) {
      var o;
      n.subscribe(function(c) {
        return o = c;
      }, function(c) {
        return i(c);
      }, function() {
        return r(o);
      });
    });
  }, t.create = function(e) {
    return new t(e);
  }, t;
}();
function So(t) {
  var e;
  return (e = t ?? fa.Promise) !== null && e !== void 0 ? e : Promise;
}
function bf(t) {
  return t && Re(t.next) && Re(t.error) && Re(t.complete);
}
function Ef(t) {
  return t && t instanceof Is || bf(t) && ua(t);
}
function vf(t) {
  return Re(t == null ? void 0 : t.lift);
}
function Ui(t) {
  return function(e) {
    if (vf(e))
      return e.lift(function(n) {
        try {
          return t(n, this);
        } catch (r) {
          this.error(r);
        }
      });
    throw new TypeError("Unable to lift unknown Observable type");
  };
}
function Zn(t, e, n, r, i) {
  return new Tf(t, e, n, r, i);
}
var Tf = function(t) {
  Bs(e, t);
  function e(n, r, i, o, c, f) {
    var y = t.call(this, n) || this;
    return y.onFinalize = c, y.shouldUnsubscribe = f, y._next = r ? function(w) {
      try {
        r(w);
      } catch (_) {
        n.error(_);
      }
    } : t.prototype._next, y._error = o ? function(w) {
      try {
        o(w);
      } catch (_) {
        n.error(_);
      } finally {
        this.unsubscribe();
      }
    } : t.prototype._error, y._complete = i ? function() {
      try {
        i();
      } catch (w) {
        n.error(w);
      } finally {
        this.unsubscribe();
      }
    } : t.prototype._complete, y;
  }
  return e.prototype.unsubscribe = function() {
    var n;
    if (!this.shouldUnsubscribe || this.shouldUnsubscribe()) {
      var r = this.closed;
      t.prototype.unsubscribe.call(this), !r && ((n = this.onFinalize) === null || n === void 0 || n.call(this));
    }
  }, e;
}(Is), Bf = new rn(function(t) {
  return t.complete();
}), ha = function(t) {
  return t && typeof t.length == "number" && typeof t != "function";
};
function Sf(t) {
  return Re(t == null ? void 0 : t.then);
}
function If(t) {
  return Re(t[Us]);
}
function Uf(t) {
  return Symbol.asyncIterator && Re(t == null ? void 0 : t[Symbol.asyncIterator]);
}
function Cf(t) {
  return new TypeError("You provided " + (t !== null && typeof t == "object" ? "an invalid object" : "'" + t + "'") + " where a stream was expected. You can provide an Observable, Promise, ReadableStream, Array, AsyncIterable, or Iterable.");
}
function Pf() {
  return typeof Symbol != "function" || !Symbol.iterator ? "@@iterator" : Symbol.iterator;
}
var Of = Pf();
function Rf(t) {
  return Re(t == null ? void 0 : t[Of]);
}
function kf(t) {
  return hf(this, arguments, function() {
    var n, r, i, o;
    return aa(this, function(c) {
      switch (c.label) {
        case 0:
          n = t.getReader(), c.label = 1;
        case 1:
          c.trys.push([1, , 9, 10]), c.label = 2;
        case 2:
          return [4, In(n.read())];
        case 3:
          return r = c.sent(), i = r.value, o = r.done, o ? [4, In(void 0)] : [3, 5];
        case 4:
          return [2, c.sent()];
        case 5:
          return [4, In(i)];
        case 6:
          return [4, c.sent()];
        case 7:
          return c.sent(), [3, 2];
        case 8:
          return [3, 10];
        case 9:
          return n.releaseLock(), [7];
        case 10:
          return [2];
      }
    });
  });
}
function Nf(t) {
  return Re(t == null ? void 0 : t.getReader);
}
function Cs(t) {
  if (t instanceof rn)
    return t;
  if (t != null) {
    if (If(t))
      return zf(t);
    if (ha(t))
      return Ff(t);
    if (Sf(t))
      return Df(t);
    if (Uf(t))
      return pa(t);
    if (Rf(t))
      return Lf(t);
    if (Nf(t))
      return Mf(t);
  }
  throw Cf(t);
}
function zf(t) {
  return new rn(function(e) {
    var n = t[Us]();
    if (Re(n.subscribe))
      return n.subscribe(e);
    throw new TypeError("Provided object does not correctly implement Symbol.observable");
  });
}
function Ff(t) {
  return new rn(function(e) {
    for (var n = 0; n < t.length && !e.closed; n++)
      e.next(t[n]);
    e.complete();
  });
}
function Df(t) {
  return new rn(function(e) {
    t.then(function(n) {
      e.closed || (e.next(n), e.complete());
    }, function(n) {
      return e.error(n);
    }).then(null, da);
  });
}
function Lf(t) {
  return new rn(function(e) {
    var n, r;
    try {
      for (var i = Jn(t), o = i.next(); !o.done; o = i.next()) {
        var c = o.value;
        if (e.next(c), e.closed)
          return;
      }
    } catch (f) {
      n = { error: f };
    } finally {
      try {
        o && !o.done && (r = i.return) && r.call(i);
      } finally {
        if (n)
          throw n.error;
      }
    }
    e.complete();
  });
}
function pa(t) {
  return new rn(function(e) {
    Hf(t, e).catch(function(n) {
      return e.error(n);
    });
  });
}
function Mf(t) {
  return pa(kf(t));
}
function Hf(t, e) {
  var n, r, i, o;
  return df(this, void 0, void 0, function() {
    var c, f;
    return aa(this, function(y) {
      switch (y.label) {
        case 0:
          y.trys.push([0, 5, 6, 11]), n = pf(t), y.label = 1;
        case 1:
          return [4, n.next()];
        case 2:
          if (r = y.sent(), !!r.done)
            return [3, 4];
          if (c = r.value, e.next(c), e.closed)
            return [2];
          y.label = 3;
        case 3:
          return [3, 1];
        case 4:
          return [3, 11];
        case 5:
          return f = y.sent(), i = { error: f }, [3, 11];
        case 6:
          return y.trys.push([6, , 9, 10]), r && !r.done && (o = n.return) ? [4, o.call(n)] : [3, 8];
        case 7:
          y.sent(), y.label = 8;
        case 8:
          return [3, 10];
        case 9:
          if (i)
            throw i.error;
          return [7];
        case 10:
          return [7];
        case 11:
          return e.complete(), [2];
      }
    });
  });
}
function $f(t, e, n, r, i) {
  r === void 0 && (r = 0), i === void 0 && (i = !1);
  var o = e.schedule(function() {
    n(), i ? t.add(this.schedule(null, r)) : this.unsubscribe();
  }, r);
  if (t.add(o), !i)
    return o;
}
var qf = ca(function(t) {
  return function() {
    t(this), this.name = "EmptyError", this.message = "no elements in sequence";
  };
});
function Qf(t, e) {
  var n = typeof e == "object";
  return new Promise(function(r, i) {
    var o = !1, c;
    t.subscribe({
      next: function(f) {
        c = f, o = !0;
      },
      error: i,
      complete: function() {
        o ? r(c) : n ? r(e.defaultValue) : i(new qf());
      }
    });
  });
}
function Kr(t, e) {
  return Ui(function(n, r) {
    var i = 0;
    n.subscribe(Zn(r, function(o) {
      r.next(t.call(e, o, i++));
    }));
  });
}
var jf = Array.isArray;
function Gf(t, e) {
  return jf(e) ? t.apply(void 0, Wr([], Xn(e))) : t(e);
}
function Wf(t) {
  return Kr(function(e) {
    return Gf(t, e);
  });
}
function Kf(t, e, n, r, i, o, c, f) {
  var y = [], w = 0, _ = 0, m = !1, I = function() {
    m && !y.length && !w && e.complete();
  }, z = function(N) {
    return w < r ? k(N) : y.push(N);
  }, k = function(N) {
    o && e.next(N), w++;
    var M = !1;
    Cs(n(N, _++)).subscribe(Zn(e, function(Z) {
      i == null || i(Z), o ? z(Z) : e.next(Z);
    }, function() {
      M = !0;
    }, void 0, function() {
      if (M)
        try {
          w--;
          for (var Z = function() {
            var ve = y.shift();
            c ? $f(e, c, function() {
              return k(ve);
            }) : k(ve);
          }; y.length && w < r; )
            Z();
          I();
        } catch (ve) {
          e.error(ve);
        }
    }));
  };
  return t.subscribe(Zn(e, z, function() {
    m = !0, I();
  })), function() {
    f == null || f();
  };
}
function Aa(t, e, n) {
  return n === void 0 && (n = 1 / 0), Re(e) ? Aa(function(r, i) {
    return Kr(function(o, c) {
      return e(r, o, i, c);
    })(Cs(t(r, i)));
  }, n) : (typeof e == "number" && (n = e), Ui(function(r, i) {
    return Kf(r, i, t, n);
  }));
}
var Yf = ["addListener", "removeListener"], Vf = ["addEventListener", "removeEventListener"], Jf = ["on", "off"];
function cs(t, e, n, r) {
  if (Re(n) && (r = n, n = void 0), r)
    return cs(t, e, n).pipe(Wf(r));
  var i = Xn(el(t) ? Vf.map(function(f) {
    return function(y) {
      return t[f](e, y, n);
    };
  }) : Xf(t) ? Yf.map(Io(t, e)) : Zf(t) ? Jf.map(Io(t, e)) : [], 2), o = i[0], c = i[1];
  if (!o && ha(t))
    return Aa(function(f) {
      return cs(f, e, n);
    })(Cs(t));
  if (!o)
    throw new TypeError("Invalid event target");
  return new rn(function(f) {
    var y = function() {
      for (var w = [], _ = 0; _ < arguments.length; _++)
        w[_] = arguments[_];
      return f.next(1 < w.length ? w : w[0]);
    };
    return o(y), function() {
      return c(y);
    };
  });
}
function Io(t, e) {
  return function(n) {
    return function(r) {
      return t[n](e, r);
    };
  };
}
function Xf(t) {
  return Re(t.addListener) && Re(t.removeListener);
}
function Zf(t) {
  return Re(t.on) && Re(t.off);
}
function el(t) {
  return Re(t.addEventListener) && Re(t.removeEventListener);
}
function Uo(t, e) {
  return Ui(function(n, r) {
    var i = 0;
    n.subscribe(Zn(r, function(o) {
      return t.call(e, o, i++) && r.next(o);
    }));
  });
}
function tl(t) {
  return t <= 0 ? function() {
    return Bf;
  } : Ui(function(e, n) {
    var r = 0;
    e.subscribe(Zn(n, function(i) {
      ++r <= t && (n.next(i), t <= r && n.complete());
    }));
  });
}
var Pn, ar, cr, ur;
class ya {
  constructor(e, n, r) {
    he(this, Pn, void 0);
    he(this, ar, void 0);
    he(this, cr, void 0);
    he(this, ur, void 0);
    if (e === n)
      throw new Error(
        "[WindowMessageStream] source and target must be different"
      );
    lt(this, ar, e), lt(this, cr, n), lt(this, ur, r), lt(this, Pn, cs(
      window,
      "message"
    ).pipe(
      Uo((i) => {
        var o;
        return i.origin === te(this, ur) && ((o = i.data) == null ? void 0 : o.target) === te(this, ar);
      }),
      Kr((i) => i.data)
    ));
  }
  async post(e) {
    const n = {
      target: te(this, cr),
      payload: e
    };
    return typeof __REACT_NATIVE__ < "u" && __REACT_NATIVE__ ? window.ReactNativeWebView.postMessage(JSON.stringify(n)) : window.postMessage(n), await Qf(
      te(this, Pn).pipe(
        Uo((r) => r.payload.id === e.id),
        Kr((r) => r.payload),
        tl(1)
      )
    );
  }
  subscribe(e) {
    return te(this, Pn).subscribe(e);
  }
}
Pn = new WeakMap(), ar = new WeakMap(), cr = new WeakMap(), ur = new WeakMap();
var er = /* @__PURE__ */ ((t) => (t.DAPP = "DAPP_WITH_RAZOR", t.RAZOR_CONTENT = "RAZOR_CONTENT", t))(er || {}), tr = /* @__PURE__ */ ((t) => (t.NETWORK_SWITCH = "RAZOR_NETWORK_SWITCH", t))(tr || {});
const Ps = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAABNGSURBVHgB7d09jB3lucDxd47Nem3H0qaJ2NvgFFBiDNKFNLZpY75SRHGkmFwk0sUBmlRBQJIqDb6KOyIlF1LESsGHIS32NrmOFGNTmuKuq+U2uXsFtnfX3p3Me/Aha3u9X2fO7sw8v5+U7CdU2M//nXnfmSKNSPnJxMTCwu4jZZke6PWKR6rvPFJ9PlH9aH8CAO40XRRpupqVs0tL5aXq67Pj43MXi4Ozs2kEilSjPPRv3tzzUlmWefAfSQDAUKooOLu0lN6rZuv7u7/z+XSqSS0BcP2v9x/ZsaN4zdAHgNHJMbC4WL5RhcDZNKShAsDgB4BtMZ3KpZd3PfG/76dN2lQAVIN/fzX4f2/wA8D2KYriD4uLS29s5tZAL23Qwt8mX+oVvU8MfwDYXmVZ/kevV3y8cP7+H6cNWvcVgLzB78bC7tfKlF5OAECjVAP95NjjM69s4PfX1h/+N3Z/XK36H0kAQCMVRbq4uFh+bz23BNYMgHy/P19eSM7vA0AbTC8tlU+uFQGrBoDhDwCtND02dv3gag8RWnUT4I4dxbvJ8AeAttmfb92v9gv3DICF85NvuucPAO2UZ3ie5ff6+Yq3AKpL//lYwe8TANBqVQi8Mv7EzMk7v39XALjvDwAdkl8uVJYH79wUuMItgOL1ZPgDQDcUaSI/vffuby8zf37yuerDuwkA6JRbRwPPDr6+8wrAmwkA6Jz88r7lX38dAPnNfsmlfwDopPwOn1uzvu/rALizDACAblk+6/t7AG7t/P+fBAB02tjY9W/mJwT2rwCUZfFcAgA6b25uvP9W334A7NyZnk0AQOdVtwEO549F+cn+iYWF+f9LAEAI+TZAb25uzvP+ASCQhfldh/MtgCMJAAijTL1v93q94kACAMLo9coDvaJIEwkACKMsi0d6ZenpfwAQzETeA7A/AQCR7O8lACAcAQAAAQkAAAhIAABAQAIAAAISAAAQkAAAgIAEAAAEJAAAICABAAABCQAACEgAAEBAAgAAAhIAABCQAACAgAQAAAQkAAAgIAEAAAEJAAAISAAAQEACAAACEgAAEJAAAICABAAABCQAACAgAQAAAQkAAAhIAABAQAIAAAISAAAQkAAAgIAEAAAEJAAAICABAAABCQAACEgAAEBAAgAAAhIAABCQAACAgAQAAAQkAAAgIAEAAAEJAAAISAAAQEACAAACEgAAEJAAAICABAAABCQAACAgAQAAAQkAAAhIAABAQAIAAAISAAAQkAAAgIAEAAAEJAAAICABAAABCQAACEgAAEBAAgAAAhIAABCQAACAgAQAAAQkAAAgIAEAAAEJAAAISAAAQEACAAACEgAAEJAAAICABAAABCQAACAgAQAAAQkAAAhIAABAQAIAAAISAAAQkAAAgIAEAAAEJAAAICABAAABCQAACEgAAEBAOxMAG3bu7/Ppg3Pz/c9/9sO96YHJHQnapJg/P1kmANY0+0WZfvunL9OZqbl06fLN23725998Mz1zeDxBWwgAgDXk1f6vf/dlmrqwcM/fyVcALr/3rQRt4RYAwAoGq/1Tp6/2P1/LlZnFBG0iAABuyYN+6sJ8Nfivrrrahy4QAEB4+RJ/HvjrXe1DFwgAIKQ86N/56Fr64Nyc1T4hCQAglMHxvT/+5ZrVPqEJAKDzrPbhbgIA6Ky82j91+lp/Y5/VPtxOAACdstHjexCVAAA6YT0P6wH+RQAArWW1D5snAIBW8bAeqIcAAFrB8T2olwAAGsvxPRgdAQA0jtU+jJ4AABphsKHvzNRcunT5ZgJGSwAA22pwfO/Tz25Y7cMWEgDAlnN8D7afAAC2jIf1QHMIAGCkLl2+0d/Fb7UPzSIAgNo5vgfNJwCA2ji+B+0hAIChWO1DOwkAYFOs9qHdBACwbh7WA90hAIA1Ob4H3SMAgBV5WA90mwAAvpYH/dSF+WrwX7Xah44TAED/En8e+Fb7EIcAgKAc34PYBAAE4/gekAkACMBqH7iTAIAOy6v9U6ev9Tf2We0DywkA6BjH94D1EADQER7WA2yEAIAWs9oHNksAQMt4WA9QBwEALeH4HlAnAQAN5vgeMCoCABrIah8YNQEADTHY0Hdmai5dunwzAYySAIBtNji+9+lnN6z2gS0jAGAbOL4HbDcBAFvIw3qAphAAMGJW+0ATCQAYoV+99YXBDzSSAIARyAP/+z//h0v9QGP1ElA7wx9oOgEANcuX/Q1/oOkEANToysxieuej6wmg6QQA1Ci/pS9HAEDTCQCo0dsfWv0D7SAAoEZW/0BbCACokQAA2kIAAEBAAgAAAhIAABCQAACAgAQAAAQkAAAgIAEAAAEJAAAISAAAQEACAAACEgAAEJAAAICABAAABCQAACAgAQAAAQkAAAhIAABAQAIAAAISAAAQkAAAgIAEAAAEJAAAICABAAABCQAACEgAAEBAAgAAAhIAABCQAACAgAQAAAQkAAAgIAEAAAEJAAAISAAAQEACAAACEgAAEJAAAICABAAABCQAACAgAQAAAQkAAAhIAABAQAIAAAISAAAQkAAAgIAEAEANHpjckaBNBABADQQAbSMAAGpw/OieBG0iAACGlFf/hx8bS9AmAgBgSCeO7XULgNYRAABDeObweD8AoG0EAMAm5eH/1qsTCdpoZwJgQyb2FekXL+6z8qfVBADAOuXBf+LYN9JPf7C3/zm0mQAAWEUe9E8fGk/PP7UnHXrUTn+6QwAArCAP+3yPP5/vt9qniwQAwC2DS/x5+Fvt03UCAAgvD/tXf7LP0CcUAQCE9PCD96Vnj4zb0EdYAgAIIw/6H313T3/wW+0TnQAAOs+GPribAAA6abCh7/jR3Z7TDysQAECn2NAH6yMAgNZziR82TgAArWRDHwxHAACtkod9fgnPoUd3We3DEAQA0HhewgP1EwBAI+VBn1f5X632XeKHugkAoFFs6IOtIQCAbWdDH2w9AQBsm8GZ/fxcfqt92FoCANhS+al8zz+1x4Y+2GYCABg5l/iheQQAMDI29EFzCQCgVoMz+08fGk8HHvJXDDSVP51ALep6Cc+5v8+nD87N9z//2Q/3epMfjEgxf36yTEAtdj0+kyLJu/fzff1hN/TNflGm3/7py3Rmai5dunzztp/9+Tff7N9GAOolAKBGEQKgzg19ebX/6999maYuLNzzd/IVgMvvfSsB9XILAFiXujb0DVb7p05f7X++lisziwmonwAA7mmwoe/40d1D3YvPg37qwnw1+K+uutoHto4AAG6Th36+t1/Xhr488Ne72ge2jgAA+uq8xP/OR9fSB+fmrPahwQQABFb3hr58fO+Pf7lmtQ8tIAAgoDzsTxzbW33cZbUPQQkACGKwoa+Ol/Dk1f6p09f6G/us9qGdBAB0WB70+ZG8+e17w17i3+jxPaDZBAB0UJ0v4VnPw3qA9hEA0BGDS/x5+FvtA2sRANBydb2Ex8N6IBYBAC2Un8qX7+vXtaHP8T2IRwBAS9R5Zt/xPUAAQMPVvaHPah/IBAA00GBDXz7Cd+Ch4f6YDjb0nZmaS5cu30wAmQCABqlrQ182OL736Wc3rPaBuwgA2GZ52B9+bFctG/oc3wPWSwDANqhzQ1/mYT3ARgkAqFE+nndlZvGeP8/DPh/fy/f2h13tX7p8o7+L32of2AwBADXK9+9f/OXsbd+r8yU8ju8BdREAUKPjR3enhx/cmd7+8Hr/6zov8Tu+B9SpmD8/6W8TaCCr/X+p/p5KQL1cAYCGsdoHtoIAgAbwsB5gqwkA2EaO7wHbRQDAFvOwHqAJBABsgTzopy7MV4P/qtU+0AgCAEYoX+LPA99qH2gaAQA1c3wPaAMBADVxfA9oEwEAQ7DaB9pKAMAm5NX+qdPX+hv7rPaBNhIAsE6O7wFdIgBgDR7WA3SRAIAVWO0DXScA4BYP6wEiEQCE5/geEJEAICTH94DoBAChWO0DfEUA0HmDDX1npubSpcs3EwACgA4bHN/79LMbVvsAdxAAdIrjewDrIwDoBA/rAdgYAUBrWe0DbJ4AoJV+9dYXBj/AEAQArZIH/vd//g+X+gGG1EvQIoY/QD0EAK2RL/sb/gD1EAC0wpWZxfTOR9cTAPUQALRCfktfjgAA6iEAaIW3P7T6B6iTAKAVrP4B6iUAaAUBAFAvAQAAAQkAAAhIAABAQAIAAAISAAAQkAAAgIAEAAAEJAAAICABAAABCQAACEgAAEBAAgAAAhIAABCQAACAgAQAAAQkAAAgIAEAAAEJAAAISAAAQEACAAACEgAAEJAAAICABAAABCQAACAgAQAAAQkAAAhIAABAQAIAAAISAAAQkAAAgIAEAAAEJAAAICABAAABCQAACEgAAEBAAgAAAhIAABCQAACAgAQAAAQkAAAgIAEAAAEJAAAISAAAQEACAAACEgBAoz0wuSMB9RMAQKMJABgNAQA02vGjexJQPwEANFZe/R9+bCwB9RMAQGOdOLbXLQAYEQEANNIzh8f7AQCMhgAAGicP/7denUjA6OxMAA0xsa9Iv3hxn5U/bAEBAGy7PPhPHPtG+ukP9vY/B0ZPAADbIg/6pw+Np+ef2pMOPWqnP2w1AQBsqTzs8z3+fL7fah+2jwAARm5wiT8Pf6t9aAYBAIxMHvav/mSfoQ8NJACAWj384H3p2SPjNvRBwwkAYGh50P/ou3v6g99qH9pBAACbZkMftJcAADZksKHv+NHdntMPLSYAgHWxoQ+6RQAA9+QSP3SXAABuY0MfxCAAgL487PNLeA49ustqHwIQABCYl/BAXAIAgsmDPq/yv1rtu8QPUQkACMKGPmA5AQAdZkMfcC8CADpocGY/P5ffah9YiQCAjshP5Xv+qT029AHrIgCgxVziBzZLAEAL2dAHDEsAQEsMzuw/fWg8HXjIH11gOP4WgYbzEh5gFAQANFDevZ/v69vQB4yKAICGsKEP2EoCALaZDX3AdhAAsA0GG/qOH93dP78PsNUEAGyRPPTzvX0b+oAmEAAwYi7xA00kAGAEbOgDmk4AQI3ysD9xbG/1cZfVPtBoAgCGNNjQ58w+0CYCADYhD/r8SN789j2X+IE2EgCwATb0AV0hAGANg0v8efhb7QNdIQDgHryEB+gyAQDLeAkPEIUAIDxn9oGIBABh2dAHRCYACGWwoS8f4TvwkP/8gbj8DUgINvQB3E4A0Fl52B9+bJcNfQArEAB0ig19AOsjAGiFByZ3pCszi/f8eR72+bG8+d6+1T7A2gQArZDv37/4y9nbvuclPACbV8yfnywTtMClyzfS2x9e73/uEj/AcAQAAATUSwBAOAIAAAISAAAQkAAAgIAEAAAEJAAAICABAAABCQAACEgAAEBAAgAAAhIAABCQAACAgAQAAAQkAAAgIAEAAAEJAAAISAAAQEACAAACEgAAEJAAAICABAAABCQAACAgAQAAAQkAAAhIAABAQAIAAAISAAAQkAAAgIAEAAAEJAAAICABAAABCQAACEgAAEBAAgAAAhIAABCQAACAgAQAAAQkAAAgIAEAAAEJAAAISAAAQEACAAACEgAAEJAAAICABAAABCQAACAgAQAAAQkAAAhIAABAQAIAAAISAAAQkAAAgIAEAAAEJAAAICABAAABCQAACEgAAEBAAgAAAhIAABCQAACAgAQAAAQkAAAgIAEAAAEJAAAISAAAQEACAAACEgAAEJAAAICABAAABCQAACAgAQAAAQkAAAhIAABAQAIAAAISAAAQkAAAgIAEAAAEJAAAICABAAABCQAACEgAAEBAAgAAAhIAABCQAACAgAQAAAQkAAAgoBwA0wkAiGS6CoBiNgEAYZRlOd1bWlq6lACAQIr/75VlcTEBAGFUVwAu9nbssAcAAII52xsb23U2AQBhjI/PXewVB6dniyKdTQBA51WX/88WB2dn+88BWFwszyUAIIDi/fz//QAYHx8/mQCAzquuALyXP/YDwG0AAOi+fPl/93c+n86ff/0o4Oo2wBsJAOisskxfz/pi+Q8W/jb5cfXDIwkA6JrpXY/PfHvwxW0vA3IVAAA665XlX9wWANV9gbP2AgBAtxRF+Ydq9f/e8u/d9Trg6irAC6n0giAA6IjpxcV01xX+uwIg7w4sk1sBANAFRSpfH+z8X6630i+PPzFzsizTfyYAoLXyLB97/PP/WulnxWr/4Pz5f/uk+scfSQBAqxRFujj27zMH7/Xz3mr/8NjY2JPVh+kEALRJdd+//N5qv7BqAOQnBC4tlSIAANpjOs/ule77L7fqLYCB63+9f3+v13vX7QAAaK582f+++64/md/2t+bvpg2Y++/Jk9W//KUEADRK3vA3/sTMy+v9/V7agPwvri4rvJDcEgCAZiiL2Wr4v7KR4Z9t6ArAQL4lUH14vdcrfpwAgG2R3+5XDf8X1rrfv5JNBcDA/PnJ56oPb1b/258AgC1xa/C/kR/hnzZpqAAYqK4IHNlRpNfKojiSAICRqGPwD9QSAAP51kBRFM/2UvmcGACA4d0a+ufGx+dOrmd3/3rVGgDLlZ9MTMzNjedjg0d6RXGgSOXEUnWroAqE/QkAuE016KerGTlblOXFpVRcLIp0ZWzs+tk6h/5y/wRUwXnWRW1utwAAAABJRU5ErkJggg==", nl = "Razor Wallet", rl = "xyz.razorwallet";
function il(t) {
  return t && t.__esModule && Object.prototype.hasOwnProperty.call(t, "default") ? t.default : t;
}
function sl(t) {
  if (t.__esModule)
    return t;
  var e = t.default;
  if (typeof e == "function") {
    var n = function r() {
      return this instanceof r ? Reflect.construct(e, arguments, this.constructor) : e.apply(this, arguments);
    };
    n.prototype = e.prototype;
  } else
    n = {};
  return Object.defineProperty(n, "__esModule", { value: !0 }), Object.keys(t).forEach(function(r) {
    var i = Object.getOwnPropertyDescriptor(t, r);
    Object.defineProperty(n, r, i.get ? i : {
      enumerable: !0,
      get: function() {
        return t[r];
      }
    });
  }), n;
}
function ol(t) {
  throw new Error('Could not dynamically require "' + t + '". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.');
}
var wa = { exports: {} };
const al = {}, cl = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: al
}, Symbol.toStringTag, { value: "Module" })), ul = /* @__PURE__ */ sl(cl);
(function(t) {
  (function(e) {
    var n = function(l) {
      var p, d = new Float64Array(16);
      if (l)
        for (p = 0; p < l.length; p++)
          d[p] = l[p];
      return d;
    }, r = function() {
      throw new Error("no PRNG");
    }, i = new Uint8Array(16), o = new Uint8Array(32);
    o[0] = 9;
    var c = n(), f = n([1]), y = n([56129, 1]), w = n([30883, 4953, 19914, 30187, 55467, 16705, 2637, 112, 59544, 30585, 16505, 36039, 65139, 11119, 27886, 20995]), _ = n([61785, 9906, 39828, 60374, 45398, 33411, 5274, 224, 53552, 61171, 33010, 6542, 64743, 22239, 55772, 9222]), m = n([54554, 36645, 11616, 51542, 42930, 38181, 51040, 26924, 56412, 64982, 57905, 49316, 21502, 52590, 14035, 8553]), I = n([26200, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214]), z = n([41136, 18958, 6951, 50414, 58488, 44335, 6150, 12099, 55207, 15867, 153, 11085, 57099, 20417, 9344, 11139]);
    function k(l, p, d, s) {
      l[p] = d >> 24 & 255, l[p + 1] = d >> 16 & 255, l[p + 2] = d >> 8 & 255, l[p + 3] = d & 255, l[p + 4] = s >> 24 & 255, l[p + 5] = s >> 16 & 255, l[p + 6] = s >> 8 & 255, l[p + 7] = s & 255;
    }
    function N(l, p, d, s, A) {
      var E, v = 0;
      for (E = 0; E < A; E++)
        v |= l[p + E] ^ d[s + E];
      return (1 & v - 1 >>> 8) - 1;
    }
    function M(l, p, d, s) {
      return N(l, p, d, s, 16);
    }
    function Z(l, p, d, s) {
      return N(l, p, d, s, 32);
    }
    function ve(l, p, d, s) {
      for (var A = s[0] & 255 | (s[1] & 255) << 8 | (s[2] & 255) << 16 | (s[3] & 255) << 24, E = d[0] & 255 | (d[1] & 255) << 8 | (d[2] & 255) << 16 | (d[3] & 255) << 24, v = d[4] & 255 | (d[5] & 255) << 8 | (d[6] & 255) << 16 | (d[7] & 255) << 24, O = d[8] & 255 | (d[9] & 255) << 8 | (d[10] & 255) << 16 | (d[11] & 255) << 24, L = d[12] & 255 | (d[13] & 255) << 8 | (d[14] & 255) << 16 | (d[15] & 255) << 24, Y = s[4] & 255 | (s[5] & 255) << 8 | (s[6] & 255) << 16 | (s[7] & 255) << 24, $ = p[0] & 255 | (p[1] & 255) << 8 | (p[2] & 255) << 16 | (p[3] & 255) << 24, me = p[4] & 255 | (p[5] & 255) << 8 | (p[6] & 255) << 16 | (p[7] & 255) << 24, j = p[8] & 255 | (p[9] & 255) << 8 | (p[10] & 255) << 16 | (p[11] & 255) << 24, ee = p[12] & 255 | (p[13] & 255) << 8 | (p[14] & 255) << 16 | (p[15] & 255) << 24, ne = s[8] & 255 | (s[9] & 255) << 8 | (s[10] & 255) << 16 | (s[11] & 255) << 24, ce = d[16] & 255 | (d[17] & 255) << 8 | (d[18] & 255) << 16 | (d[19] & 255) << 24, ae = d[20] & 255 | (d[21] & 255) << 8 | (d[22] & 255) << 16 | (d[23] & 255) << 24, re = d[24] & 255 | (d[25] & 255) << 8 | (d[26] & 255) << 16 | (d[27] & 255) << 24, se = d[28] & 255 | (d[29] & 255) << 8 | (d[30] & 255) << 16 | (d[31] & 255) << 24, ie = s[12] & 255 | (s[13] & 255) << 8 | (s[14] & 255) << 16 | (s[15] & 255) << 24, G = A, V = E, q = v, W = O, K = L, H = Y, B = $, S = me, F = j, P = ee, R = ne, D = ce, X = ae, ue = re, le = se, fe = ie, x, Ae = 0; Ae < 20; Ae += 2)
        x = G + X | 0, K ^= x << 7 | x >>> 25, x = K + G | 0, F ^= x << 9 | x >>> 23, x = F + K | 0, X ^= x << 13 | x >>> 19, x = X + F | 0, G ^= x << 18 | x >>> 14, x = H + V | 0, P ^= x << 7 | x >>> 25, x = P + H | 0, ue ^= x << 9 | x >>> 23, x = ue + P | 0, V ^= x << 13 | x >>> 19, x = V + ue | 0, H ^= x << 18 | x >>> 14, x = R + B | 0, le ^= x << 7 | x >>> 25, x = le + R | 0, q ^= x << 9 | x >>> 23, x = q + le | 0, B ^= x << 13 | x >>> 19, x = B + q | 0, R ^= x << 18 | x >>> 14, x = fe + D | 0, W ^= x << 7 | x >>> 25, x = W + fe | 0, S ^= x << 9 | x >>> 23, x = S + W | 0, D ^= x << 13 | x >>> 19, x = D + S | 0, fe ^= x << 18 | x >>> 14, x = G + W | 0, V ^= x << 7 | x >>> 25, x = V + G | 0, q ^= x << 9 | x >>> 23, x = q + V | 0, W ^= x << 13 | x >>> 19, x = W + q | 0, G ^= x << 18 | x >>> 14, x = H + K | 0, B ^= x << 7 | x >>> 25, x = B + H | 0, S ^= x << 9 | x >>> 23, x = S + B | 0, K ^= x << 13 | x >>> 19, x = K + S | 0, H ^= x << 18 | x >>> 14, x = R + P | 0, D ^= x << 7 | x >>> 25, x = D + R | 0, F ^= x << 9 | x >>> 23, x = F + D | 0, P ^= x << 13 | x >>> 19, x = P + F | 0, R ^= x << 18 | x >>> 14, x = fe + le | 0, X ^= x << 7 | x >>> 25, x = X + fe | 0, ue ^= x << 9 | x >>> 23, x = ue + X | 0, le ^= x << 13 | x >>> 19, x = le + ue | 0, fe ^= x << 18 | x >>> 14;
      G = G + A | 0, V = V + E | 0, q = q + v | 0, W = W + O | 0, K = K + L | 0, H = H + Y | 0, B = B + $ | 0, S = S + me | 0, F = F + j | 0, P = P + ee | 0, R = R + ne | 0, D = D + ce | 0, X = X + ae | 0, ue = ue + re | 0, le = le + se | 0, fe = fe + ie | 0, l[0] = G >>> 0 & 255, l[1] = G >>> 8 & 255, l[2] = G >>> 16 & 255, l[3] = G >>> 24 & 255, l[4] = V >>> 0 & 255, l[5] = V >>> 8 & 255, l[6] = V >>> 16 & 255, l[7] = V >>> 24 & 255, l[8] = q >>> 0 & 255, l[9] = q >>> 8 & 255, l[10] = q >>> 16 & 255, l[11] = q >>> 24 & 255, l[12] = W >>> 0 & 255, l[13] = W >>> 8 & 255, l[14] = W >>> 16 & 255, l[15] = W >>> 24 & 255, l[16] = K >>> 0 & 255, l[17] = K >>> 8 & 255, l[18] = K >>> 16 & 255, l[19] = K >>> 24 & 255, l[20] = H >>> 0 & 255, l[21] = H >>> 8 & 255, l[22] = H >>> 16 & 255, l[23] = H >>> 24 & 255, l[24] = B >>> 0 & 255, l[25] = B >>> 8 & 255, l[26] = B >>> 16 & 255, l[27] = B >>> 24 & 255, l[28] = S >>> 0 & 255, l[29] = S >>> 8 & 255, l[30] = S >>> 16 & 255, l[31] = S >>> 24 & 255, l[32] = F >>> 0 & 255, l[33] = F >>> 8 & 255, l[34] = F >>> 16 & 255, l[35] = F >>> 24 & 255, l[36] = P >>> 0 & 255, l[37] = P >>> 8 & 255, l[38] = P >>> 16 & 255, l[39] = P >>> 24 & 255, l[40] = R >>> 0 & 255, l[41] = R >>> 8 & 255, l[42] = R >>> 16 & 255, l[43] = R >>> 24 & 255, l[44] = D >>> 0 & 255, l[45] = D >>> 8 & 255, l[46] = D >>> 16 & 255, l[47] = D >>> 24 & 255, l[48] = X >>> 0 & 255, l[49] = X >>> 8 & 255, l[50] = X >>> 16 & 255, l[51] = X >>> 24 & 255, l[52] = ue >>> 0 & 255, l[53] = ue >>> 8 & 255, l[54] = ue >>> 16 & 255, l[55] = ue >>> 24 & 255, l[56] = le >>> 0 & 255, l[57] = le >>> 8 & 255, l[58] = le >>> 16 & 255, l[59] = le >>> 24 & 255, l[60] = fe >>> 0 & 255, l[61] = fe >>> 8 & 255, l[62] = fe >>> 16 & 255, l[63] = fe >>> 24 & 255;
    }
    function Q(l, p, d, s) {
      for (var A = s[0] & 255 | (s[1] & 255) << 8 | (s[2] & 255) << 16 | (s[3] & 255) << 24, E = d[0] & 255 | (d[1] & 255) << 8 | (d[2] & 255) << 16 | (d[3] & 255) << 24, v = d[4] & 255 | (d[5] & 255) << 8 | (d[6] & 255) << 16 | (d[7] & 255) << 24, O = d[8] & 255 | (d[9] & 255) << 8 | (d[10] & 255) << 16 | (d[11] & 255) << 24, L = d[12] & 255 | (d[13] & 255) << 8 | (d[14] & 255) << 16 | (d[15] & 255) << 24, Y = s[4] & 255 | (s[5] & 255) << 8 | (s[6] & 255) << 16 | (s[7] & 255) << 24, $ = p[0] & 255 | (p[1] & 255) << 8 | (p[2] & 255) << 16 | (p[3] & 255) << 24, me = p[4] & 255 | (p[5] & 255) << 8 | (p[6] & 255) << 16 | (p[7] & 255) << 24, j = p[8] & 255 | (p[9] & 255) << 8 | (p[10] & 255) << 16 | (p[11] & 255) << 24, ee = p[12] & 255 | (p[13] & 255) << 8 | (p[14] & 255) << 16 | (p[15] & 255) << 24, ne = s[8] & 255 | (s[9] & 255) << 8 | (s[10] & 255) << 16 | (s[11] & 255) << 24, ce = d[16] & 255 | (d[17] & 255) << 8 | (d[18] & 255) << 16 | (d[19] & 255) << 24, ae = d[20] & 255 | (d[21] & 255) << 8 | (d[22] & 255) << 16 | (d[23] & 255) << 24, re = d[24] & 255 | (d[25] & 255) << 8 | (d[26] & 255) << 16 | (d[27] & 255) << 24, se = d[28] & 255 | (d[29] & 255) << 8 | (d[30] & 255) << 16 | (d[31] & 255) << 24, ie = s[12] & 255 | (s[13] & 255) << 8 | (s[14] & 255) << 16 | (s[15] & 255) << 24, G = A, V = E, q = v, W = O, K = L, H = Y, B = $, S = me, F = j, P = ee, R = ne, D = ce, X = ae, ue = re, le = se, fe = ie, x, Ae = 0; Ae < 20; Ae += 2)
        x = G + X | 0, K ^= x << 7 | x >>> 25, x = K + G | 0, F ^= x << 9 | x >>> 23, x = F + K | 0, X ^= x << 13 | x >>> 19, x = X + F | 0, G ^= x << 18 | x >>> 14, x = H + V | 0, P ^= x << 7 | x >>> 25, x = P + H | 0, ue ^= x << 9 | x >>> 23, x = ue + P | 0, V ^= x << 13 | x >>> 19, x = V + ue | 0, H ^= x << 18 | x >>> 14, x = R + B | 0, le ^= x << 7 | x >>> 25, x = le + R | 0, q ^= x << 9 | x >>> 23, x = q + le | 0, B ^= x << 13 | x >>> 19, x = B + q | 0, R ^= x << 18 | x >>> 14, x = fe + D | 0, W ^= x << 7 | x >>> 25, x = W + fe | 0, S ^= x << 9 | x >>> 23, x = S + W | 0, D ^= x << 13 | x >>> 19, x = D + S | 0, fe ^= x << 18 | x >>> 14, x = G + W | 0, V ^= x << 7 | x >>> 25, x = V + G | 0, q ^= x << 9 | x >>> 23, x = q + V | 0, W ^= x << 13 | x >>> 19, x = W + q | 0, G ^= x << 18 | x >>> 14, x = H + K | 0, B ^= x << 7 | x >>> 25, x = B + H | 0, S ^= x << 9 | x >>> 23, x = S + B | 0, K ^= x << 13 | x >>> 19, x = K + S | 0, H ^= x << 18 | x >>> 14, x = R + P | 0, D ^= x << 7 | x >>> 25, x = D + R | 0, F ^= x << 9 | x >>> 23, x = F + D | 0, P ^= x << 13 | x >>> 19, x = P + F | 0, R ^= x << 18 | x >>> 14, x = fe + le | 0, X ^= x << 7 | x >>> 25, x = X + fe | 0, ue ^= x << 9 | x >>> 23, x = ue + X | 0, le ^= x << 13 | x >>> 19, x = le + ue | 0, fe ^= x << 18 | x >>> 14;
      l[0] = G >>> 0 & 255, l[1] = G >>> 8 & 255, l[2] = G >>> 16 & 255, l[3] = G >>> 24 & 255, l[4] = H >>> 0 & 255, l[5] = H >>> 8 & 255, l[6] = H >>> 16 & 255, l[7] = H >>> 24 & 255, l[8] = R >>> 0 & 255, l[9] = R >>> 8 & 255, l[10] = R >>> 16 & 255, l[11] = R >>> 24 & 255, l[12] = fe >>> 0 & 255, l[13] = fe >>> 8 & 255, l[14] = fe >>> 16 & 255, l[15] = fe >>> 24 & 255, l[16] = B >>> 0 & 255, l[17] = B >>> 8 & 255, l[18] = B >>> 16 & 255, l[19] = B >>> 24 & 255, l[20] = S >>> 0 & 255, l[21] = S >>> 8 & 255, l[22] = S >>> 16 & 255, l[23] = S >>> 24 & 255, l[24] = F >>> 0 & 255, l[25] = F >>> 8 & 255, l[26] = F >>> 16 & 255, l[27] = F >>> 24 & 255, l[28] = P >>> 0 & 255, l[29] = P >>> 8 & 255, l[30] = P >>> 16 & 255, l[31] = P >>> 24 & 255;
    }
    function ke(l, p, d, s) {
      ve(l, p, d, s);
    }
    function Ce(l, p, d, s) {
      Q(l, p, d, s);
    }
    var nt = new Uint8Array([101, 120, 112, 97, 110, 100, 32, 51, 50, 45, 98, 121, 116, 101, 32, 107]);
    function It(l, p, d, s, A, E, v) {
      var O = new Uint8Array(16), L = new Uint8Array(64), Y, $;
      for ($ = 0; $ < 16; $++)
        O[$] = 0;
      for ($ = 0; $ < 8; $++)
        O[$] = E[$];
      for (; A >= 64; ) {
        for (ke(L, O, v, nt), $ = 0; $ < 64; $++)
          l[p + $] = d[s + $] ^ L[$];
        for (Y = 1, $ = 8; $ < 16; $++)
          Y = Y + (O[$] & 255) | 0, O[$] = Y & 255, Y >>>= 8;
        A -= 64, p += 64, s += 64;
      }
      if (A > 0)
        for (ke(L, O, v, nt), $ = 0; $ < A; $++)
          l[p + $] = d[s + $] ^ L[$];
      return 0;
    }
    function rt(l, p, d, s, A) {
      var E = new Uint8Array(16), v = new Uint8Array(64), O, L;
      for (L = 0; L < 16; L++)
        E[L] = 0;
      for (L = 0; L < 8; L++)
        E[L] = s[L];
      for (; d >= 64; ) {
        for (ke(v, E, A, nt), L = 0; L < 64; L++)
          l[p + L] = v[L];
        for (O = 1, L = 8; L < 16; L++)
          O = O + (E[L] & 255) | 0, E[L] = O & 255, O >>>= 8;
        d -= 64, p += 64;
      }
      if (d > 0)
        for (ke(v, E, A, nt), L = 0; L < d; L++)
          l[p + L] = v[L];
      return 0;
    }
    function it(l, p, d, s, A) {
      var E = new Uint8Array(32);
      Ce(E, s, A, nt);
      for (var v = new Uint8Array(8), O = 0; O < 8; O++)
        v[O] = s[O + 16];
      return rt(l, p, d, v, E);
    }
    function mt(l, p, d, s, A, E, v) {
      var O = new Uint8Array(32);
      Ce(O, E, v, nt);
      for (var L = new Uint8Array(8), Y = 0; Y < 8; Y++)
        L[Y] = E[Y + 16];
      return It(l, p, d, s, A, L, O);
    }
    var bt = function(l) {
      this.buffer = new Uint8Array(16), this.r = new Uint16Array(10), this.h = new Uint16Array(10), this.pad = new Uint16Array(8), this.leftover = 0, this.fin = 0;
      var p, d, s, A, E, v, O, L;
      p = l[0] & 255 | (l[1] & 255) << 8, this.r[0] = p & 8191, d = l[2] & 255 | (l[3] & 255) << 8, this.r[1] = (p >>> 13 | d << 3) & 8191, s = l[4] & 255 | (l[5] & 255) << 8, this.r[2] = (d >>> 10 | s << 6) & 7939, A = l[6] & 255 | (l[7] & 255) << 8, this.r[3] = (s >>> 7 | A << 9) & 8191, E = l[8] & 255 | (l[9] & 255) << 8, this.r[4] = (A >>> 4 | E << 12) & 255, this.r[5] = E >>> 1 & 8190, v = l[10] & 255 | (l[11] & 255) << 8, this.r[6] = (E >>> 14 | v << 2) & 8191, O = l[12] & 255 | (l[13] & 255) << 8, this.r[7] = (v >>> 11 | O << 5) & 8065, L = l[14] & 255 | (l[15] & 255) << 8, this.r[8] = (O >>> 8 | L << 8) & 8191, this.r[9] = L >>> 5 & 127, this.pad[0] = l[16] & 255 | (l[17] & 255) << 8, this.pad[1] = l[18] & 255 | (l[19] & 255) << 8, this.pad[2] = l[20] & 255 | (l[21] & 255) << 8, this.pad[3] = l[22] & 255 | (l[23] & 255) << 8, this.pad[4] = l[24] & 255 | (l[25] & 255) << 8, this.pad[5] = l[26] & 255 | (l[27] & 255) << 8, this.pad[6] = l[28] & 255 | (l[29] & 255) << 8, this.pad[7] = l[30] & 255 | (l[31] & 255) << 8;
    };
    bt.prototype.blocks = function(l, p, d) {
      for (var s = this.fin ? 0 : 2048, A, E, v, O, L, Y, $, me, j, ee, ne, ce, ae, re, se, ie, G, V, q, W = this.h[0], K = this.h[1], H = this.h[2], B = this.h[3], S = this.h[4], F = this.h[5], P = this.h[6], R = this.h[7], D = this.h[8], X = this.h[9], ue = this.r[0], le = this.r[1], fe = this.r[2], x = this.r[3], Ae = this.r[4], be = this.r[5], Ee = this.r[6], de = this.r[7], we = this.r[8], ge = this.r[9]; d >= 16; )
        A = l[p + 0] & 255 | (l[p + 1] & 255) << 8, W += A & 8191, E = l[p + 2] & 255 | (l[p + 3] & 255) << 8, K += (A >>> 13 | E << 3) & 8191, v = l[p + 4] & 255 | (l[p + 5] & 255) << 8, H += (E >>> 10 | v << 6) & 8191, O = l[p + 6] & 255 | (l[p + 7] & 255) << 8, B += (v >>> 7 | O << 9) & 8191, L = l[p + 8] & 255 | (l[p + 9] & 255) << 8, S += (O >>> 4 | L << 12) & 8191, F += L >>> 1 & 8191, Y = l[p + 10] & 255 | (l[p + 11] & 255) << 8, P += (L >>> 14 | Y << 2) & 8191, $ = l[p + 12] & 255 | (l[p + 13] & 255) << 8, R += (Y >>> 11 | $ << 5) & 8191, me = l[p + 14] & 255 | (l[p + 15] & 255) << 8, D += ($ >>> 8 | me << 8) & 8191, X += me >>> 5 | s, j = 0, ee = j, ee += W * ue, ee += K * (5 * ge), ee += H * (5 * we), ee += B * (5 * de), ee += S * (5 * Ee), j = ee >>> 13, ee &= 8191, ee += F * (5 * be), ee += P * (5 * Ae), ee += R * (5 * x), ee += D * (5 * fe), ee += X * (5 * le), j += ee >>> 13, ee &= 8191, ne = j, ne += W * le, ne += K * ue, ne += H * (5 * ge), ne += B * (5 * we), ne += S * (5 * de), j = ne >>> 13, ne &= 8191, ne += F * (5 * Ee), ne += P * (5 * be), ne += R * (5 * Ae), ne += D * (5 * x), ne += X * (5 * fe), j += ne >>> 13, ne &= 8191, ce = j, ce += W * fe, ce += K * le, ce += H * ue, ce += B * (5 * ge), ce += S * (5 * we), j = ce >>> 13, ce &= 8191, ce += F * (5 * de), ce += P * (5 * Ee), ce += R * (5 * be), ce += D * (5 * Ae), ce += X * (5 * x), j += ce >>> 13, ce &= 8191, ae = j, ae += W * x, ae += K * fe, ae += H * le, ae += B * ue, ae += S * (5 * ge), j = ae >>> 13, ae &= 8191, ae += F * (5 * we), ae += P * (5 * de), ae += R * (5 * Ee), ae += D * (5 * be), ae += X * (5 * Ae), j += ae >>> 13, ae &= 8191, re = j, re += W * Ae, re += K * x, re += H * fe, re += B * le, re += S * ue, j = re >>> 13, re &= 8191, re += F * (5 * ge), re += P * (5 * we), re += R * (5 * de), re += D * (5 * Ee), re += X * (5 * be), j += re >>> 13, re &= 8191, se = j, se += W * be, se += K * Ae, se += H * x, se += B * fe, se += S * le, j = se >>> 13, se &= 8191, se += F * ue, se += P * (5 * ge), se += R * (5 * we), se += D * (5 * de), se += X * (5 * Ee), j += se >>> 13, se &= 8191, ie = j, ie += W * Ee, ie += K * be, ie += H * Ae, ie += B * x, ie += S * fe, j = ie >>> 13, ie &= 8191, ie += F * le, ie += P * ue, ie += R * (5 * ge), ie += D * (5 * we), ie += X * (5 * de), j += ie >>> 13, ie &= 8191, G = j, G += W * de, G += K * Ee, G += H * be, G += B * Ae, G += S * x, j = G >>> 13, G &= 8191, G += F * fe, G += P * le, G += R * ue, G += D * (5 * ge), G += X * (5 * we), j += G >>> 13, G &= 8191, V = j, V += W * we, V += K * de, V += H * Ee, V += B * be, V += S * Ae, j = V >>> 13, V &= 8191, V += F * x, V += P * fe, V += R * le, V += D * ue, V += X * (5 * ge), j += V >>> 13, V &= 8191, q = j, q += W * ge, q += K * we, q += H * de, q += B * Ee, q += S * be, j = q >>> 13, q &= 8191, q += F * Ae, q += P * x, q += R * fe, q += D * le, q += X * ue, j += q >>> 13, q &= 8191, j = (j << 2) + j | 0, j = j + ee | 0, ee = j & 8191, j = j >>> 13, ne += j, W = ee, K = ne, H = ce, B = ae, S = re, F = se, P = ie, R = G, D = V, X = q, p += 16, d -= 16;
      this.h[0] = W, this.h[1] = K, this.h[2] = H, this.h[3] = B, this.h[4] = S, this.h[5] = F, this.h[6] = P, this.h[7] = R, this.h[8] = D, this.h[9] = X;
    }, bt.prototype.finish = function(l, p) {
      var d = new Uint16Array(10), s, A, E, v;
      if (this.leftover) {
        for (v = this.leftover, this.buffer[v++] = 1; v < 16; v++)
          this.buffer[v] = 0;
        this.fin = 1, this.blocks(this.buffer, 0, 16);
      }
      for (s = this.h[1] >>> 13, this.h[1] &= 8191, v = 2; v < 10; v++)
        this.h[v] += s, s = this.h[v] >>> 13, this.h[v] &= 8191;
      for (this.h[0] += s * 5, s = this.h[0] >>> 13, this.h[0] &= 8191, this.h[1] += s, s = this.h[1] >>> 13, this.h[1] &= 8191, this.h[2] += s, d[0] = this.h[0] + 5, s = d[0] >>> 13, d[0] &= 8191, v = 1; v < 10; v++)
        d[v] = this.h[v] + s, s = d[v] >>> 13, d[v] &= 8191;
      for (d[9] -= 8192, A = (s ^ 1) - 1, v = 0; v < 10; v++)
        d[v] &= A;
      for (A = ~A, v = 0; v < 10; v++)
        this.h[v] = this.h[v] & A | d[v];
      for (this.h[0] = (this.h[0] | this.h[1] << 13) & 65535, this.h[1] = (this.h[1] >>> 3 | this.h[2] << 10) & 65535, this.h[2] = (this.h[2] >>> 6 | this.h[3] << 7) & 65535, this.h[3] = (this.h[3] >>> 9 | this.h[4] << 4) & 65535, this.h[4] = (this.h[4] >>> 12 | this.h[5] << 1 | this.h[6] << 14) & 65535, this.h[5] = (this.h[6] >>> 2 | this.h[7] << 11) & 65535, this.h[6] = (this.h[7] >>> 5 | this.h[8] << 8) & 65535, this.h[7] = (this.h[8] >>> 8 | this.h[9] << 5) & 65535, E = this.h[0] + this.pad[0], this.h[0] = E & 65535, v = 1; v < 8; v++)
        E = (this.h[v] + this.pad[v] | 0) + (E >>> 16) | 0, this.h[v] = E & 65535;
      l[p + 0] = this.h[0] >>> 0 & 255, l[p + 1] = this.h[0] >>> 8 & 255, l[p + 2] = this.h[1] >>> 0 & 255, l[p + 3] = this.h[1] >>> 8 & 255, l[p + 4] = this.h[2] >>> 0 & 255, l[p + 5] = this.h[2] >>> 8 & 255, l[p + 6] = this.h[3] >>> 0 & 255, l[p + 7] = this.h[3] >>> 8 & 255, l[p + 8] = this.h[4] >>> 0 & 255, l[p + 9] = this.h[4] >>> 8 & 255, l[p + 10] = this.h[5] >>> 0 & 255, l[p + 11] = this.h[5] >>> 8 & 255, l[p + 12] = this.h[6] >>> 0 & 255, l[p + 13] = this.h[6] >>> 8 & 255, l[p + 14] = this.h[7] >>> 0 & 255, l[p + 15] = this.h[7] >>> 8 & 255;
    }, bt.prototype.update = function(l, p, d) {
      var s, A;
      if (this.leftover) {
        for (A = 16 - this.leftover, A > d && (A = d), s = 0; s < A; s++)
          this.buffer[this.leftover + s] = l[p + s];
        if (d -= A, p += A, this.leftover += A, this.leftover < 16)
          return;
        this.blocks(this.buffer, 0, 16), this.leftover = 0;
      }
      if (d >= 16 && (A = d - d % 16, this.blocks(l, p, A), p += A, d -= A), d) {
        for (s = 0; s < d; s++)
          this.buffer[this.leftover + s] = l[p + s];
        this.leftover += d;
      }
    };
    function Et(l, p, d, s, A, E) {
      var v = new bt(E);
      return v.update(d, s, A), v.finish(l, p), 0;
    }
    function qt(l, p, d, s, A, E) {
      var v = new Uint8Array(16);
      return Et(v, 0, d, s, A, E), M(l, p, v, 0);
    }
    function Qt(l, p, d, s, A) {
      var E;
      if (d < 32)
        return -1;
      for (mt(l, 0, p, 0, d, s, A), Et(l, 16, l, 32, d - 32, l), E = 0; E < 16; E++)
        l[E] = 0;
      return 0;
    }
    function Ut(l, p, d, s, A) {
      var E, v = new Uint8Array(32);
      if (d < 32 || (it(v, 0, 32, s, A), qt(p, 16, p, 32, d - 32, v) !== 0))
        return -1;
      for (mt(l, 0, p, 0, d, s, A), E = 0; E < 32; E++)
        l[E] = 0;
      return 0;
    }
    function yt(l, p) {
      var d;
      for (d = 0; d < 16; d++)
        l[d] = p[d] | 0;
    }
    function qn(l) {
      var p, d, s = 1;
      for (p = 0; p < 16; p++)
        d = l[p] + s + 65535, s = Math.floor(d / 65536), l[p] = d - s * 65536;
      l[0] += s - 1 + 37 * (s - 1);
    }
    function jt(l, p, d) {
      for (var s, A = ~(d - 1), E = 0; E < 16; E++)
        s = A & (l[E] ^ p[E]), l[E] ^= s, p[E] ^= s;
    }
    function Gt(l, p) {
      var d, s, A, E = n(), v = n();
      for (d = 0; d < 16; d++)
        v[d] = p[d];
      for (qn(v), qn(v), qn(v), s = 0; s < 2; s++) {
        for (E[0] = v[0] - 65517, d = 1; d < 15; d++)
          E[d] = v[d] - 65535 - (E[d - 1] >> 16 & 1), E[d - 1] &= 65535;
        E[15] = v[15] - 32767 - (E[14] >> 16 & 1), A = E[15] >> 16 & 1, E[14] &= 65535, jt(v, E, 1 - A);
      }
      for (d = 0; d < 16; d++)
        l[2 * d] = v[d] & 255, l[2 * d + 1] = v[d] >> 8;
    }
    function br(l, p) {
      var d = new Uint8Array(32), s = new Uint8Array(32);
      return Gt(d, l), Gt(s, p), Z(d, 0, s, 0);
    }
    function Me(l) {
      var p = new Uint8Array(32);
      return Gt(p, l), p[0] & 1;
    }
    function Ge(l, p) {
      var d;
      for (d = 0; d < 16; d++)
        l[d] = p[2 * d] + (p[2 * d + 1] << 8);
      l[15] &= 32767;
    }
    function st(l, p, d) {
      for (var s = 0; s < 16; s++)
        l[s] = p[s] + d[s];
    }
    function ot(l, p, d) {
      for (var s = 0; s < 16; s++)
        l[s] = p[s] - d[s];
    }
    function ye(l, p, d) {
      var s, A, E = 0, v = 0, O = 0, L = 0, Y = 0, $ = 0, me = 0, j = 0, ee = 0, ne = 0, ce = 0, ae = 0, re = 0, se = 0, ie = 0, G = 0, V = 0, q = 0, W = 0, K = 0, H = 0, B = 0, S = 0, F = 0, P = 0, R = 0, D = 0, X = 0, ue = 0, le = 0, fe = 0, x = d[0], Ae = d[1], be = d[2], Ee = d[3], de = d[4], we = d[5], ge = d[6], He = d[7], Ie = d[8], ze = d[9], Fe = d[10], De = d[11], je = d[12], Ve = d[13], Je = d[14], Xe = d[15];
      s = p[0], E += s * x, v += s * Ae, O += s * be, L += s * Ee, Y += s * de, $ += s * we, me += s * ge, j += s * He, ee += s * Ie, ne += s * ze, ce += s * Fe, ae += s * De, re += s * je, se += s * Ve, ie += s * Je, G += s * Xe, s = p[1], v += s * x, O += s * Ae, L += s * be, Y += s * Ee, $ += s * de, me += s * we, j += s * ge, ee += s * He, ne += s * Ie, ce += s * ze, ae += s * Fe, re += s * De, se += s * je, ie += s * Ve, G += s * Je, V += s * Xe, s = p[2], O += s * x, L += s * Ae, Y += s * be, $ += s * Ee, me += s * de, j += s * we, ee += s * ge, ne += s * He, ce += s * Ie, ae += s * ze, re += s * Fe, se += s * De, ie += s * je, G += s * Ve, V += s * Je, q += s * Xe, s = p[3], L += s * x, Y += s * Ae, $ += s * be, me += s * Ee, j += s * de, ee += s * we, ne += s * ge, ce += s * He, ae += s * Ie, re += s * ze, se += s * Fe, ie += s * De, G += s * je, V += s * Ve, q += s * Je, W += s * Xe, s = p[4], Y += s * x, $ += s * Ae, me += s * be, j += s * Ee, ee += s * de, ne += s * we, ce += s * ge, ae += s * He, re += s * Ie, se += s * ze, ie += s * Fe, G += s * De, V += s * je, q += s * Ve, W += s * Je, K += s * Xe, s = p[5], $ += s * x, me += s * Ae, j += s * be, ee += s * Ee, ne += s * de, ce += s * we, ae += s * ge, re += s * He, se += s * Ie, ie += s * ze, G += s * Fe, V += s * De, q += s * je, W += s * Ve, K += s * Je, H += s * Xe, s = p[6], me += s * x, j += s * Ae, ee += s * be, ne += s * Ee, ce += s * de, ae += s * we, re += s * ge, se += s * He, ie += s * Ie, G += s * ze, V += s * Fe, q += s * De, W += s * je, K += s * Ve, H += s * Je, B += s * Xe, s = p[7], j += s * x, ee += s * Ae, ne += s * be, ce += s * Ee, ae += s * de, re += s * we, se += s * ge, ie += s * He, G += s * Ie, V += s * ze, q += s * Fe, W += s * De, K += s * je, H += s * Ve, B += s * Je, S += s * Xe, s = p[8], ee += s * x, ne += s * Ae, ce += s * be, ae += s * Ee, re += s * de, se += s * we, ie += s * ge, G += s * He, V += s * Ie, q += s * ze, W += s * Fe, K += s * De, H += s * je, B += s * Ve, S += s * Je, F += s * Xe, s = p[9], ne += s * x, ce += s * Ae, ae += s * be, re += s * Ee, se += s * de, ie += s * we, G += s * ge, V += s * He, q += s * Ie, W += s * ze, K += s * Fe, H += s * De, B += s * je, S += s * Ve, F += s * Je, P += s * Xe, s = p[10], ce += s * x, ae += s * Ae, re += s * be, se += s * Ee, ie += s * de, G += s * we, V += s * ge, q += s * He, W += s * Ie, K += s * ze, H += s * Fe, B += s * De, S += s * je, F += s * Ve, P += s * Je, R += s * Xe, s = p[11], ae += s * x, re += s * Ae, se += s * be, ie += s * Ee, G += s * de, V += s * we, q += s * ge, W += s * He, K += s * Ie, H += s * ze, B += s * Fe, S += s * De, F += s * je, P += s * Ve, R += s * Je, D += s * Xe, s = p[12], re += s * x, se += s * Ae, ie += s * be, G += s * Ee, V += s * de, q += s * we, W += s * ge, K += s * He, H += s * Ie, B += s * ze, S += s * Fe, F += s * De, P += s * je, R += s * Ve, D += s * Je, X += s * Xe, s = p[13], se += s * x, ie += s * Ae, G += s * be, V += s * Ee, q += s * de, W += s * we, K += s * ge, H += s * He, B += s * Ie, S += s * ze, F += s * Fe, P += s * De, R += s * je, D += s * Ve, X += s * Je, ue += s * Xe, s = p[14], ie += s * x, G += s * Ae, V += s * be, q += s * Ee, W += s * de, K += s * we, H += s * ge, B += s * He, S += s * Ie, F += s * ze, P += s * Fe, R += s * De, D += s * je, X += s * Ve, ue += s * Je, le += s * Xe, s = p[15], G += s * x, V += s * Ae, q += s * be, W += s * Ee, K += s * de, H += s * we, B += s * ge, S += s * He, F += s * Ie, P += s * ze, R += s * Fe, D += s * De, X += s * je, ue += s * Ve, le += s * Je, fe += s * Xe, E += 38 * V, v += 38 * q, O += 38 * W, L += 38 * K, Y += 38 * H, $ += 38 * B, me += 38 * S, j += 38 * F, ee += 38 * P, ne += 38 * R, ce += 38 * D, ae += 38 * X, re += 38 * ue, se += 38 * le, ie += 38 * fe, A = 1, s = E + A + 65535, A = Math.floor(s / 65536), E = s - A * 65536, s = v + A + 65535, A = Math.floor(s / 65536), v = s - A * 65536, s = O + A + 65535, A = Math.floor(s / 65536), O = s - A * 65536, s = L + A + 65535, A = Math.floor(s / 65536), L = s - A * 65536, s = Y + A + 65535, A = Math.floor(s / 65536), Y = s - A * 65536, s = $ + A + 65535, A = Math.floor(s / 65536), $ = s - A * 65536, s = me + A + 65535, A = Math.floor(s / 65536), me = s - A * 65536, s = j + A + 65535, A = Math.floor(s / 65536), j = s - A * 65536, s = ee + A + 65535, A = Math.floor(s / 65536), ee = s - A * 65536, s = ne + A + 65535, A = Math.floor(s / 65536), ne = s - A * 65536, s = ce + A + 65535, A = Math.floor(s / 65536), ce = s - A * 65536, s = ae + A + 65535, A = Math.floor(s / 65536), ae = s - A * 65536, s = re + A + 65535, A = Math.floor(s / 65536), re = s - A * 65536, s = se + A + 65535, A = Math.floor(s / 65536), se = s - A * 65536, s = ie + A + 65535, A = Math.floor(s / 65536), ie = s - A * 65536, s = G + A + 65535, A = Math.floor(s / 65536), G = s - A * 65536, E += A - 1 + 37 * (A - 1), A = 1, s = E + A + 65535, A = Math.floor(s / 65536), E = s - A * 65536, s = v + A + 65535, A = Math.floor(s / 65536), v = s - A * 65536, s = O + A + 65535, A = Math.floor(s / 65536), O = s - A * 65536, s = L + A + 65535, A = Math.floor(s / 65536), L = s - A * 65536, s = Y + A + 65535, A = Math.floor(s / 65536), Y = s - A * 65536, s = $ + A + 65535, A = Math.floor(s / 65536), $ = s - A * 65536, s = me + A + 65535, A = Math.floor(s / 65536), me = s - A * 65536, s = j + A + 65535, A = Math.floor(s / 65536), j = s - A * 65536, s = ee + A + 65535, A = Math.floor(s / 65536), ee = s - A * 65536, s = ne + A + 65535, A = Math.floor(s / 65536), ne = s - A * 65536, s = ce + A + 65535, A = Math.floor(s / 65536), ce = s - A * 65536, s = ae + A + 65535, A = Math.floor(s / 65536), ae = s - A * 65536, s = re + A + 65535, A = Math.floor(s / 65536), re = s - A * 65536, s = se + A + 65535, A = Math.floor(s / 65536), se = s - A * 65536, s = ie + A + 65535, A = Math.floor(s / 65536), ie = s - A * 65536, s = G + A + 65535, A = Math.floor(s / 65536), G = s - A * 65536, E += A - 1 + 37 * (A - 1), l[0] = E, l[1] = v, l[2] = O, l[3] = L, l[4] = Y, l[5] = $, l[6] = me, l[7] = j, l[8] = ee, l[9] = ne, l[10] = ce, l[11] = ae, l[12] = re, l[13] = se, l[14] = ie, l[15] = G;
    }
    function et(l, p) {
      ye(l, p, p);
    }
    function Qn(l, p) {
      var d = n(), s;
      for (s = 0; s < 16; s++)
        d[s] = p[s];
      for (s = 253; s >= 0; s--)
        et(d, d), s !== 2 && s !== 4 && ye(d, d, p);
      for (s = 0; s < 16; s++)
        l[s] = d[s];
    }
    function Ct(l, p) {
      var d = n(), s;
      for (s = 0; s < 16; s++)
        d[s] = p[s];
      for (s = 250; s >= 0; s--)
        et(d, d), s !== 1 && ye(d, d, p);
      for (s = 0; s < 16; s++)
        l[s] = d[s];
    }
    function Wt(l, p, d) {
      var s = new Uint8Array(32), A = new Float64Array(80), E, v, O = n(), L = n(), Y = n(), $ = n(), me = n(), j = n();
      for (v = 0; v < 31; v++)
        s[v] = p[v];
      for (s[31] = p[31] & 127 | 64, s[0] &= 248, Ge(A, d), v = 0; v < 16; v++)
        L[v] = A[v], $[v] = O[v] = Y[v] = 0;
      for (O[0] = $[0] = 1, v = 254; v >= 0; --v)
        E = s[v >>> 3] >>> (v & 7) & 1, jt(O, L, E), jt(Y, $, E), st(me, O, Y), ot(O, O, Y), st(Y, L, $), ot(L, L, $), et($, me), et(j, O), ye(O, Y, O), ye(Y, L, me), st(me, O, Y), ot(O, O, Y), et(L, O), ot(Y, $, j), ye(O, Y, y), st(O, O, $), ye(Y, Y, O), ye(O, $, j), ye($, L, A), et(L, me), jt(O, L, E), jt(Y, $, E);
      for (v = 0; v < 16; v++)
        A[v + 16] = O[v], A[v + 32] = Y[v], A[v + 48] = L[v], A[v + 64] = $[v];
      var ee = A.subarray(32), ne = A.subarray(16);
      return Qn(ee, ee), ye(ne, ne, ee), Gt(l, ne), 0;
    }
    function sn(l, p) {
      return Wt(l, p, o);
    }
    function Er(l, p) {
      return r(p, 32), sn(l, p);
    }
    function on(l, p, d) {
      var s = new Uint8Array(32);
      return Wt(s, d, p), Ce(l, i, s, nt);
    }
    var Pt = Qt, an = Ut;
    function Gi(l, p, d, s, A, E) {
      var v = new Uint8Array(32);
      return on(v, A, E), Pt(l, p, d, s, v);
    }
    function Wi(l, p, d, s, A, E) {
      var v = new Uint8Array(32);
      return on(v, A, E), an(l, p, d, s, v);
    }
    var xn = [
      1116352408,
      3609767458,
      1899447441,
      602891725,
      3049323471,
      3964484399,
      3921009573,
      2173295548,
      961987163,
      4081628472,
      1508970993,
      3053834265,
      2453635748,
      2937671579,
      2870763221,
      3664609560,
      3624381080,
      2734883394,
      310598401,
      1164996542,
      607225278,
      1323610764,
      1426881987,
      3590304994,
      1925078388,
      4068182383,
      2162078206,
      991336113,
      2614888103,
      633803317,
      3248222580,
      3479774868,
      3835390401,
      2666613458,
      4022224774,
      944711139,
      264347078,
      2341262773,
      604807628,
      2007800933,
      770255983,
      1495990901,
      1249150122,
      1856431235,
      1555081692,
      3175218132,
      1996064986,
      2198950837,
      2554220882,
      3999719339,
      2821834349,
      766784016,
      2952996808,
      2566594879,
      3210313671,
      3203337956,
      3336571891,
      1034457026,
      3584528711,
      2466948901,
      113926993,
      3758326383,
      338241895,
      168717936,
      666307205,
      1188179964,
      773529912,
      1546045734,
      1294757372,
      1522805485,
      1396182291,
      2643833823,
      1695183700,
      2343527390,
      1986661051,
      1014477480,
      2177026350,
      1206759142,
      2456956037,
      344077627,
      2730485921,
      1290863460,
      2820302411,
      3158454273,
      3259730800,
      3505952657,
      3345764771,
      106217008,
      3516065817,
      3606008344,
      3600352804,
      1432725776,
      4094571909,
      1467031594,
      275423344,
      851169720,
      430227734,
      3100823752,
      506948616,
      1363258195,
      659060556,
      3750685593,
      883997877,
      3785050280,
      958139571,
      3318307427,
      1322822218,
      3812723403,
      1537002063,
      2003034995,
      1747873779,
      3602036899,
      1955562222,
      1575990012,
      2024104815,
      1125592928,
      2227730452,
      2716904306,
      2361852424,
      442776044,
      2428436474,
      593698344,
      2756734187,
      3733110249,
      3204031479,
      2999351573,
      3329325298,
      3815920427,
      3391569614,
      3928383900,
      3515267271,
      566280711,
      3940187606,
      3454069534,
      4118630271,
      4000239992,
      116418474,
      1914138554,
      174292421,
      2731055270,
      289380356,
      3203993006,
      460393269,
      320620315,
      685471733,
      587496836,
      852142971,
      1086792851,
      1017036298,
      365543100,
      1126000580,
      2618297676,
      1288033470,
      3409855158,
      1501505948,
      4234509866,
      1607167915,
      987167468,
      1816402316,
      1246189591
    ];
    function vr(l, p, d, s) {
      for (var A = new Int32Array(16), E = new Int32Array(16), v, O, L, Y, $, me, j, ee, ne, ce, ae, re, se, ie, G, V, q, W, K, H, B, S, F, P, R, D, X = l[0], ue = l[1], le = l[2], fe = l[3], x = l[4], Ae = l[5], be = l[6], Ee = l[7], de = p[0], we = p[1], ge = p[2], He = p[3], Ie = p[4], ze = p[5], Fe = p[6], De = p[7], je = 0; s >= 128; ) {
        for (K = 0; K < 16; K++)
          H = 8 * K + je, A[K] = d[H + 0] << 24 | d[H + 1] << 16 | d[H + 2] << 8 | d[H + 3], E[K] = d[H + 4] << 24 | d[H + 5] << 16 | d[H + 6] << 8 | d[H + 7];
        for (K = 0; K < 80; K++)
          if (v = X, O = ue, L = le, Y = fe, $ = x, me = Ae, j = be, ee = Ee, ne = de, ce = we, ae = ge, re = He, se = Ie, ie = ze, G = Fe, V = De, B = Ee, S = De, F = S & 65535, P = S >>> 16, R = B & 65535, D = B >>> 16, B = (x >>> 14 | Ie << 18) ^ (x >>> 18 | Ie << 14) ^ (Ie >>> 9 | x << 23), S = (Ie >>> 14 | x << 18) ^ (Ie >>> 18 | x << 14) ^ (x >>> 9 | Ie << 23), F += S & 65535, P += S >>> 16, R += B & 65535, D += B >>> 16, B = x & Ae ^ ~x & be, S = Ie & ze ^ ~Ie & Fe, F += S & 65535, P += S >>> 16, R += B & 65535, D += B >>> 16, B = xn[K * 2], S = xn[K * 2 + 1], F += S & 65535, P += S >>> 16, R += B & 65535, D += B >>> 16, B = A[K % 16], S = E[K % 16], F += S & 65535, P += S >>> 16, R += B & 65535, D += B >>> 16, P += F >>> 16, R += P >>> 16, D += R >>> 16, q = R & 65535 | D << 16, W = F & 65535 | P << 16, B = q, S = W, F = S & 65535, P = S >>> 16, R = B & 65535, D = B >>> 16, B = (X >>> 28 | de << 4) ^ (de >>> 2 | X << 30) ^ (de >>> 7 | X << 25), S = (de >>> 28 | X << 4) ^ (X >>> 2 | de << 30) ^ (X >>> 7 | de << 25), F += S & 65535, P += S >>> 16, R += B & 65535, D += B >>> 16, B = X & ue ^ X & le ^ ue & le, S = de & we ^ de & ge ^ we & ge, F += S & 65535, P += S >>> 16, R += B & 65535, D += B >>> 16, P += F >>> 16, R += P >>> 16, D += R >>> 16, ee = R & 65535 | D << 16, V = F & 65535 | P << 16, B = Y, S = re, F = S & 65535, P = S >>> 16, R = B & 65535, D = B >>> 16, B = q, S = W, F += S & 65535, P += S >>> 16, R += B & 65535, D += B >>> 16, P += F >>> 16, R += P >>> 16, D += R >>> 16, Y = R & 65535 | D << 16, re = F & 65535 | P << 16, ue = v, le = O, fe = L, x = Y, Ae = $, be = me, Ee = j, X = ee, we = ne, ge = ce, He = ae, Ie = re, ze = se, Fe = ie, De = G, de = V, K % 16 === 15)
            for (H = 0; H < 16; H++)
              B = A[H], S = E[H], F = S & 65535, P = S >>> 16, R = B & 65535, D = B >>> 16, B = A[(H + 9) % 16], S = E[(H + 9) % 16], F += S & 65535, P += S >>> 16, R += B & 65535, D += B >>> 16, q = A[(H + 1) % 16], W = E[(H + 1) % 16], B = (q >>> 1 | W << 31) ^ (q >>> 8 | W << 24) ^ q >>> 7, S = (W >>> 1 | q << 31) ^ (W >>> 8 | q << 24) ^ (W >>> 7 | q << 25), F += S & 65535, P += S >>> 16, R += B & 65535, D += B >>> 16, q = A[(H + 14) % 16], W = E[(H + 14) % 16], B = (q >>> 19 | W << 13) ^ (W >>> 29 | q << 3) ^ q >>> 6, S = (W >>> 19 | q << 13) ^ (q >>> 29 | W << 3) ^ (W >>> 6 | q << 26), F += S & 65535, P += S >>> 16, R += B & 65535, D += B >>> 16, P += F >>> 16, R += P >>> 16, D += R >>> 16, A[H] = R & 65535 | D << 16, E[H] = F & 65535 | P << 16;
        B = X, S = de, F = S & 65535, P = S >>> 16, R = B & 65535, D = B >>> 16, B = l[0], S = p[0], F += S & 65535, P += S >>> 16, R += B & 65535, D += B >>> 16, P += F >>> 16, R += P >>> 16, D += R >>> 16, l[0] = X = R & 65535 | D << 16, p[0] = de = F & 65535 | P << 16, B = ue, S = we, F = S & 65535, P = S >>> 16, R = B & 65535, D = B >>> 16, B = l[1], S = p[1], F += S & 65535, P += S >>> 16, R += B & 65535, D += B >>> 16, P += F >>> 16, R += P >>> 16, D += R >>> 16, l[1] = ue = R & 65535 | D << 16, p[1] = we = F & 65535 | P << 16, B = le, S = ge, F = S & 65535, P = S >>> 16, R = B & 65535, D = B >>> 16, B = l[2], S = p[2], F += S & 65535, P += S >>> 16, R += B & 65535, D += B >>> 16, P += F >>> 16, R += P >>> 16, D += R >>> 16, l[2] = le = R & 65535 | D << 16, p[2] = ge = F & 65535 | P << 16, B = fe, S = He, F = S & 65535, P = S >>> 16, R = B & 65535, D = B >>> 16, B = l[3], S = p[3], F += S & 65535, P += S >>> 16, R += B & 65535, D += B >>> 16, P += F >>> 16, R += P >>> 16, D += R >>> 16, l[3] = fe = R & 65535 | D << 16, p[3] = He = F & 65535 | P << 16, B = x, S = Ie, F = S & 65535, P = S >>> 16, R = B & 65535, D = B >>> 16, B = l[4], S = p[4], F += S & 65535, P += S >>> 16, R += B & 65535, D += B >>> 16, P += F >>> 16, R += P >>> 16, D += R >>> 16, l[4] = x = R & 65535 | D << 16, p[4] = Ie = F & 65535 | P << 16, B = Ae, S = ze, F = S & 65535, P = S >>> 16, R = B & 65535, D = B >>> 16, B = l[5], S = p[5], F += S & 65535, P += S >>> 16, R += B & 65535, D += B >>> 16, P += F >>> 16, R += P >>> 16, D += R >>> 16, l[5] = Ae = R & 65535 | D << 16, p[5] = ze = F & 65535 | P << 16, B = be, S = Fe, F = S & 65535, P = S >>> 16, R = B & 65535, D = B >>> 16, B = l[6], S = p[6], F += S & 65535, P += S >>> 16, R += B & 65535, D += B >>> 16, P += F >>> 16, R += P >>> 16, D += R >>> 16, l[6] = be = R & 65535 | D << 16, p[6] = Fe = F & 65535 | P << 16, B = Ee, S = De, F = S & 65535, P = S >>> 16, R = B & 65535, D = B >>> 16, B = l[7], S = p[7], F += S & 65535, P += S >>> 16, R += B & 65535, D += B >>> 16, P += F >>> 16, R += P >>> 16, D += R >>> 16, l[7] = Ee = R & 65535 | D << 16, p[7] = De = F & 65535 | P << 16, je += 128, s -= 128;
      }
      return s;
    }
    function Ot(l, p, d) {
      var s = new Int32Array(8), A = new Int32Array(8), E = new Uint8Array(256), v, O = d;
      for (s[0] = 1779033703, s[1] = 3144134277, s[2] = 1013904242, s[3] = 2773480762, s[4] = 1359893119, s[5] = 2600822924, s[6] = 528734635, s[7] = 1541459225, A[0] = 4089235720, A[1] = 2227873595, A[2] = 4271175723, A[3] = 1595750129, A[4] = 2917565137, A[5] = 725511199, A[6] = 4215389547, A[7] = 327033209, vr(s, A, p, d), d %= 128, v = 0; v < d; v++)
        E[v] = p[O - d + v];
      for (E[d] = 128, d = 256 - 128 * (d < 112 ? 1 : 0), E[d - 9] = 0, k(E, d - 8, O / 536870912 | 0, O << 3), vr(s, A, E, d), v = 0; v < 8; v++)
        k(l, 8 * v, s[v], A[v]);
      return 0;
    }
    function cn(l, p) {
      var d = n(), s = n(), A = n(), E = n(), v = n(), O = n(), L = n(), Y = n(), $ = n();
      ot(d, l[1], l[0]), ot($, p[1], p[0]), ye(d, d, $), st(s, l[0], l[1]), st($, p[0], p[1]), ye(s, s, $), ye(A, l[3], p[3]), ye(A, A, _), ye(E, l[2], p[2]), st(E, E, E), ot(v, s, d), ot(O, E, A), st(L, E, A), st(Y, s, d), ye(l[0], v, O), ye(l[1], Y, L), ye(l[2], L, O), ye(l[3], v, Y);
    }
    function un(l, p, d) {
      var s;
      for (s = 0; s < 4; s++)
        jt(l[s], p[s], d);
    }
    function at(l, p) {
      var d = n(), s = n(), A = n();
      Qn(A, p[2]), ye(d, p[0], A), ye(s, p[1], A), Gt(l, s), l[31] ^= Me(d) << 7;
    }
    function fn(l, p, d) {
      var s, A;
      for (yt(l[0], c), yt(l[1], f), yt(l[2], f), yt(l[3], c), A = 255; A >= 0; --A)
        s = d[A / 8 | 0] >> (A & 7) & 1, un(l, p, s), cn(p, l), cn(l, l), un(l, p, s);
    }
    function _n(l, p) {
      var d = [n(), n(), n(), n()];
      yt(d[0], m), yt(d[1], I), yt(d[2], f), ye(d[3], m, I), fn(l, d, p);
    }
    function dt(l, p, d) {
      var s = new Uint8Array(64), A = [n(), n(), n(), n()], E;
      for (d || r(p, 32), Ot(s, p, 32), s[0] &= 248, s[31] &= 127, s[31] |= 64, _n(A, s), at(l, A), E = 0; E < 32; E++)
        p[E + 32] = l[E];
      return 0;
    }
    var mn = new Float64Array([237, 211, 245, 92, 26, 99, 18, 88, 214, 156, 247, 162, 222, 249, 222, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16]);
    function h(l, p) {
      var d, s, A, E;
      for (s = 63; s >= 32; --s) {
        for (d = 0, A = s - 32, E = s - 12; A < E; ++A)
          p[A] += d - 16 * p[s] * mn[A - (s - 32)], d = Math.floor((p[A] + 128) / 256), p[A] -= d * 256;
        p[A] += d, p[s] = 0;
      }
      for (d = 0, A = 0; A < 32; A++)
        p[A] += d - (p[31] >> 4) * mn[A], d = p[A] >> 8, p[A] &= 255;
      for (A = 0; A < 32; A++)
        p[A] -= d * mn[A];
      for (s = 0; s < 32; s++)
        p[s + 1] += p[s] >> 8, l[s] = p[s] & 255;
    }
    function a(l) {
      var p = new Float64Array(64), d;
      for (d = 0; d < 64; d++)
        p[d] = l[d];
      for (d = 0; d < 64; d++)
        l[d] = 0;
      h(l, p);
    }
    function u(l, p, d, s) {
      var A = new Uint8Array(64), E = new Uint8Array(64), v = new Uint8Array(64), O, L, Y = new Float64Array(64), $ = [n(), n(), n(), n()];
      Ot(A, s, 32), A[0] &= 248, A[31] &= 127, A[31] |= 64;
      var me = d + 64;
      for (O = 0; O < d; O++)
        l[64 + O] = p[O];
      for (O = 0; O < 32; O++)
        l[32 + O] = A[32 + O];
      for (Ot(v, l.subarray(32), d + 32), a(v), _n($, v), at(l, $), O = 32; O < 64; O++)
        l[O] = s[O];
      for (Ot(E, l, d + 64), a(E), O = 0; O < 64; O++)
        Y[O] = 0;
      for (O = 0; O < 32; O++)
        Y[O] = v[O];
      for (O = 0; O < 32; O++)
        for (L = 0; L < 32; L++)
          Y[O + L] += E[O] * A[L];
      return h(l.subarray(32), Y), me;
    }
    function g(l, p) {
      var d = n(), s = n(), A = n(), E = n(), v = n(), O = n(), L = n();
      return yt(l[2], f), Ge(l[1], p), et(A, l[1]), ye(E, A, w), ot(A, A, l[2]), st(E, l[2], E), et(v, E), et(O, v), ye(L, O, v), ye(d, L, A), ye(d, d, E), Ct(d, d), ye(d, d, A), ye(d, d, E), ye(d, d, E), ye(l[0], d, E), et(s, l[0]), ye(s, s, E), br(s, A) && ye(l[0], l[0], z), et(s, l[0]), ye(s, s, E), br(s, A) ? -1 : (Me(l[0]) === p[31] >> 7 && ot(l[0], c, l[0]), ye(l[3], l[0], l[1]), 0);
    }
    function b(l, p, d, s) {
      var A, E = new Uint8Array(32), v = new Uint8Array(64), O = [n(), n(), n(), n()], L = [n(), n(), n(), n()];
      if (d < 64 || g(L, s))
        return -1;
      for (A = 0; A < d; A++)
        l[A] = p[A];
      for (A = 0; A < 32; A++)
        l[A + 32] = s[A];
      if (Ot(v, l, d), a(v), fn(O, L, v), _n(L, p.subarray(32)), cn(O, L), at(E, O), d -= 64, Z(p, 0, E, 0)) {
        for (A = 0; A < d; A++)
          l[A] = 0;
        return -1;
      }
      for (A = 0; A < d; A++)
        l[A] = p[A + 64];
      return d;
    }
    var T = 32, U = 24, oe = 32, Se = 16, Te = 32, Pe = 32, _e = 32, jn = 32, Ki = 32, yo = U, Xu = oe, Zu = Se, Rt = 64, ln = 32, bn = 64, Yi = 32, Vi = 64;
    e.lowlevel = {
      crypto_core_hsalsa20: Ce,
      crypto_stream_xor: mt,
      crypto_stream: it,
      crypto_stream_salsa20_xor: It,
      crypto_stream_salsa20: rt,
      crypto_onetimeauth: Et,
      crypto_onetimeauth_verify: qt,
      crypto_verify_16: M,
      crypto_verify_32: Z,
      crypto_secretbox: Qt,
      crypto_secretbox_open: Ut,
      crypto_scalarmult: Wt,
      crypto_scalarmult_base: sn,
      crypto_box_beforenm: on,
      crypto_box_afternm: Pt,
      crypto_box: Gi,
      crypto_box_open: Wi,
      crypto_box_keypair: Er,
      crypto_hash: Ot,
      crypto_sign: u,
      crypto_sign_keypair: dt,
      crypto_sign_open: b,
      crypto_secretbox_KEYBYTES: T,
      crypto_secretbox_NONCEBYTES: U,
      crypto_secretbox_ZEROBYTES: oe,
      crypto_secretbox_BOXZEROBYTES: Se,
      crypto_scalarmult_BYTES: Te,
      crypto_scalarmult_SCALARBYTES: Pe,
      crypto_box_PUBLICKEYBYTES: _e,
      crypto_box_SECRETKEYBYTES: jn,
      crypto_box_BEFORENMBYTES: Ki,
      crypto_box_NONCEBYTES: yo,
      crypto_box_ZEROBYTES: Xu,
      crypto_box_BOXZEROBYTES: Zu,
      crypto_sign_BYTES: Rt,
      crypto_sign_PUBLICKEYBYTES: ln,
      crypto_sign_SECRETKEYBYTES: bn,
      crypto_sign_SEEDBYTES: Yi,
      crypto_hash_BYTES: Vi,
      gf: n,
      D: w,
      L: mn,
      pack25519: Gt,
      unpack25519: Ge,
      M: ye,
      A: st,
      S: et,
      Z: ot,
      pow2523: Ct,
      add: cn,
      set25519: yt,
      modL: h,
      scalarmult: fn,
      scalarbase: _n
    };
    function wo(l, p) {
      if (l.length !== T)
        throw new Error("bad key size");
      if (p.length !== U)
        throw new Error("bad nonce size");
    }
    function ef(l, p) {
      if (l.length !== _e)
        throw new Error("bad public key size");
      if (p.length !== jn)
        throw new Error("bad secret key size");
    }
    function ft() {
      for (var l = 0; l < arguments.length; l++)
        if (!(arguments[l] instanceof Uint8Array))
          throw new TypeError("unexpected type, use Uint8Array");
    }
    function go(l) {
      for (var p = 0; p < l.length; p++)
        l[p] = 0;
    }
    e.randomBytes = function(l) {
      var p = new Uint8Array(l);
      return r(p, l), p;
    }, e.secretbox = function(l, p, d) {
      ft(l, p, d), wo(d, p);
      for (var s = new Uint8Array(oe + l.length), A = new Uint8Array(s.length), E = 0; E < l.length; E++)
        s[E + oe] = l[E];
      return Qt(A, s, s.length, p, d), A.subarray(Se);
    }, e.secretbox.open = function(l, p, d) {
      ft(l, p, d), wo(d, p);
      for (var s = new Uint8Array(Se + l.length), A = new Uint8Array(s.length), E = 0; E < l.length; E++)
        s[E + Se] = l[E];
      return s.length < 32 || Ut(A, s, s.length, p, d) !== 0 ? null : A.subarray(oe);
    }, e.secretbox.keyLength = T, e.secretbox.nonceLength = U, e.secretbox.overheadLength = Se, e.scalarMult = function(l, p) {
      if (ft(l, p), l.length !== Pe)
        throw new Error("bad n size");
      if (p.length !== Te)
        throw new Error("bad p size");
      var d = new Uint8Array(Te);
      return Wt(d, l, p), d;
    }, e.scalarMult.base = function(l) {
      if (ft(l), l.length !== Pe)
        throw new Error("bad n size");
      var p = new Uint8Array(Te);
      return sn(p, l), p;
    }, e.scalarMult.scalarLength = Pe, e.scalarMult.groupElementLength = Te, e.box = function(l, p, d, s) {
      var A = e.box.before(d, s);
      return e.secretbox(l, p, A);
    }, e.box.before = function(l, p) {
      ft(l, p), ef(l, p);
      var d = new Uint8Array(Ki);
      return on(d, l, p), d;
    }, e.box.after = e.secretbox, e.box.open = function(l, p, d, s) {
      var A = e.box.before(d, s);
      return e.secretbox.open(l, p, A);
    }, e.box.open.after = e.secretbox.open, e.box.keyPair = function() {
      var l = new Uint8Array(_e), p = new Uint8Array(jn);
      return Er(l, p), { publicKey: l, secretKey: p };
    }, e.box.keyPair.fromSecretKey = function(l) {
      if (ft(l), l.length !== jn)
        throw new Error("bad secret key size");
      var p = new Uint8Array(_e);
      return sn(p, l), { publicKey: p, secretKey: new Uint8Array(l) };
    }, e.box.publicKeyLength = _e, e.box.secretKeyLength = jn, e.box.sharedKeyLength = Ki, e.box.nonceLength = yo, e.box.overheadLength = e.secretbox.overheadLength, e.sign = function(l, p) {
      if (ft(l, p), p.length !== bn)
        throw new Error("bad secret key size");
      var d = new Uint8Array(Rt + l.length);
      return u(d, l, l.length, p), d;
    }, e.sign.open = function(l, p) {
      if (ft(l, p), p.length !== ln)
        throw new Error("bad public key size");
      var d = new Uint8Array(l.length), s = b(d, l, l.length, p);
      if (s < 0)
        return null;
      for (var A = new Uint8Array(s), E = 0; E < A.length; E++)
        A[E] = d[E];
      return A;
    }, e.sign.detached = function(l, p) {
      for (var d = e.sign(l, p), s = new Uint8Array(Rt), A = 0; A < s.length; A++)
        s[A] = d[A];
      return s;
    }, e.sign.detached.verify = function(l, p, d) {
      if (ft(l, p, d), p.length !== Rt)
        throw new Error("bad signature size");
      if (d.length !== ln)
        throw new Error("bad public key size");
      var s = new Uint8Array(Rt + l.length), A = new Uint8Array(Rt + l.length), E;
      for (E = 0; E < Rt; E++)
        s[E] = p[E];
      for (E = 0; E < l.length; E++)
        s[E + Rt] = l[E];
      return b(A, s, s.length, d) >= 0;
    }, e.sign.keyPair = function() {
      var l = new Uint8Array(ln), p = new Uint8Array(bn);
      return dt(l, p), { publicKey: l, secretKey: p };
    }, e.sign.keyPair.fromSecretKey = function(l) {
      if (ft(l), l.length !== bn)
        throw new Error("bad secret key size");
      for (var p = new Uint8Array(ln), d = 0; d < p.length; d++)
        p[d] = l[32 + d];
      return { publicKey: p, secretKey: new Uint8Array(l) };
    }, e.sign.keyPair.fromSeed = function(l) {
      if (ft(l), l.length !== Yi)
        throw new Error("bad seed size");
      for (var p = new Uint8Array(ln), d = new Uint8Array(bn), s = 0; s < 32; s++)
        d[s] = l[s];
      return dt(p, d, !0), { publicKey: p, secretKey: d };
    }, e.sign.publicKeyLength = ln, e.sign.secretKeyLength = bn, e.sign.seedLength = Yi, e.sign.signatureLength = Rt, e.hash = function(l) {
      ft(l);
      var p = new Uint8Array(Vi);
      return Ot(p, l, l.length), p;
    }, e.hash.hashLength = Vi, e.verify = function(l, p) {
      return ft(l, p), l.length === 0 || p.length === 0 || l.length !== p.length ? !1 : N(l, 0, p, 0, l.length) === 0;
    }, e.setPRNG = function(l) {
      r = l;
    }, function() {
      var l = typeof self < "u" ? self.crypto || self.msCrypto : null;
      if (l && l.getRandomValues) {
        var p = 65536;
        e.setPRNG(function(d, s) {
          var A, E = new Uint8Array(s);
          for (A = 0; A < s; A += p)
            l.getRandomValues(E.subarray(A, A + Math.min(s - A, p)));
          for (A = 0; A < s; A++)
            d[A] = E[A];
          go(E);
        });
      } else
        typeof ol < "u" && (l = ul, l && l.randomBytes && e.setPRNG(function(d, s) {
          var A, E = l.randomBytes(s);
          for (A = 0; A < s; A++)
            d[A] = E[A];
          go(E);
        }));
    }();
  })(t.exports ? t.exports : self.nacl = self.nacl || {});
})(wa);
var fl = wa.exports;
const Sr = /* @__PURE__ */ il(fl);
function pn(t) {
  if (!Number.isSafeInteger(t) || t < 0)
    throw new Error(`Wrong positive integer: ${t}`);
}
function ll(t) {
  return t instanceof Uint8Array || t != null && typeof t == "object" && t.constructor.name === "Uint8Array";
}
function Os(t, ...e) {
  if (!ll(t))
    throw new Error("Expected Uint8Array");
  if (e.length > 0 && !e.includes(t.length))
    throw new Error(`Expected Uint8Array of length ${e}, not of length=${t.length}`);
}
function ga(t) {
  if (typeof t != "function" || typeof t.create != "function")
    throw new Error("Hash should be wrapped by utils.wrapConstructor");
  pn(t.outputLen), pn(t.blockLen);
}
function On(t, e = !0) {
  if (t.destroyed)
    throw new Error("Hash instance has been destroyed");
  if (e && t.finished)
    throw new Error("Hash#digest() has already been called");
}
function xa(t, e) {
  Os(t);
  const n = e.outputLen;
  if (t.length < n)
    throw new Error(`digestInto() expects output buffer of length at least ${n}`);
}
/*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) */
const dl = (t) => new Uint32Array(t.buffer, t.byteOffset, Math.floor(t.byteLength / 4));
function _a(t) {
  return t instanceof Uint8Array || t != null && typeof t == "object" && t.constructor.name === "Uint8Array";
}
const zr = (t) => new DataView(t.buffer, t.byteOffset, t.byteLength), vt = (t, e) => t << 32 - e | t >>> e, hl = new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68;
if (!hl)
  throw new Error("Non little-endian hardware is not supported");
const pl = /* @__PURE__ */ Array.from({ length: 256 }, (t, e) => e.toString(16).padStart(2, "0"));
function ma(t) {
  if (!_a(t))
    throw new Error("Uint8Array expected");
  let e = "";
  for (let n = 0; n < t.length; n++)
    e += pl[t[n]];
  return e;
}
const Nt = { _0: 48, _9: 57, _A: 65, _F: 70, _a: 97, _f: 102 };
function Co(t) {
  if (t >= Nt._0 && t <= Nt._9)
    return t - Nt._0;
  if (t >= Nt._A && t <= Nt._F)
    return t - (Nt._A - 10);
  if (t >= Nt._a && t <= Nt._f)
    return t - (Nt._a - 10);
}
function ba(t) {
  if (typeof t != "string")
    throw new Error("hex string expected, got " + typeof t);
  const e = t.length, n = e / 2;
  if (e % 2)
    throw new Error("padded hex string expected, got unpadded hex of length " + e);
  const r = new Uint8Array(n);
  for (let i = 0, o = 0; i < n; i++, o += 2) {
    const c = Co(t.charCodeAt(o)), f = Co(t.charCodeAt(o + 1));
    if (c === void 0 || f === void 0) {
      const y = t[o] + t[o + 1];
      throw new Error('hex string expected, got non-hex character "' + y + '" at index ' + o);
    }
    r[i] = c * 16 + f;
  }
  return r;
}
function Al(t) {
  if (typeof t != "string")
    throw new Error(`utf8ToBytes expected string, got ${typeof t}`);
  return new Uint8Array(new TextEncoder().encode(t));
}
function Rn(t) {
  if (typeof t == "string" && (t = Al(t)), !_a(t))
    throw new Error(`expected Uint8Array, got ${typeof t}`);
  return t;
}
class Rs {
  // Safe version that clones internal state
  clone() {
    return this._cloneInto();
  }
}
const yl = {}.toString;
function wl(t, e) {
  if (e !== void 0 && yl.call(e) !== "[object Object]")
    throw new Error("Options should be object or undefined");
  return Object.assign(t, e);
}
function ks(t) {
  const e = (r) => t().update(Rn(r)).digest(), n = t();
  return e.outputLen = n.outputLen, e.blockLen = n.blockLen, e.create = () => t(), e;
}
class Ea extends Rs {
  constructor(e, n) {
    super(), this.finished = !1, this.destroyed = !1, ga(e);
    const r = Rn(n);
    if (this.iHash = e.create(), typeof this.iHash.update != "function")
      throw new Error("Expected instance of class which extends utils.Hash");
    this.blockLen = this.iHash.blockLen, this.outputLen = this.iHash.outputLen;
    const i = this.blockLen, o = new Uint8Array(i);
    o.set(r.length > i ? e.create().update(r).digest() : r);
    for (let c = 0; c < o.length; c++)
      o[c] ^= 54;
    this.iHash.update(o), this.oHash = e.create();
    for (let c = 0; c < o.length; c++)
      o[c] ^= 106;
    this.oHash.update(o), o.fill(0);
  }
  update(e) {
    return On(this), this.iHash.update(e), this;
  }
  digestInto(e) {
    On(this), Os(e, this.outputLen), this.finished = !0, this.iHash.digestInto(e), this.oHash.update(e), this.oHash.digestInto(e), this.destroy();
  }
  digest() {
    const e = new Uint8Array(this.oHash.outputLen);
    return this.digestInto(e), e;
  }
  _cloneInto(e) {
    e || (e = Object.create(Object.getPrototypeOf(this), {}));
    const { oHash: n, iHash: r, finished: i, destroyed: o, blockLen: c, outputLen: f } = this;
    return e = e, e.finished = i, e.destroyed = o, e.blockLen = c, e.outputLen = f, e.oHash = n._cloneInto(e.oHash), e.iHash = r._cloneInto(e.iHash), e;
  }
  destroy() {
    this.destroyed = !0, this.oHash.destroy(), this.iHash.destroy();
  }
}
const Ci = (t, e, n) => new Ea(t, e).update(n).digest();
Ci.create = (t, e) => new Ea(t, e);
function gl(t, e, n, r) {
  ga(t);
  const i = wl({ dkLen: 32, asyncTick: 10 }, r), { c: o, dkLen: c, asyncTick: f } = i;
  if (pn(o), pn(c), pn(f), o < 1)
    throw new Error("PBKDF2: iterations (c) should be >= 1");
  const y = Rn(e), w = Rn(n), _ = new Uint8Array(c), m = Ci.create(t, y), I = m._cloneInto().update(w);
  return { c: o, dkLen: c, asyncTick: f, DK: _, PRF: m, PRFSalt: I };
}
function xl(t, e, n, r, i) {
  return t.destroy(), e.destroy(), r && r.destroy(), i.fill(0), n;
}
function _l(t, e, n, r) {
  const { c: i, dkLen: o, DK: c, PRF: f, PRFSalt: y } = gl(t, e, n, r);
  let w;
  const _ = new Uint8Array(4), m = zr(_), I = new Uint8Array(f.outputLen);
  for (let z = 1, k = 0; k < o; z++, k += f.outputLen) {
    const N = c.subarray(k, k + f.outputLen);
    m.setInt32(0, z, !1), (w = y._cloneInto(w)).update(_).digestInto(I), N.set(I.subarray(0, N.length));
    for (let M = 1; M < i; M++) {
      f._cloneInto(w).update(I).digestInto(I);
      for (let Z = 0; Z < N.length; Z++)
        N[Z] ^= I[Z];
    }
  }
  return xl(f, y, c, w, I);
}
function ml(t, e, n, r) {
  if (typeof t.setBigUint64 == "function")
    return t.setBigUint64(e, n, r);
  const i = BigInt(32), o = BigInt(4294967295), c = Number(n >> i & o), f = Number(n & o), y = r ? 4 : 0, w = r ? 0 : 4;
  t.setUint32(e + y, c, r), t.setUint32(e + w, f, r);
}
class va extends Rs {
  constructor(e, n, r, i) {
    super(), this.blockLen = e, this.outputLen = n, this.padOffset = r, this.isLE = i, this.finished = !1, this.length = 0, this.pos = 0, this.destroyed = !1, this.buffer = new Uint8Array(e), this.view = zr(this.buffer);
  }
  update(e) {
    On(this);
    const { view: n, buffer: r, blockLen: i } = this;
    e = Rn(e);
    const o = e.length;
    for (let c = 0; c < o; ) {
      const f = Math.min(i - this.pos, o - c);
      if (f === i) {
        const y = zr(e);
        for (; i <= o - c; c += i)
          this.process(y, c);
        continue;
      }
      r.set(e.subarray(c, c + f), this.pos), this.pos += f, c += f, this.pos === i && (this.process(n, 0), this.pos = 0);
    }
    return this.length += e.length, this.roundClean(), this;
  }
  digestInto(e) {
    On(this), xa(e, this), this.finished = !0;
    const { buffer: n, view: r, blockLen: i, isLE: o } = this;
    let { pos: c } = this;
    n[c++] = 128, this.buffer.subarray(c).fill(0), this.padOffset > i - c && (this.process(r, 0), c = 0);
    for (let m = c; m < i; m++)
      n[m] = 0;
    ml(r, i - 8, BigInt(this.length * 8), o), this.process(r, 0);
    const f = zr(e), y = this.outputLen;
    if (y % 4)
      throw new Error("_sha2: outputLen should be aligned to 32bit");
    const w = y / 4, _ = this.get();
    if (w > _.length)
      throw new Error("_sha2: outputLen bigger than state");
    for (let m = 0; m < w; m++)
      f.setUint32(4 * m, _[m], o);
  }
  digest() {
    const { buffer: e, outputLen: n } = this;
    this.digestInto(e);
    const r = e.slice(0, n);
    return this.destroy(), r;
  }
  _cloneInto(e) {
    e || (e = new this.constructor()), e.set(...this.get());
    const { blockLen: n, buffer: r, length: i, finished: o, destroyed: c, pos: f } = this;
    return e.length = i, e.pos = f, e.finished = o, e.destroyed = c, i % n && e.buffer.set(r), e;
  }
}
const bl = (t, e, n) => t & e ^ ~t & n, El = (t, e, n) => t & e ^ t & n ^ e & n, vl = /* @__PURE__ */ new Uint32Array([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]), Kt = /* @__PURE__ */ new Uint32Array([
  1779033703,
  3144134277,
  1013904242,
  2773480762,
  1359893119,
  2600822924,
  528734635,
  1541459225
]), Yt = /* @__PURE__ */ new Uint32Array(64);
class Tl extends va {
  constructor() {
    super(64, 32, 8, !1), this.A = Kt[0] | 0, this.B = Kt[1] | 0, this.C = Kt[2] | 0, this.D = Kt[3] | 0, this.E = Kt[4] | 0, this.F = Kt[5] | 0, this.G = Kt[6] | 0, this.H = Kt[7] | 0;
  }
  get() {
    const { A: e, B: n, C: r, D: i, E: o, F: c, G: f, H: y } = this;
    return [e, n, r, i, o, c, f, y];
  }
  // prettier-ignore
  set(e, n, r, i, o, c, f, y) {
    this.A = e | 0, this.B = n | 0, this.C = r | 0, this.D = i | 0, this.E = o | 0, this.F = c | 0, this.G = f | 0, this.H = y | 0;
  }
  process(e, n) {
    for (let m = 0; m < 16; m++, n += 4)
      Yt[m] = e.getUint32(n, !1);
    for (let m = 16; m < 64; m++) {
      const I = Yt[m - 15], z = Yt[m - 2], k = vt(I, 7) ^ vt(I, 18) ^ I >>> 3, N = vt(z, 17) ^ vt(z, 19) ^ z >>> 10;
      Yt[m] = N + Yt[m - 7] + k + Yt[m - 16] | 0;
    }
    let { A: r, B: i, C: o, D: c, E: f, F: y, G: w, H: _ } = this;
    for (let m = 0; m < 64; m++) {
      const I = vt(f, 6) ^ vt(f, 11) ^ vt(f, 25), z = _ + I + bl(f, y, w) + vl[m] + Yt[m] | 0, N = (vt(r, 2) ^ vt(r, 13) ^ vt(r, 22)) + El(r, i, o) | 0;
      _ = w, w = y, y = f, f = c + z | 0, c = o, o = i, i = r, r = z + N | 0;
    }
    r = r + this.A | 0, i = i + this.B | 0, o = o + this.C | 0, c = c + this.D | 0, f = f + this.E | 0, y = y + this.F | 0, w = w + this.G | 0, _ = _ + this.H | 0, this.set(r, i, o, c, f, y, w, _);
  }
  roundClean() {
    Yt.fill(0);
  }
  destroy() {
    this.set(0, 0, 0, 0, 0, 0, 0, 0), this.buffer.fill(0);
  }
}
const Bl = /* @__PURE__ */ ks(() => new Tl()), Ir = /* @__PURE__ */ BigInt(2 ** 32 - 1), us = /* @__PURE__ */ BigInt(32);
function Ta(t, e = !1) {
  return e ? { h: Number(t & Ir), l: Number(t >> us & Ir) } : { h: Number(t >> us & Ir) | 0, l: Number(t & Ir) | 0 };
}
function Ba(t, e = !1) {
  let n = new Uint32Array(t.length), r = new Uint32Array(t.length);
  for (let i = 0; i < t.length; i++) {
    const { h: o, l: c } = Ta(t[i], e);
    [n[i], r[i]] = [o, c];
  }
  return [n, r];
}
const Sl = (t, e) => BigInt(t >>> 0) << us | BigInt(e >>> 0), Il = (t, e, n) => t >>> n, Ul = (t, e, n) => t << 32 - n | e >>> n, Cl = (t, e, n) => t >>> n | e << 32 - n, Pl = (t, e, n) => t << 32 - n | e >>> n, Ol = (t, e, n) => t << 64 - n | e >>> n - 32, Rl = (t, e, n) => t >>> n - 32 | e << 64 - n, kl = (t, e) => e, Nl = (t, e) => t, Sa = (t, e, n) => t << n | e >>> 32 - n, Ia = (t, e, n) => e << n | t >>> 32 - n, Ua = (t, e, n) => e << n - 32 | t >>> 64 - n, Ca = (t, e, n) => t << n - 32 | e >>> 64 - n;
function zl(t, e, n, r) {
  const i = (e >>> 0) + (r >>> 0);
  return { h: t + n + (i / 2 ** 32 | 0) | 0, l: i | 0 };
}
const Fl = (t, e, n) => (t >>> 0) + (e >>> 0) + (n >>> 0), Dl = (t, e, n, r) => e + n + r + (t / 2 ** 32 | 0) | 0, Ll = (t, e, n, r) => (t >>> 0) + (e >>> 0) + (n >>> 0) + (r >>> 0), Ml = (t, e, n, r, i) => e + n + r + i + (t / 2 ** 32 | 0) | 0, Hl = (t, e, n, r, i) => (t >>> 0) + (e >>> 0) + (n >>> 0) + (r >>> 0) + (i >>> 0), $l = (t, e, n, r, i, o) => e + n + r + i + o + (t / 2 ** 32 | 0) | 0, pe = {
  fromBig: Ta,
  split: Ba,
  toBig: Sl,
  shrSH: Il,
  shrSL: Ul,
  rotrSH: Cl,
  rotrSL: Pl,
  rotrBH: Ol,
  rotrBL: Rl,
  rotr32H: kl,
  rotr32L: Nl,
  rotlSH: Sa,
  rotlSL: Ia,
  rotlBH: Ua,
  rotlBL: Ca,
  add: zl,
  add3L: Fl,
  add3H: Dl,
  add4L: Ll,
  add4H: Ml,
  add5H: $l,
  add5L: Hl
}, [ql, Ql] = pe.split([
  "0x428a2f98d728ae22",
  "0x7137449123ef65cd",
  "0xb5c0fbcfec4d3b2f",
  "0xe9b5dba58189dbbc",
  "0x3956c25bf348b538",
  "0x59f111f1b605d019",
  "0x923f82a4af194f9b",
  "0xab1c5ed5da6d8118",
  "0xd807aa98a3030242",
  "0x12835b0145706fbe",
  "0x243185be4ee4b28c",
  "0x550c7dc3d5ffb4e2",
  "0x72be5d74f27b896f",
  "0x80deb1fe3b1696b1",
  "0x9bdc06a725c71235",
  "0xc19bf174cf692694",
  "0xe49b69c19ef14ad2",
  "0xefbe4786384f25e3",
  "0x0fc19dc68b8cd5b5",
  "0x240ca1cc77ac9c65",
  "0x2de92c6f592b0275",
  "0x4a7484aa6ea6e483",
  "0x5cb0a9dcbd41fbd4",
  "0x76f988da831153b5",
  "0x983e5152ee66dfab",
  "0xa831c66d2db43210",
  "0xb00327c898fb213f",
  "0xbf597fc7beef0ee4",
  "0xc6e00bf33da88fc2",
  "0xd5a79147930aa725",
  "0x06ca6351e003826f",
  "0x142929670a0e6e70",
  "0x27b70a8546d22ffc",
  "0x2e1b21385c26c926",
  "0x4d2c6dfc5ac42aed",
  "0x53380d139d95b3df",
  "0x650a73548baf63de",
  "0x766a0abb3c77b2a8",
  "0x81c2c92e47edaee6",
  "0x92722c851482353b",
  "0xa2bfe8a14cf10364",
  "0xa81a664bbc423001",
  "0xc24b8b70d0f89791",
  "0xc76c51a30654be30",
  "0xd192e819d6ef5218",
  "0xd69906245565a910",
  "0xf40e35855771202a",
  "0x106aa07032bbd1b8",
  "0x19a4c116b8d2d0c8",
  "0x1e376c085141ab53",
  "0x2748774cdf8eeb99",
  "0x34b0bcb5e19b48a8",
  "0x391c0cb3c5c95a63",
  "0x4ed8aa4ae3418acb",
  "0x5b9cca4f7763e373",
  "0x682e6ff3d6b2b8a3",
  "0x748f82ee5defb2fc",
  "0x78a5636f43172f60",
  "0x84c87814a1f0ab72",
  "0x8cc702081a6439ec",
  "0x90befffa23631e28",
  "0xa4506cebde82bde9",
  "0xbef9a3f7b2c67915",
  "0xc67178f2e372532b",
  "0xca273eceea26619c",
  "0xd186b8c721c0c207",
  "0xeada7dd6cde0eb1e",
  "0xf57d4f7fee6ed178",
  "0x06f067aa72176fba",
  "0x0a637dc5a2c898a6",
  "0x113f9804bef90dae",
  "0x1b710b35131c471b",
  "0x28db77f523047d84",
  "0x32caab7b40c72493",
  "0x3c9ebe0a15c9bebc",
  "0x431d67c49c100d4c",
  "0x4cc5d4becb3e42b6",
  "0x597f299cfc657e2a",
  "0x5fcb6fab3ad6faec",
  "0x6c44198c4a475817"
].map((t) => BigInt(t))), Vt = /* @__PURE__ */ new Uint32Array(80), Jt = /* @__PURE__ */ new Uint32Array(80);
class jl extends va {
  constructor() {
    super(128, 64, 16, !1), this.Ah = 1779033703, this.Al = -205731576, this.Bh = -1150833019, this.Bl = -2067093701, this.Ch = 1013904242, this.Cl = -23791573, this.Dh = -1521486534, this.Dl = 1595750129, this.Eh = 1359893119, this.El = -1377402159, this.Fh = -1694144372, this.Fl = 725511199, this.Gh = 528734635, this.Gl = -79577749, this.Hh = 1541459225, this.Hl = 327033209;
  }
  // prettier-ignore
  get() {
    const { Ah: e, Al: n, Bh: r, Bl: i, Ch: o, Cl: c, Dh: f, Dl: y, Eh: w, El: _, Fh: m, Fl: I, Gh: z, Gl: k, Hh: N, Hl: M } = this;
    return [e, n, r, i, o, c, f, y, w, _, m, I, z, k, N, M];
  }
  // prettier-ignore
  set(e, n, r, i, o, c, f, y, w, _, m, I, z, k, N, M) {
    this.Ah = e | 0, this.Al = n | 0, this.Bh = r | 0, this.Bl = i | 0, this.Ch = o | 0, this.Cl = c | 0, this.Dh = f | 0, this.Dl = y | 0, this.Eh = w | 0, this.El = _ | 0, this.Fh = m | 0, this.Fl = I | 0, this.Gh = z | 0, this.Gl = k | 0, this.Hh = N | 0, this.Hl = M | 0;
  }
  process(e, n) {
    for (let Q = 0; Q < 16; Q++, n += 4)
      Vt[Q] = e.getUint32(n), Jt[Q] = e.getUint32(n += 4);
    for (let Q = 16; Q < 80; Q++) {
      const ke = Vt[Q - 15] | 0, Ce = Jt[Q - 15] | 0, nt = pe.rotrSH(ke, Ce, 1) ^ pe.rotrSH(ke, Ce, 8) ^ pe.shrSH(ke, Ce, 7), It = pe.rotrSL(ke, Ce, 1) ^ pe.rotrSL(ke, Ce, 8) ^ pe.shrSL(ke, Ce, 7), rt = Vt[Q - 2] | 0, it = Jt[Q - 2] | 0, mt = pe.rotrSH(rt, it, 19) ^ pe.rotrBH(rt, it, 61) ^ pe.shrSH(rt, it, 6), bt = pe.rotrSL(rt, it, 19) ^ pe.rotrBL(rt, it, 61) ^ pe.shrSL(rt, it, 6), Et = pe.add4L(It, bt, Jt[Q - 7], Jt[Q - 16]), qt = pe.add4H(Et, nt, mt, Vt[Q - 7], Vt[Q - 16]);
      Vt[Q] = qt | 0, Jt[Q] = Et | 0;
    }
    let { Ah: r, Al: i, Bh: o, Bl: c, Ch: f, Cl: y, Dh: w, Dl: _, Eh: m, El: I, Fh: z, Fl: k, Gh: N, Gl: M, Hh: Z, Hl: ve } = this;
    for (let Q = 0; Q < 80; Q++) {
      const ke = pe.rotrSH(m, I, 14) ^ pe.rotrSH(m, I, 18) ^ pe.rotrBH(m, I, 41), Ce = pe.rotrSL(m, I, 14) ^ pe.rotrSL(m, I, 18) ^ pe.rotrBL(m, I, 41), nt = m & z ^ ~m & N, It = I & k ^ ~I & M, rt = pe.add5L(ve, Ce, It, Ql[Q], Jt[Q]), it = pe.add5H(rt, Z, ke, nt, ql[Q], Vt[Q]), mt = rt | 0, bt = pe.rotrSH(r, i, 28) ^ pe.rotrBH(r, i, 34) ^ pe.rotrBH(r, i, 39), Et = pe.rotrSL(r, i, 28) ^ pe.rotrBL(r, i, 34) ^ pe.rotrBL(r, i, 39), qt = r & o ^ r & f ^ o & f, Qt = i & c ^ i & y ^ c & y;
      Z = N | 0, ve = M | 0, N = z | 0, M = k | 0, z = m | 0, k = I | 0, { h: m, l: I } = pe.add(w | 0, _ | 0, it | 0, mt | 0), w = f | 0, _ = y | 0, f = o | 0, y = c | 0, o = r | 0, c = i | 0;
      const Ut = pe.add3L(mt, Et, Qt);
      r = pe.add3H(Ut, it, bt, qt), i = Ut | 0;
    }
    ({ h: r, l: i } = pe.add(this.Ah | 0, this.Al | 0, r | 0, i | 0)), { h: o, l: c } = pe.add(this.Bh | 0, this.Bl | 0, o | 0, c | 0), { h: f, l: y } = pe.add(this.Ch | 0, this.Cl | 0, f | 0, y | 0), { h: w, l: _ } = pe.add(this.Dh | 0, this.Dl | 0, w | 0, _ | 0), { h: m, l: I } = pe.add(this.Eh | 0, this.El | 0, m | 0, I | 0), { h: z, l: k } = pe.add(this.Fh | 0, this.Fl | 0, z | 0, k | 0), { h: N, l: M } = pe.add(this.Gh | 0, this.Gl | 0, N | 0, M | 0), { h: Z, l: ve } = pe.add(this.Hh | 0, this.Hl | 0, Z | 0, ve | 0), this.set(r, i, o, c, f, y, w, _, m, I, z, k, N, M, Z, ve);
  }
  roundClean() {
    Vt.fill(0), Jt.fill(0);
  }
  destroy() {
    this.buffer.fill(0), this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
  }
}
const Ns = /* @__PURE__ */ ks(() => new jl());
function Pa(t) {
  if (typeof t != "string")
    throw new TypeError(`Invalid mnemonic type: ${typeof t}`);
  return t.normalize("NFKD");
}
function Gl(t) {
  const e = Pa(t), n = e.split(" ");
  if (![12, 15, 18, 21, 24].includes(n.length))
    throw new Error("Invalid mnemonic");
  return { nfkd: e, words: n };
}
const Wl = (t) => Pa(`mnemonic${t}`);
function Kl(t, e = "") {
  return _l(Ns, Gl(t).nfkd, Wl(e), { c: 2048, dkLen: 64 });
}
const [Oa, Ra, ka] = [[], [], []], Yl = /* @__PURE__ */ BigInt(0), Wn = /* @__PURE__ */ BigInt(1), Vl = /* @__PURE__ */ BigInt(2), Jl = /* @__PURE__ */ BigInt(7), Xl = /* @__PURE__ */ BigInt(256), Zl = /* @__PURE__ */ BigInt(113);
for (let t = 0, e = Wn, n = 1, r = 0; t < 24; t++) {
  [n, r] = [r, (2 * n + 3 * r) % 5], Oa.push(2 * (5 * r + n)), Ra.push((t + 1) * (t + 2) / 2 % 64);
  let i = Yl;
  for (let o = 0; o < 7; o++)
    e = (e << Wn ^ (e >> Jl) * Zl) % Xl, e & Vl && (i ^= Wn << (Wn << /* @__PURE__ */ BigInt(o)) - Wn);
  ka.push(i);
}
const [ed, td] = /* @__PURE__ */ Ba(ka, !0), Po = (t, e, n) => n > 32 ? Ua(t, e, n) : Sa(t, e, n), Oo = (t, e, n) => n > 32 ? Ca(t, e, n) : Ia(t, e, n);
function nd(t, e = 24) {
  const n = new Uint32Array(10);
  for (let r = 24 - e; r < 24; r++) {
    for (let c = 0; c < 10; c++)
      n[c] = t[c] ^ t[c + 10] ^ t[c + 20] ^ t[c + 30] ^ t[c + 40];
    for (let c = 0; c < 10; c += 2) {
      const f = (c + 8) % 10, y = (c + 2) % 10, w = n[y], _ = n[y + 1], m = Po(w, _, 1) ^ n[f], I = Oo(w, _, 1) ^ n[f + 1];
      for (let z = 0; z < 50; z += 10)
        t[c + z] ^= m, t[c + z + 1] ^= I;
    }
    let i = t[2], o = t[3];
    for (let c = 0; c < 24; c++) {
      const f = Ra[c], y = Po(i, o, f), w = Oo(i, o, f), _ = Oa[c];
      i = t[_], o = t[_ + 1], t[_] = y, t[_ + 1] = w;
    }
    for (let c = 0; c < 50; c += 10) {
      for (let f = 0; f < 10; f++)
        n[f] = t[c + f];
      for (let f = 0; f < 10; f++)
        t[c + f] ^= ~n[(f + 2) % 10] & n[(f + 4) % 10];
    }
    t[0] ^= ed[r], t[1] ^= td[r];
  }
  n.fill(0);
}
class zs extends Rs {
  // NOTE: we accept arguments in bytes instead of bits here.
  constructor(e, n, r, i = !1, o = 24) {
    if (super(), this.blockLen = e, this.suffix = n, this.outputLen = r, this.enableXOF = i, this.rounds = o, this.pos = 0, this.posOut = 0, this.finished = !1, this.destroyed = !1, pn(r), 0 >= this.blockLen || this.blockLen >= 200)
      throw new Error("Sha3 supports only keccak-f1600 function");
    this.state = new Uint8Array(200), this.state32 = dl(this.state);
  }
  keccak() {
    nd(this.state32, this.rounds), this.posOut = 0, this.pos = 0;
  }
  update(e) {
    On(this);
    const { blockLen: n, state: r } = this;
    e = Rn(e);
    const i = e.length;
    for (let o = 0; o < i; ) {
      const c = Math.min(n - this.pos, i - o);
      for (let f = 0; f < c; f++)
        r[this.pos++] ^= e[o++];
      this.pos === n && this.keccak();
    }
    return this;
  }
  finish() {
    if (this.finished)
      return;
    this.finished = !0;
    const { state: e, suffix: n, pos: r, blockLen: i } = this;
    e[r] ^= n, n & 128 && r === i - 1 && this.keccak(), e[i - 1] ^= 128, this.keccak();
  }
  writeInto(e) {
    On(this, !1), Os(e), this.finish();
    const n = this.state, { blockLen: r } = this;
    for (let i = 0, o = e.length; i < o; ) {
      this.posOut >= r && this.keccak();
      const c = Math.min(r - this.posOut, o - i);
      e.set(n.subarray(this.posOut, this.posOut + c), i), this.posOut += c, i += c;
    }
    return e;
  }
  xofInto(e) {
    if (!this.enableXOF)
      throw new Error("XOF is not possible for this instance");
    return this.writeInto(e);
  }
  xof(e) {
    return pn(e), this.xofInto(new Uint8Array(e));
  }
  digestInto(e) {
    if (xa(e, this), this.finished)
      throw new Error("digest() was already called");
    return this.writeInto(e), this.destroy(), e;
  }
  digest() {
    return this.digestInto(new Uint8Array(this.outputLen));
  }
  destroy() {
    this.destroyed = !0, this.state.fill(0);
  }
  _cloneInto(e) {
    const { blockLen: n, suffix: r, outputLen: i, rounds: o, enableXOF: c } = this;
    return e || (e = new zs(n, r, i, c, o)), e.state32.set(this.state32), e.pos = this.pos, e.posOut = this.posOut, e.finished = this.finished, e.rounds = o, e.suffix = r, e.outputLen = i, e.enableXOF = c, e.destroyed = this.destroyed, e;
  }
}
const rd = (t, e, n) => ks(() => new zs(e, t, n)), kn = /* @__PURE__ */ rd(6, 136, 256 / 8);
function Na(t, e) {
  return function() {
    return t.apply(e, arguments);
  };
}
const { toString: id } = Object.prototype, { getPrototypeOf: Fs } = Object, Pi = /* @__PURE__ */ ((t) => (e) => {
  const n = id.call(e);
  return t[n] || (t[n] = n.slice(8, -1).toLowerCase());
})(/* @__PURE__ */ Object.create(null)), St = (t) => (t = t.toLowerCase(), (e) => Pi(e) === t), Oi = (t) => (e) => typeof e === t, { isArray: zn } = Array, nr = Oi("undefined");
function sd(t) {
  return t !== null && !nr(t) && t.constructor !== null && !nr(t.constructor) && pt(t.constructor.isBuffer) && t.constructor.isBuffer(t);
}
const za = St("ArrayBuffer");
function od(t) {
  let e;
  return typeof ArrayBuffer < "u" && ArrayBuffer.isView ? e = ArrayBuffer.isView(t) : e = t && t.buffer && za(t.buffer), e;
}
const ad = Oi("string"), pt = Oi("function"), Fa = Oi("number"), Ri = (t) => t !== null && typeof t == "object", cd = (t) => t === !0 || t === !1, Fr = (t) => {
  if (Pi(t) !== "object")
    return !1;
  const e = Fs(t);
  return (e === null || e === Object.prototype || Object.getPrototypeOf(e) === null) && !(Symbol.toStringTag in t) && !(Symbol.iterator in t);
}, ud = St("Date"), fd = St("File"), ld = St("Blob"), dd = St("FileList"), hd = (t) => Ri(t) && pt(t.pipe), pd = (t) => {
  let e;
  return t && (typeof FormData == "function" && t instanceof FormData || pt(t.append) && ((e = Pi(t)) === "formdata" || // detect form-data instance
  e === "object" && pt(t.toString) && t.toString() === "[object FormData]"));
}, Ad = St("URLSearchParams"), yd = (t) => t.trim ? t.trim() : t.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
function dr(t, e, { allOwnKeys: n = !1 } = {}) {
  if (t === null || typeof t > "u")
    return;
  let r, i;
  if (typeof t != "object" && (t = [t]), zn(t))
    for (r = 0, i = t.length; r < i; r++)
      e.call(null, t[r], r, t);
  else {
    const o = n ? Object.getOwnPropertyNames(t) : Object.keys(t), c = o.length;
    let f;
    for (r = 0; r < c; r++)
      f = o[r], e.call(null, t[f], f, t);
  }
}
function Da(t, e) {
  e = e.toLowerCase();
  const n = Object.keys(t);
  let r = n.length, i;
  for (; r-- > 0; )
    if (i = n[r], e === i.toLowerCase())
      return i;
  return null;
}
const La = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : global, Ma = (t) => !nr(t) && t !== La;
function fs() {
  const { caseless: t } = Ma(this) && this || {}, e = {}, n = (r, i) => {
    const o = t && Da(e, i) || i;
    Fr(e[o]) && Fr(r) ? e[o] = fs(e[o], r) : Fr(r) ? e[o] = fs({}, r) : zn(r) ? e[o] = r.slice() : e[o] = r;
  };
  for (let r = 0, i = arguments.length; r < i; r++)
    arguments[r] && dr(arguments[r], n);
  return e;
}
const wd = (t, e, n, { allOwnKeys: r } = {}) => (dr(e, (i, o) => {
  n && pt(i) ? t[o] = Na(i, n) : t[o] = i;
}, { allOwnKeys: r }), t), gd = (t) => (t.charCodeAt(0) === 65279 && (t = t.slice(1)), t), xd = (t, e, n, r) => {
  t.prototype = Object.create(e.prototype, r), t.prototype.constructor = t, Object.defineProperty(t, "super", {
    value: e.prototype
  }), n && Object.assign(t.prototype, n);
}, _d = (t, e, n, r) => {
  let i, o, c;
  const f = {};
  if (e = e || {}, t == null)
    return e;
  do {
    for (i = Object.getOwnPropertyNames(t), o = i.length; o-- > 0; )
      c = i[o], (!r || r(c, t, e)) && !f[c] && (e[c] = t[c], f[c] = !0);
    t = n !== !1 && Fs(t);
  } while (t && (!n || n(t, e)) && t !== Object.prototype);
  return e;
}, md = (t, e, n) => {
  t = String(t), (n === void 0 || n > t.length) && (n = t.length), n -= e.length;
  const r = t.indexOf(e, n);
  return r !== -1 && r === n;
}, bd = (t) => {
  if (!t)
    return null;
  if (zn(t))
    return t;
  let e = t.length;
  if (!Fa(e))
    return null;
  const n = new Array(e);
  for (; e-- > 0; )
    n[e] = t[e];
  return n;
}, Ed = /* @__PURE__ */ ((t) => (e) => t && e instanceof t)(typeof Uint8Array < "u" && Fs(Uint8Array)), vd = (t, e) => {
  const r = (t && t[Symbol.iterator]).call(t);
  let i;
  for (; (i = r.next()) && !i.done; ) {
    const o = i.value;
    e.call(t, o[0], o[1]);
  }
}, Td = (t, e) => {
  let n;
  const r = [];
  for (; (n = t.exec(e)) !== null; )
    r.push(n);
  return r;
}, Bd = St("HTMLFormElement"), Sd = (t) => t.toLowerCase().replace(
  /[-_\s]([a-z\d])(\w*)/g,
  function(n, r, i) {
    return r.toUpperCase() + i;
  }
), Ro = (({ hasOwnProperty: t }) => (e, n) => t.call(e, n))(Object.prototype), Id = St("RegExp"), Ha = (t, e) => {
  const n = Object.getOwnPropertyDescriptors(t), r = {};
  dr(n, (i, o) => {
    let c;
    (c = e(i, o, t)) !== !1 && (r[o] = c || i);
  }), Object.defineProperties(t, r);
}, Ud = (t) => {
  Ha(t, (e, n) => {
    if (pt(t) && ["arguments", "caller", "callee"].indexOf(n) !== -1)
      return !1;
    const r = t[n];
    if (pt(r)) {
      if (e.enumerable = !1, "writable" in e) {
        e.writable = !1;
        return;
      }
      e.set || (e.set = () => {
        throw Error("Can not rewrite read-only method '" + n + "'");
      });
    }
  });
}, Cd = (t, e) => {
  const n = {}, r = (i) => {
    i.forEach((o) => {
      n[o] = !0;
    });
  };
  return zn(t) ? r(t) : r(String(t).split(e)), n;
}, Pd = () => {
}, Od = (t, e) => (t = +t, Number.isFinite(t) ? t : e), es = "abcdefghijklmnopqrstuvwxyz", ko = "0123456789", $a = {
  DIGIT: ko,
  ALPHA: es,
  ALPHA_DIGIT: es + es.toUpperCase() + ko
}, Rd = (t = 16, e = $a.ALPHA_DIGIT) => {
  let n = "";
  const { length: r } = e;
  for (; t--; )
    n += e[Math.random() * r | 0];
  return n;
};
function kd(t) {
  return !!(t && pt(t.append) && t[Symbol.toStringTag] === "FormData" && t[Symbol.iterator]);
}
const Nd = (t) => {
  const e = new Array(10), n = (r, i) => {
    if (Ri(r)) {
      if (e.indexOf(r) >= 0)
        return;
      if (!("toJSON" in r)) {
        e[i] = r;
        const o = zn(r) ? [] : {};
        return dr(r, (c, f) => {
          const y = n(c, i + 1);
          !nr(y) && (o[f] = y);
        }), e[i] = void 0, o;
      }
    }
    return r;
  };
  return n(t, 0);
}, zd = St("AsyncFunction"), Fd = (t) => t && (Ri(t) || pt(t)) && pt(t.then) && pt(t.catch), C = {
  isArray: zn,
  isArrayBuffer: za,
  isBuffer: sd,
  isFormData: pd,
  isArrayBufferView: od,
  isString: ad,
  isNumber: Fa,
  isBoolean: cd,
  isObject: Ri,
  isPlainObject: Fr,
  isUndefined: nr,
  isDate: ud,
  isFile: fd,
  isBlob: ld,
  isRegExp: Id,
  isFunction: pt,
  isStream: hd,
  isURLSearchParams: Ad,
  isTypedArray: Ed,
  isFileList: dd,
  forEach: dr,
  merge: fs,
  extend: wd,
  trim: yd,
  stripBOM: gd,
  inherits: xd,
  toFlatObject: _d,
  kindOf: Pi,
  kindOfTest: St,
  endsWith: md,
  toArray: bd,
  forEachEntry: vd,
  matchAll: Td,
  isHTMLForm: Bd,
  hasOwnProperty: Ro,
  hasOwnProp: Ro,
  // an alias to avoid ESLint no-prototype-builtins detection
  reduceDescriptors: Ha,
  freezeMethods: Ud,
  toObjectSet: Cd,
  toCamelCase: Sd,
  noop: Pd,
  toFiniteNumber: Od,
  findKey: Da,
  global: La,
  isContextDefined: Ma,
  ALPHABET: $a,
  generateString: Rd,
  isSpecCompliantForm: kd,
  toJSONObject: Nd,
  isAsyncFn: zd,
  isThenable: Fd
};
function xe(t, e, n, r, i) {
  Error.call(this), Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = new Error().stack, this.message = t, this.name = "AxiosError", e && (this.code = e), n && (this.config = n), r && (this.request = r), i && (this.response = i);
}
C.inherits(xe, Error, {
  toJSON: function() {
    return {
      // Standard
      message: this.message,
      name: this.name,
      // Microsoft
      description: this.description,
      number: this.number,
      // Mozilla
      fileName: this.fileName,
      lineNumber: this.lineNumber,
      columnNumber: this.columnNumber,
      stack: this.stack,
      // Axios
      config: C.toJSONObject(this.config),
      code: this.code,
      status: this.response && this.response.status ? this.response.status : null
    };
  }
});
const qa = xe.prototype, Qa = {};
[
  "ERR_BAD_OPTION_VALUE",
  "ERR_BAD_OPTION",
  "ECONNABORTED",
  "ETIMEDOUT",
  "ERR_NETWORK",
  "ERR_FR_TOO_MANY_REDIRECTS",
  "ERR_DEPRECATED",
  "ERR_BAD_RESPONSE",
  "ERR_BAD_REQUEST",
  "ERR_CANCELED",
  "ERR_NOT_SUPPORT",
  "ERR_INVALID_URL"
  // eslint-disable-next-line func-names
].forEach((t) => {
  Qa[t] = { value: t };
});
Object.defineProperties(xe, Qa);
Object.defineProperty(qa, "isAxiosError", { value: !0 });
xe.from = (t, e, n, r, i, o) => {
  const c = Object.create(qa);
  return C.toFlatObject(t, c, function(y) {
    return y !== Error.prototype;
  }, (f) => f !== "isAxiosError"), xe.call(c, t.message, e, n, r, i), c.cause = t, c.name = t.name, o && Object.assign(c, o), c;
};
const Dd = null;
function ls(t) {
  return C.isPlainObject(t) || C.isArray(t);
}
function ja(t) {
  return C.endsWith(t, "[]") ? t.slice(0, -2) : t;
}
function No(t, e, n) {
  return t ? t.concat(e).map(function(i, o) {
    return i = ja(i), !n && o ? "[" + i + "]" : i;
  }).join(n ? "." : "") : e;
}
function Ld(t) {
  return C.isArray(t) && !t.some(ls);
}
const Md = C.toFlatObject(C, {}, null, function(e) {
  return /^is[A-Z]/.test(e);
});
function ki(t, e, n) {
  if (!C.isObject(t))
    throw new TypeError("target must be an object");
  e = e || new FormData(), n = C.toFlatObject(n, {
    metaTokens: !0,
    dots: !1,
    indexes: !1
  }, !1, function(N, M) {
    return !C.isUndefined(M[N]);
  });
  const r = n.metaTokens, i = n.visitor || _, o = n.dots, c = n.indexes, y = (n.Blob || typeof Blob < "u" && Blob) && C.isSpecCompliantForm(e);
  if (!C.isFunction(i))
    throw new TypeError("visitor must be a function");
  function w(k) {
    if (k === null)
      return "";
    if (C.isDate(k))
      return k.toISOString();
    if (!y && C.isBlob(k))
      throw new xe("Blob is not supported. Use a Buffer instead.");
    return C.isArrayBuffer(k) || C.isTypedArray(k) ? y && typeof Blob == "function" ? new Blob([k]) : Buffer.from(k) : k;
  }
  function _(k, N, M) {
    let Z = k;
    if (k && !M && typeof k == "object") {
      if (C.endsWith(N, "{}"))
        N = r ? N : N.slice(0, -2), k = JSON.stringify(k);
      else if (C.isArray(k) && Ld(k) || (C.isFileList(k) || C.endsWith(N, "[]")) && (Z = C.toArray(k)))
        return N = ja(N), Z.forEach(function(Q, ke) {
          !(C.isUndefined(Q) || Q === null) && e.append(
            // eslint-disable-next-line no-nested-ternary
            c === !0 ? No([N], ke, o) : c === null ? N : N + "[]",
            w(Q)
          );
        }), !1;
    }
    return ls(k) ? !0 : (e.append(No(M, N, o), w(k)), !1);
  }
  const m = [], I = Object.assign(Md, {
    defaultVisitor: _,
    convertValue: w,
    isVisitable: ls
  });
  function z(k, N) {
    if (!C.isUndefined(k)) {
      if (m.indexOf(k) !== -1)
        throw Error("Circular reference detected in " + N.join("."));
      m.push(k), C.forEach(k, function(Z, ve) {
        (!(C.isUndefined(Z) || Z === null) && i.call(
          e,
          Z,
          C.isString(ve) ? ve.trim() : ve,
          N,
          I
        )) === !0 && z(Z, N ? N.concat(ve) : [ve]);
      }), m.pop();
    }
  }
  if (!C.isObject(t))
    throw new TypeError("data must be an object");
  return z(t), e;
}
function zo(t) {
  const e = {
    "!": "%21",
    "'": "%27",
    "(": "%28",
    ")": "%29",
    "~": "%7E",
    "%20": "+",
    "%00": "\0"
  };
  return encodeURIComponent(t).replace(/[!'()~]|%20|%00/g, function(r) {
    return e[r];
  });
}
function Ds(t, e) {
  this._pairs = [], t && ki(t, this, e);
}
const Ga = Ds.prototype;
Ga.append = function(e, n) {
  this._pairs.push([e, n]);
};
Ga.toString = function(e) {
  const n = e ? function(r) {
    return e.call(this, r, zo);
  } : zo;
  return this._pairs.map(function(i) {
    return n(i[0]) + "=" + n(i[1]);
  }, "").join("&");
};
function Hd(t) {
  return encodeURIComponent(t).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]");
}
function Wa(t, e, n) {
  if (!e)
    return t;
  const r = n && n.encode || Hd, i = n && n.serialize;
  let o;
  if (i ? o = i(e, n) : o = C.isURLSearchParams(e) ? e.toString() : new Ds(e, n).toString(r), o) {
    const c = t.indexOf("#");
    c !== -1 && (t = t.slice(0, c)), t += (t.indexOf("?") === -1 ? "?" : "&") + o;
  }
  return t;
}
class Fo {
  constructor() {
    this.handlers = [];
  }
  /**
   * Add a new interceptor to the stack
   *
   * @param {Function} fulfilled The function to handle `then` for a `Promise`
   * @param {Function} rejected The function to handle `reject` for a `Promise`
   *
   * @return {Number} An ID used to remove interceptor later
   */
  use(e, n, r) {
    return this.handlers.push({
      fulfilled: e,
      rejected: n,
      synchronous: r ? r.synchronous : !1,
      runWhen: r ? r.runWhen : null
    }), this.handlers.length - 1;
  }
  /**
   * Remove an interceptor from the stack
   *
   * @param {Number} id The ID that was returned by `use`
   *
   * @returns {Boolean} `true` if the interceptor was removed, `false` otherwise
   */
  eject(e) {
    this.handlers[e] && (this.handlers[e] = null);
  }
  /**
   * Clear all interceptors from the stack
   *
   * @returns {void}
   */
  clear() {
    this.handlers && (this.handlers = []);
  }
  /**
   * Iterate over all the registered interceptors
   *
   * This method is particularly useful for skipping over any
   * interceptors that may have become `null` calling `eject`.
   *
   * @param {Function} fn The function to call for each interceptor
   *
   * @returns {void}
   */
  forEach(e) {
    C.forEach(this.handlers, function(r) {
      r !== null && e(r);
    });
  }
}
const Ka = {
  silentJSONParsing: !0,
  forcedJSONParsing: !0,
  clarifyTimeoutError: !1
}, $d = typeof URLSearchParams < "u" ? URLSearchParams : Ds, qd = typeof FormData < "u" ? FormData : null, Qd = typeof Blob < "u" ? Blob : null, jd = {
  isBrowser: !0,
  classes: {
    URLSearchParams: $d,
    FormData: qd,
    Blob: Qd
  },
  protocols: ["http", "https", "file", "blob", "url", "data"]
}, Ya = typeof window < "u" && typeof document < "u", Gd = ((t) => Ya && ["ReactNative", "NativeScript", "NS"].indexOf(t) < 0)(typeof navigator < "u" && navigator.product), Wd = typeof WorkerGlobalScope < "u" && // eslint-disable-next-line no-undef
self instanceof WorkerGlobalScope && typeof self.importScripts == "function", Kd = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  hasBrowserEnv: Ya,
  hasStandardBrowserEnv: Gd,
  hasStandardBrowserWebWorkerEnv: Wd
}, Symbol.toStringTag, { value: "Module" })), Bt = {
  ...Kd,
  ...jd
};
function Yd(t, e) {
  return ki(t, new Bt.classes.URLSearchParams(), Object.assign({
    visitor: function(n, r, i, o) {
      return Bt.isNode && C.isBuffer(n) ? (this.append(r, n.toString("base64")), !1) : o.defaultVisitor.apply(this, arguments);
    }
  }, e));
}
function Vd(t) {
  return C.matchAll(/\w+|\[(\w*)]/g, t).map((e) => e[0] === "[]" ? "" : e[1] || e[0]);
}
function Jd(t) {
  const e = {}, n = Object.keys(t);
  let r;
  const i = n.length;
  let o;
  for (r = 0; r < i; r++)
    o = n[r], e[o] = t[o];
  return e;
}
function Va(t) {
  function e(n, r, i, o) {
    let c = n[o++];
    const f = Number.isFinite(+c), y = o >= n.length;
    return c = !c && C.isArray(i) ? i.length : c, y ? (C.hasOwnProp(i, c) ? i[c] = [i[c], r] : i[c] = r, !f) : ((!i[c] || !C.isObject(i[c])) && (i[c] = []), e(n, r, i[c], o) && C.isArray(i[c]) && (i[c] = Jd(i[c])), !f);
  }
  if (C.isFormData(t) && C.isFunction(t.entries)) {
    const n = {};
    return C.forEachEntry(t, (r, i) => {
      e(Vd(r), i, n, 0);
    }), n;
  }
  return null;
}
function Xd(t, e, n) {
  if (C.isString(t))
    try {
      return (e || JSON.parse)(t), C.trim(t);
    } catch (r) {
      if (r.name !== "SyntaxError")
        throw r;
    }
  return (n || JSON.stringify)(t);
}
const Ls = {
  transitional: Ka,
  adapter: ["xhr", "http"],
  transformRequest: [function(e, n) {
    const r = n.getContentType() || "", i = r.indexOf("application/json") > -1, o = C.isObject(e);
    if (o && C.isHTMLForm(e) && (e = new FormData(e)), C.isFormData(e))
      return i && i ? JSON.stringify(Va(e)) : e;
    if (C.isArrayBuffer(e) || C.isBuffer(e) || C.isStream(e) || C.isFile(e) || C.isBlob(e))
      return e;
    if (C.isArrayBufferView(e))
      return e.buffer;
    if (C.isURLSearchParams(e))
      return n.setContentType("application/x-www-form-urlencoded;charset=utf-8", !1), e.toString();
    let f;
    if (o) {
      if (r.indexOf("application/x-www-form-urlencoded") > -1)
        return Yd(e, this.formSerializer).toString();
      if ((f = C.isFileList(e)) || r.indexOf("multipart/form-data") > -1) {
        const y = this.env && this.env.FormData;
        return ki(
          f ? { "files[]": e } : e,
          y && new y(),
          this.formSerializer
        );
      }
    }
    return o || i ? (n.setContentType("application/json", !1), Xd(e)) : e;
  }],
  transformResponse: [function(e) {
    const n = this.transitional || Ls.transitional, r = n && n.forcedJSONParsing, i = this.responseType === "json";
    if (e && C.isString(e) && (r && !this.responseType || i)) {
      const c = !(n && n.silentJSONParsing) && i;
      try {
        return JSON.parse(e);
      } catch (f) {
        if (c)
          throw f.name === "SyntaxError" ? xe.from(f, xe.ERR_BAD_RESPONSE, this, null, this.response) : f;
      }
    }
    return e;
  }],
  /**
   * A timeout in milliseconds to abort a request. If set to 0 (default) a
   * timeout is not created.
   */
  timeout: 0,
  xsrfCookieName: "XSRF-TOKEN",
  xsrfHeaderName: "X-XSRF-TOKEN",
  maxContentLength: -1,
  maxBodyLength: -1,
  env: {
    FormData: Bt.classes.FormData,
    Blob: Bt.classes.Blob
  },
  validateStatus: function(e) {
    return e >= 200 && e < 300;
  },
  headers: {
    common: {
      Accept: "application/json, text/plain, */*",
      "Content-Type": void 0
    }
  }
};
C.forEach(["delete", "get", "head", "post", "put", "patch"], (t) => {
  Ls.headers[t] = {};
});
const Ms = Ls, Zd = C.toObjectSet([
  "age",
  "authorization",
  "content-length",
  "content-type",
  "etag",
  "expires",
  "from",
  "host",
  "if-modified-since",
  "if-unmodified-since",
  "last-modified",
  "location",
  "max-forwards",
  "proxy-authorization",
  "referer",
  "retry-after",
  "user-agent"
]), eh = (t) => {
  const e = {};
  let n, r, i;
  return t && t.split(`
`).forEach(function(c) {
    i = c.indexOf(":"), n = c.substring(0, i).trim().toLowerCase(), r = c.substring(i + 1).trim(), !(!n || e[n] && Zd[n]) && (n === "set-cookie" ? e[n] ? e[n].push(r) : e[n] = [r] : e[n] = e[n] ? e[n] + ", " + r : r);
  }), e;
}, Do = Symbol("internals");
function Kn(t) {
  return t && String(t).trim().toLowerCase();
}
function Dr(t) {
  return t === !1 || t == null ? t : C.isArray(t) ? t.map(Dr) : String(t);
}
function th(t) {
  const e = /* @__PURE__ */ Object.create(null), n = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
  let r;
  for (; r = n.exec(t); )
    e[r[1]] = r[2];
  return e;
}
const nh = (t) => /^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(t.trim());
function ts(t, e, n, r, i) {
  if (C.isFunction(r))
    return r.call(this, e, n);
  if (i && (e = n), !!C.isString(e)) {
    if (C.isString(r))
      return e.indexOf(r) !== -1;
    if (C.isRegExp(r))
      return r.test(e);
  }
}
function rh(t) {
  return t.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (e, n, r) => n.toUpperCase() + r);
}
function ih(t, e) {
  const n = C.toCamelCase(" " + e);
  ["get", "set", "has"].forEach((r) => {
    Object.defineProperty(t, r + n, {
      value: function(i, o, c) {
        return this[r].call(this, e, i, o, c);
      },
      configurable: !0
    });
  });
}
class Ni {
  constructor(e) {
    e && this.set(e);
  }
  set(e, n, r) {
    const i = this;
    function o(f, y, w) {
      const _ = Kn(y);
      if (!_)
        throw new Error("header name must be a non-empty string");
      const m = C.findKey(i, _);
      (!m || i[m] === void 0 || w === !0 || w === void 0 && i[m] !== !1) && (i[m || y] = Dr(f));
    }
    const c = (f, y) => C.forEach(f, (w, _) => o(w, _, y));
    return C.isPlainObject(e) || e instanceof this.constructor ? c(e, n) : C.isString(e) && (e = e.trim()) && !nh(e) ? c(eh(e), n) : e != null && o(n, e, r), this;
  }
  get(e, n) {
    if (e = Kn(e), e) {
      const r = C.findKey(this, e);
      if (r) {
        const i = this[r];
        if (!n)
          return i;
        if (n === !0)
          return th(i);
        if (C.isFunction(n))
          return n.call(this, i, r);
        if (C.isRegExp(n))
          return n.exec(i);
        throw new TypeError("parser must be boolean|regexp|function");
      }
    }
  }
  has(e, n) {
    if (e = Kn(e), e) {
      const r = C.findKey(this, e);
      return !!(r && this[r] !== void 0 && (!n || ts(this, this[r], r, n)));
    }
    return !1;
  }
  delete(e, n) {
    const r = this;
    let i = !1;
    function o(c) {
      if (c = Kn(c), c) {
        const f = C.findKey(r, c);
        f && (!n || ts(r, r[f], f, n)) && (delete r[f], i = !0);
      }
    }
    return C.isArray(e) ? e.forEach(o) : o(e), i;
  }
  clear(e) {
    const n = Object.keys(this);
    let r = n.length, i = !1;
    for (; r--; ) {
      const o = n[r];
      (!e || ts(this, this[o], o, e, !0)) && (delete this[o], i = !0);
    }
    return i;
  }
  normalize(e) {
    const n = this, r = {};
    return C.forEach(this, (i, o) => {
      const c = C.findKey(r, o);
      if (c) {
        n[c] = Dr(i), delete n[o];
        return;
      }
      const f = e ? rh(o) : String(o).trim();
      f !== o && delete n[o], n[f] = Dr(i), r[f] = !0;
    }), this;
  }
  concat(...e) {
    return this.constructor.concat(this, ...e);
  }
  toJSON(e) {
    const n = /* @__PURE__ */ Object.create(null);
    return C.forEach(this, (r, i) => {
      r != null && r !== !1 && (n[i] = e && C.isArray(r) ? r.join(", ") : r);
    }), n;
  }
  [Symbol.iterator]() {
    return Object.entries(this.toJSON())[Symbol.iterator]();
  }
  toString() {
    return Object.entries(this.toJSON()).map(([e, n]) => e + ": " + n).join(`
`);
  }
  get [Symbol.toStringTag]() {
    return "AxiosHeaders";
  }
  static from(e) {
    return e instanceof this ? e : new this(e);
  }
  static concat(e, ...n) {
    const r = new this(e);
    return n.forEach((i) => r.set(i)), r;
  }
  static accessor(e) {
    const r = (this[Do] = this[Do] = {
      accessors: {}
    }).accessors, i = this.prototype;
    function o(c) {
      const f = Kn(c);
      r[f] || (ih(i, c), r[f] = !0);
    }
    return C.isArray(e) ? e.forEach(o) : o(e), this;
  }
}
Ni.accessor(["Content-Type", "Content-Length", "Accept", "Accept-Encoding", "User-Agent", "Authorization"]);
C.reduceDescriptors(Ni.prototype, ({ value: t }, e) => {
  let n = e[0].toUpperCase() + e.slice(1);
  return {
    get: () => t,
    set(r) {
      this[n] = r;
    }
  };
});
C.freezeMethods(Ni);
const Ht = Ni;
function ns(t, e) {
  const n = this || Ms, r = e || n, i = Ht.from(r.headers);
  let o = r.data;
  return C.forEach(t, function(f) {
    o = f.call(n, o, i.normalize(), e ? e.status : void 0);
  }), i.normalize(), o;
}
function Ja(t) {
  return !!(t && t.__CANCEL__);
}
function hr(t, e, n) {
  xe.call(this, t ?? "canceled", xe.ERR_CANCELED, e, n), this.name = "CanceledError";
}
C.inherits(hr, xe, {
  __CANCEL__: !0
});
function sh(t, e, n) {
  const r = n.config.validateStatus;
  !n.status || !r || r(n.status) ? t(n) : e(new xe(
    "Request failed with status code " + n.status,
    [xe.ERR_BAD_REQUEST, xe.ERR_BAD_RESPONSE][Math.floor(n.status / 100) - 4],
    n.config,
    n.request,
    n
  ));
}
const oh = Bt.hasStandardBrowserEnv ? (
  // Standard browser envs support document.cookie
  {
    write(t, e, n, r, i, o) {
      const c = [t + "=" + encodeURIComponent(e)];
      C.isNumber(n) && c.push("expires=" + new Date(n).toGMTString()), C.isString(r) && c.push("path=" + r), C.isString(i) && c.push("domain=" + i), o === !0 && c.push("secure"), document.cookie = c.join("; ");
    },
    read(t) {
      const e = document.cookie.match(new RegExp("(^|;\\s*)(" + t + ")=([^;]*)"));
      return e ? decodeURIComponent(e[3]) : null;
    },
    remove(t) {
      this.write(t, "", Date.now() - 864e5);
    }
  }
) : (
  // Non-standard browser env (web workers, react-native) lack needed support.
  {
    write() {
    },
    read() {
      return null;
    },
    remove() {
    }
  }
);
function ah(t) {
  return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(t);
}
function ch(t, e) {
  return e ? t.replace(/\/+$/, "") + "/" + e.replace(/^\/+/, "") : t;
}
function Xa(t, e) {
  return t && !ah(e) ? ch(t, e) : e;
}
const uh = Bt.hasStandardBrowserEnv ? (
  // Standard browser envs have full support of the APIs needed to test
  // whether the request URL is of the same origin as current location.
  function() {
    const e = /(msie|trident)/i.test(navigator.userAgent), n = document.createElement("a");
    let r;
    function i(o) {
      let c = o;
      return e && (n.setAttribute("href", c), c = n.href), n.setAttribute("href", c), {
        href: n.href,
        protocol: n.protocol ? n.protocol.replace(/:$/, "") : "",
        host: n.host,
        search: n.search ? n.search.replace(/^\?/, "") : "",
        hash: n.hash ? n.hash.replace(/^#/, "") : "",
        hostname: n.hostname,
        port: n.port,
        pathname: n.pathname.charAt(0) === "/" ? n.pathname : "/" + n.pathname
      };
    }
    return r = i(window.location.href), function(c) {
      const f = C.isString(c) ? i(c) : c;
      return f.protocol === r.protocol && f.host === r.host;
    };
  }()
) : (
  // Non standard browser envs (web workers, react-native) lack needed support.
  /* @__PURE__ */ function() {
    return function() {
      return !0;
    };
  }()
);
function fh(t) {
  const e = /^([-+\w]{1,25})(:?\/\/|:)/.exec(t);
  return e && e[1] || "";
}
function lh(t, e) {
  t = t || 10;
  const n = new Array(t), r = new Array(t);
  let i = 0, o = 0, c;
  return e = e !== void 0 ? e : 1e3, function(y) {
    const w = Date.now(), _ = r[o];
    c || (c = w), n[i] = y, r[i] = w;
    let m = o, I = 0;
    for (; m !== i; )
      I += n[m++], m = m % t;
    if (i = (i + 1) % t, i === o && (o = (o + 1) % t), w - c < e)
      return;
    const z = _ && w - _;
    return z ? Math.round(I * 1e3 / z) : void 0;
  };
}
function Lo(t, e) {
  let n = 0;
  const r = lh(50, 250);
  return (i) => {
    const o = i.loaded, c = i.lengthComputable ? i.total : void 0, f = o - n, y = r(f), w = o <= c;
    n = o;
    const _ = {
      loaded: o,
      total: c,
      progress: c ? o / c : void 0,
      bytes: f,
      rate: y || void 0,
      estimated: y && c && w ? (c - o) / y : void 0,
      event: i
    };
    _[e ? "download" : "upload"] = !0, t(_);
  };
}
const dh = typeof XMLHttpRequest < "u", hh = dh && function(t) {
  return new Promise(function(n, r) {
    let i = t.data;
    const o = Ht.from(t.headers).normalize();
    let { responseType: c, withXSRFToken: f } = t, y;
    function w() {
      t.cancelToken && t.cancelToken.unsubscribe(y), t.signal && t.signal.removeEventListener("abort", y);
    }
    let _;
    if (C.isFormData(i)) {
      if (Bt.hasStandardBrowserEnv || Bt.hasStandardBrowserWebWorkerEnv)
        o.setContentType(!1);
      else if ((_ = o.getContentType()) !== !1) {
        const [N, ...M] = _ ? _.split(";").map((Z) => Z.trim()).filter(Boolean) : [];
        o.setContentType([N || "multipart/form-data", ...M].join("; "));
      }
    }
    let m = new XMLHttpRequest();
    if (t.auth) {
      const N = t.auth.username || "", M = t.auth.password ? unescape(encodeURIComponent(t.auth.password)) : "";
      o.set("Authorization", "Basic " + btoa(N + ":" + M));
    }
    const I = Xa(t.baseURL, t.url);
    m.open(t.method.toUpperCase(), Wa(I, t.params, t.paramsSerializer), !0), m.timeout = t.timeout;
    function z() {
      if (!m)
        return;
      const N = Ht.from(
        "getAllResponseHeaders" in m && m.getAllResponseHeaders()
      ), Z = {
        data: !c || c === "text" || c === "json" ? m.responseText : m.response,
        status: m.status,
        statusText: m.statusText,
        headers: N,
        config: t,
        request: m
      };
      sh(function(Q) {
        n(Q), w();
      }, function(Q) {
        r(Q), w();
      }, Z), m = null;
    }
    if ("onloadend" in m ? m.onloadend = z : m.onreadystatechange = function() {
      !m || m.readyState !== 4 || m.status === 0 && !(m.responseURL && m.responseURL.indexOf("file:") === 0) || setTimeout(z);
    }, m.onabort = function() {
      m && (r(new xe("Request aborted", xe.ECONNABORTED, t, m)), m = null);
    }, m.onerror = function() {
      r(new xe("Network Error", xe.ERR_NETWORK, t, m)), m = null;
    }, m.ontimeout = function() {
      let M = t.timeout ? "timeout of " + t.timeout + "ms exceeded" : "timeout exceeded";
      const Z = t.transitional || Ka;
      t.timeoutErrorMessage && (M = t.timeoutErrorMessage), r(new xe(
        M,
        Z.clarifyTimeoutError ? xe.ETIMEDOUT : xe.ECONNABORTED,
        t,
        m
      )), m = null;
    }, Bt.hasStandardBrowserEnv && (f && C.isFunction(f) && (f = f(t)), f || f !== !1 && uh(I))) {
      const N = t.xsrfHeaderName && t.xsrfCookieName && oh.read(t.xsrfCookieName);
      N && o.set(t.xsrfHeaderName, N);
    }
    i === void 0 && o.setContentType(null), "setRequestHeader" in m && C.forEach(o.toJSON(), function(M, Z) {
      m.setRequestHeader(Z, M);
    }), C.isUndefined(t.withCredentials) || (m.withCredentials = !!t.withCredentials), c && c !== "json" && (m.responseType = t.responseType), typeof t.onDownloadProgress == "function" && m.addEventListener("progress", Lo(t.onDownloadProgress, !0)), typeof t.onUploadProgress == "function" && m.upload && m.upload.addEventListener("progress", Lo(t.onUploadProgress)), (t.cancelToken || t.signal) && (y = (N) => {
      m && (r(!N || N.type ? new hr(null, t, m) : N), m.abort(), m = null);
    }, t.cancelToken && t.cancelToken.subscribe(y), t.signal && (t.signal.aborted ? y() : t.signal.addEventListener("abort", y)));
    const k = fh(I);
    if (k && Bt.protocols.indexOf(k) === -1) {
      r(new xe("Unsupported protocol " + k + ":", xe.ERR_BAD_REQUEST, t));
      return;
    }
    m.send(i || null);
  });
}, ds = {
  http: Dd,
  xhr: hh
};
C.forEach(ds, (t, e) => {
  if (t) {
    try {
      Object.defineProperty(t, "name", { value: e });
    } catch {
    }
    Object.defineProperty(t, "adapterName", { value: e });
  }
});
const Mo = (t) => `- ${t}`, ph = (t) => C.isFunction(t) || t === null || t === !1, Za = {
  getAdapter: (t) => {
    t = C.isArray(t) ? t : [t];
    const { length: e } = t;
    let n, r;
    const i = {};
    for (let o = 0; o < e; o++) {
      n = t[o];
      let c;
      if (r = n, !ph(n) && (r = ds[(c = String(n)).toLowerCase()], r === void 0))
        throw new xe(`Unknown adapter '${c}'`);
      if (r)
        break;
      i[c || "#" + o] = r;
    }
    if (!r) {
      const o = Object.entries(i).map(
        ([f, y]) => `adapter ${f} ` + (y === !1 ? "is not supported by the environment" : "is not available in the build")
      );
      let c = e ? o.length > 1 ? `since :
` + o.map(Mo).join(`
`) : " " + Mo(o[0]) : "as no adapter specified";
      throw new xe(
        "There is no suitable adapter to dispatch the request " + c,
        "ERR_NOT_SUPPORT"
      );
    }
    return r;
  },
  adapters: ds
};
function rs(t) {
  if (t.cancelToken && t.cancelToken.throwIfRequested(), t.signal && t.signal.aborted)
    throw new hr(null, t);
}
function Ho(t) {
  return rs(t), t.headers = Ht.from(t.headers), t.data = ns.call(
    t,
    t.transformRequest
  ), ["post", "put", "patch"].indexOf(t.method) !== -1 && t.headers.setContentType("application/x-www-form-urlencoded", !1), Za.getAdapter(t.adapter || Ms.adapter)(t).then(function(r) {
    return rs(t), r.data = ns.call(
      t,
      t.transformResponse,
      r
    ), r.headers = Ht.from(r.headers), r;
  }, function(r) {
    return Ja(r) || (rs(t), r && r.response && (r.response.data = ns.call(
      t,
      t.transformResponse,
      r.response
    ), r.response.headers = Ht.from(r.response.headers))), Promise.reject(r);
  });
}
const $o = (t) => t instanceof Ht ? t.toJSON() : t;
function Nn(t, e) {
  e = e || {};
  const n = {};
  function r(w, _, m) {
    return C.isPlainObject(w) && C.isPlainObject(_) ? C.merge.call({ caseless: m }, w, _) : C.isPlainObject(_) ? C.merge({}, _) : C.isArray(_) ? _.slice() : _;
  }
  function i(w, _, m) {
    if (C.isUndefined(_)) {
      if (!C.isUndefined(w))
        return r(void 0, w, m);
    } else
      return r(w, _, m);
  }
  function o(w, _) {
    if (!C.isUndefined(_))
      return r(void 0, _);
  }
  function c(w, _) {
    if (C.isUndefined(_)) {
      if (!C.isUndefined(w))
        return r(void 0, w);
    } else
      return r(void 0, _);
  }
  function f(w, _, m) {
    if (m in e)
      return r(w, _);
    if (m in t)
      return r(void 0, w);
  }
  const y = {
    url: o,
    method: o,
    data: o,
    baseURL: c,
    transformRequest: c,
    transformResponse: c,
    paramsSerializer: c,
    timeout: c,
    timeoutMessage: c,
    withCredentials: c,
    withXSRFToken: c,
    adapter: c,
    responseType: c,
    xsrfCookieName: c,
    xsrfHeaderName: c,
    onUploadProgress: c,
    onDownloadProgress: c,
    decompress: c,
    maxContentLength: c,
    maxBodyLength: c,
    beforeRedirect: c,
    transport: c,
    httpAgent: c,
    httpsAgent: c,
    cancelToken: c,
    socketPath: c,
    responseEncoding: c,
    validateStatus: f,
    headers: (w, _) => i($o(w), $o(_), !0)
  };
  return C.forEach(Object.keys(Object.assign({}, t, e)), function(_) {
    const m = y[_] || i, I = m(t[_], e[_], _);
    C.isUndefined(I) && m !== f || (n[_] = I);
  }), n;
}
const ec = "1.6.2", Hs = {};
["object", "boolean", "number", "function", "string", "symbol"].forEach((t, e) => {
  Hs[t] = function(r) {
    return typeof r === t || "a" + (e < 1 ? "n " : " ") + t;
  };
});
const qo = {};
Hs.transitional = function(e, n, r) {
  function i(o, c) {
    return "[Axios v" + ec + "] Transitional option '" + o + "'" + c + (r ? ". " + r : "");
  }
  return (o, c, f) => {
    if (e === !1)
      throw new xe(
        i(c, " has been removed" + (n ? " in " + n : "")),
        xe.ERR_DEPRECATED
      );
    return n && !qo[c] && (qo[c] = !0, console.warn(
      i(
        c,
        " has been deprecated since v" + n + " and will be removed in the near future"
      )
    )), e ? e(o, c, f) : !0;
  };
};
function Ah(t, e, n) {
  if (typeof t != "object")
    throw new xe("options must be an object", xe.ERR_BAD_OPTION_VALUE);
  const r = Object.keys(t);
  let i = r.length;
  for (; i-- > 0; ) {
    const o = r[i], c = e[o];
    if (c) {
      const f = t[o], y = f === void 0 || c(f, o, t);
      if (y !== !0)
        throw new xe("option " + o + " must be " + y, xe.ERR_BAD_OPTION_VALUE);
      continue;
    }
    if (n !== !0)
      throw new xe("Unknown option " + o, xe.ERR_BAD_OPTION);
  }
}
const hs = {
  assertOptions: Ah,
  validators: Hs
}, Xt = hs.validators;
class Yr {
  constructor(e) {
    this.defaults = e, this.interceptors = {
      request: new Fo(),
      response: new Fo()
    };
  }
  /**
   * Dispatch a request
   *
   * @param {String|Object} configOrUrl The config specific for this request (merged with this.defaults)
   * @param {?Object} config
   *
   * @returns {Promise} The Promise to be fulfilled
   */
  request(e, n) {
    typeof e == "string" ? (n = n || {}, n.url = e) : n = e || {}, n = Nn(this.defaults, n);
    const { transitional: r, paramsSerializer: i, headers: o } = n;
    r !== void 0 && hs.assertOptions(r, {
      silentJSONParsing: Xt.transitional(Xt.boolean),
      forcedJSONParsing: Xt.transitional(Xt.boolean),
      clarifyTimeoutError: Xt.transitional(Xt.boolean)
    }, !1), i != null && (C.isFunction(i) ? n.paramsSerializer = {
      serialize: i
    } : hs.assertOptions(i, {
      encode: Xt.function,
      serialize: Xt.function
    }, !0)), n.method = (n.method || this.defaults.method || "get").toLowerCase();
    let c = o && C.merge(
      o.common,
      o[n.method]
    );
    o && C.forEach(
      ["delete", "get", "head", "post", "put", "patch", "common"],
      (k) => {
        delete o[k];
      }
    ), n.headers = Ht.concat(c, o);
    const f = [];
    let y = !0;
    this.interceptors.request.forEach(function(N) {
      typeof N.runWhen == "function" && N.runWhen(n) === !1 || (y = y && N.synchronous, f.unshift(N.fulfilled, N.rejected));
    });
    const w = [];
    this.interceptors.response.forEach(function(N) {
      w.push(N.fulfilled, N.rejected);
    });
    let _, m = 0, I;
    if (!y) {
      const k = [Ho.bind(this), void 0];
      for (k.unshift.apply(k, f), k.push.apply(k, w), I = k.length, _ = Promise.resolve(n); m < I; )
        _ = _.then(k[m++], k[m++]);
      return _;
    }
    I = f.length;
    let z = n;
    for (m = 0; m < I; ) {
      const k = f[m++], N = f[m++];
      try {
        z = k(z);
      } catch (M) {
        N.call(this, M);
        break;
      }
    }
    try {
      _ = Ho.call(this, z);
    } catch (k) {
      return Promise.reject(k);
    }
    for (m = 0, I = w.length; m < I; )
      _ = _.then(w[m++], w[m++]);
    return _;
  }
  getUri(e) {
    e = Nn(this.defaults, e);
    const n = Xa(e.baseURL, e.url);
    return Wa(n, e.params, e.paramsSerializer);
  }
}
C.forEach(["delete", "get", "head", "options"], function(e) {
  Yr.prototype[e] = function(n, r) {
    return this.request(Nn(r || {}, {
      method: e,
      url: n,
      data: (r || {}).data
    }));
  };
});
C.forEach(["post", "put", "patch"], function(e) {
  function n(r) {
    return function(o, c, f) {
      return this.request(Nn(f || {}, {
        method: e,
        headers: r ? {
          "Content-Type": "multipart/form-data"
        } : {},
        url: o,
        data: c
      }));
    };
  }
  Yr.prototype[e] = n(), Yr.prototype[e + "Form"] = n(!0);
});
const Lr = Yr;
class $s {
  constructor(e) {
    if (typeof e != "function")
      throw new TypeError("executor must be a function.");
    let n;
    this.promise = new Promise(function(o) {
      n = o;
    });
    const r = this;
    this.promise.then((i) => {
      if (!r._listeners)
        return;
      let o = r._listeners.length;
      for (; o-- > 0; )
        r._listeners[o](i);
      r._listeners = null;
    }), this.promise.then = (i) => {
      let o;
      const c = new Promise((f) => {
        r.subscribe(f), o = f;
      }).then(i);
      return c.cancel = function() {
        r.unsubscribe(o);
      }, c;
    }, e(function(o, c, f) {
      r.reason || (r.reason = new hr(o, c, f), n(r.reason));
    });
  }
  /**
   * Throws a `CanceledError` if cancellation has been requested.
   */
  throwIfRequested() {
    if (this.reason)
      throw this.reason;
  }
  /**
   * Subscribe to the cancel signal
   */
  subscribe(e) {
    if (this.reason) {
      e(this.reason);
      return;
    }
    this._listeners ? this._listeners.push(e) : this._listeners = [e];
  }
  /**
   * Unsubscribe from the cancel signal
   */
  unsubscribe(e) {
    if (!this._listeners)
      return;
    const n = this._listeners.indexOf(e);
    n !== -1 && this._listeners.splice(n, 1);
  }
  /**
   * Returns an object that contains a new `CancelToken` and a function that, when called,
   * cancels the `CancelToken`.
   */
  static source() {
    let e;
    return {
      token: new $s(function(i) {
        e = i;
      }),
      cancel: e
    };
  }
}
const yh = $s;
function wh(t) {
  return function(n) {
    return t.apply(null, n);
  };
}
function gh(t) {
  return C.isObject(t) && t.isAxiosError === !0;
}
const ps = {
  Continue: 100,
  SwitchingProtocols: 101,
  Processing: 102,
  EarlyHints: 103,
  Ok: 200,
  Created: 201,
  Accepted: 202,
  NonAuthoritativeInformation: 203,
  NoContent: 204,
  ResetContent: 205,
  PartialContent: 206,
  MultiStatus: 207,
  AlreadyReported: 208,
  ImUsed: 226,
  MultipleChoices: 300,
  MovedPermanently: 301,
  Found: 302,
  SeeOther: 303,
  NotModified: 304,
  UseProxy: 305,
  Unused: 306,
  TemporaryRedirect: 307,
  PermanentRedirect: 308,
  BadRequest: 400,
  Unauthorized: 401,
  PaymentRequired: 402,
  Forbidden: 403,
  NotFound: 404,
  MethodNotAllowed: 405,
  NotAcceptable: 406,
  ProxyAuthenticationRequired: 407,
  RequestTimeout: 408,
  Conflict: 409,
  Gone: 410,
  LengthRequired: 411,
  PreconditionFailed: 412,
  PayloadTooLarge: 413,
  UriTooLong: 414,
  UnsupportedMediaType: 415,
  RangeNotSatisfiable: 416,
  ExpectationFailed: 417,
  ImATeapot: 418,
  MisdirectedRequest: 421,
  UnprocessableEntity: 422,
  Locked: 423,
  FailedDependency: 424,
  TooEarly: 425,
  UpgradeRequired: 426,
  PreconditionRequired: 428,
  TooManyRequests: 429,
  RequestHeaderFieldsTooLarge: 431,
  UnavailableForLegalReasons: 451,
  InternalServerError: 500,
  NotImplemented: 501,
  BadGateway: 502,
  ServiceUnavailable: 503,
  GatewayTimeout: 504,
  HttpVersionNotSupported: 505,
  VariantAlsoNegotiates: 506,
  InsufficientStorage: 507,
  LoopDetected: 508,
  NotExtended: 510,
  NetworkAuthenticationRequired: 511
};
Object.entries(ps).forEach(([t, e]) => {
  ps[e] = t;
});
const xh = ps;
function tc(t) {
  const e = new Lr(t), n = Na(Lr.prototype.request, e);
  return C.extend(n, Lr.prototype, e, { allOwnKeys: !0 }), C.extend(n, e, null, { allOwnKeys: !0 }), n.create = function(i) {
    return tc(Nn(t, i));
  }, n;
}
const qe = tc(Ms);
qe.Axios = Lr;
qe.CanceledError = hr;
qe.CancelToken = yh;
qe.isCancel = Ja;
qe.VERSION = ec;
qe.toFormData = ki;
qe.AxiosError = xe;
qe.Cancel = qe.CanceledError;
qe.all = function(e) {
  return Promise.all(e);
};
qe.spread = wh;
qe.isAxiosError = gh;
qe.mergeConfig = Nn;
qe.AxiosHeaders = Ht;
qe.formToJSON = (t) => Va(C.isHTMLForm(t) ? new FormData(t) : t);
qe.getAdapter = Za.getAdapter;
qe.HttpStatusCode = xh;
qe.default = qe;
async function _h(t) {
  var e;
  const { params: n, method: r, url: i, headers: o, body: c, overrides: f } = t, y = {
    headers: o,
    method: r,
    url: i,
    params: n,
    data: c,
    withCredentials: (e = f == null ? void 0 : f.WITH_CREDENTIALS) != null ? e : !0
  };
  try {
    const w = await qe(y);
    return {
      status: w.status,
      statusText: w.statusText,
      data: w.data,
      headers: w.headers,
      config: w.config
    };
  } catch (w) {
    const _ = w;
    if (_.response)
      return _.response;
    throw w;
  }
}
var mh = { exports: {} };
(function(t) {
  var e = Object.prototype.hasOwnProperty, n = "~";
  function r() {
  }
  Object.create && (r.prototype = /* @__PURE__ */ Object.create(null), new r().__proto__ || (n = !1));
  function i(y, w, _) {
    this.fn = y, this.context = w, this.once = _ || !1;
  }
  function o(y, w, _, m, I) {
    if (typeof _ != "function")
      throw new TypeError("The listener must be a function");
    var z = new i(_, m || y, I), k = n ? n + w : w;
    return y._events[k] ? y._events[k].fn ? y._events[k] = [y._events[k], z] : y._events[k].push(z) : (y._events[k] = z, y._eventsCount++), y;
  }
  function c(y, w) {
    --y._eventsCount === 0 ? y._events = new r() : delete y._events[w];
  }
  function f() {
    this._events = new r(), this._eventsCount = 0;
  }
  f.prototype.eventNames = function() {
    var w = [], _, m;
    if (this._eventsCount === 0)
      return w;
    for (m in _ = this._events)
      e.call(_, m) && w.push(n ? m.slice(1) : m);
    return Object.getOwnPropertySymbols ? w.concat(Object.getOwnPropertySymbols(_)) : w;
  }, f.prototype.listeners = function(w) {
    var _ = n ? n + w : w, m = this._events[_];
    if (!m)
      return [];
    if (m.fn)
      return [m.fn];
    for (var I = 0, z = m.length, k = new Array(z); I < z; I++)
      k[I] = m[I].fn;
    return k;
  }, f.prototype.listenerCount = function(w) {
    var _ = n ? n + w : w, m = this._events[_];
    return m ? m.fn ? 1 : m.length : 0;
  }, f.prototype.emit = function(w, _, m, I, z, k) {
    var N = n ? n + w : w;
    if (!this._events[N])
      return !1;
    var M = this._events[N], Z = arguments.length, ve, Q;
    if (M.fn) {
      switch (M.once && this.removeListener(w, M.fn, void 0, !0), Z) {
        case 1:
          return M.fn.call(M.context), !0;
        case 2:
          return M.fn.call(M.context, _), !0;
        case 3:
          return M.fn.call(M.context, _, m), !0;
        case 4:
          return M.fn.call(M.context, _, m, I), !0;
        case 5:
          return M.fn.call(M.context, _, m, I, z), !0;
        case 6:
          return M.fn.call(M.context, _, m, I, z, k), !0;
      }
      for (Q = 1, ve = new Array(Z - 1); Q < Z; Q++)
        ve[Q - 1] = arguments[Q];
      M.fn.apply(M.context, ve);
    } else {
      var ke = M.length, Ce;
      for (Q = 0; Q < ke; Q++)
        switch (M[Q].once && this.removeListener(w, M[Q].fn, void 0, !0), Z) {
          case 1:
            M[Q].fn.call(M[Q].context);
            break;
          case 2:
            M[Q].fn.call(M[Q].context, _);
            break;
          case 3:
            M[Q].fn.call(M[Q].context, _, m);
            break;
          case 4:
            M[Q].fn.call(M[Q].context, _, m, I);
            break;
          default:
            if (!ve)
              for (Ce = 1, ve = new Array(Z - 1); Ce < Z; Ce++)
                ve[Ce - 1] = arguments[Ce];
            M[Q].fn.apply(M[Q].context, ve);
        }
    }
    return !0;
  }, f.prototype.on = function(w, _, m) {
    return o(this, w, _, m, !1);
  }, f.prototype.once = function(w, _, m) {
    return o(this, w, _, m, !0);
  }, f.prototype.removeListener = function(w, _, m, I) {
    var z = n ? n + w : w;
    if (!this._events[z])
      return this;
    if (!_)
      return c(this, z), this;
    var k = this._events[z];
    if (k.fn)
      k.fn === _ && (!I || k.once) && (!m || k.context === m) && c(this, z);
    else {
      for (var N = 0, M = [], Z = k.length; N < Z; N++)
        (k[N].fn !== _ || I && !k[N].once || m && k[N].context !== m) && M.push(k[N]);
      M.length ? this._events[z] = M.length === 1 ? M[0] : M : c(this, z);
    }
    return this;
  }, f.prototype.removeAllListeners = function(w) {
    var _;
    return w ? (_ = n ? n + w : w, this._events[_] && c(this, _)) : (this._events = new r(), this._eventsCount = 0), this;
  }, f.prototype.off = f.prototype.removeListener, f.prototype.addListener = f.prototype.on, f.prefixed = n, f.EventEmitter = f, t.exports = f;
})(mh);
var nc = Object.defineProperty, bh = Object.getOwnPropertyDescriptor, zi = (t, e) => {
  for (var n in e)
    nc(t, n, { get: e[n], enumerable: !0 });
}, Be = (t, e, n, r) => {
  for (var i = r > 1 ? void 0 : r ? bh(e, n) : e, o = t.length - 1, c; o >= 0; o--)
    (c = t[o]) && (i = (r ? c(e, n, i) : c(i)) || i);
  return r && i && nc(e, n, i), i;
}, Eh = /^m(\/[0-9]+')+$/, rc = (t) => t.replace("'", ""), vh = "ed25519 seed", Th = 2147483648, Bh = (t) => {
  const n = Ci.create(Ns, vh).update(ba(t)).digest(), r = n.slice(0, 32), i = n.slice(32);
  return {
    key: r,
    chainCode: i
  };
}, Sh = ({ key: t, chainCode: e }, n) => {
  const r = new ArrayBuffer(4);
  new DataView(r).setUint32(0, n);
  const i = new Uint8Array(r), o = new Uint8Array([0]), c = new Uint8Array([...o, ...t, ...i]), f = Ci.create(Ns, e).update(c).digest(), y = f.slice(0, 32), w = f.slice(32);
  return {
    key: y,
    chainCode: w
  };
}, Ih = (t) => Eh.test(t) ? !t.split("/").slice(1).map(rc).some(Number.isNaN) : !1, Uh = (t, e, n = Th) => {
  if (!Ih(t))
    throw new Error("Invalid derivation path");
  const { key: r, chainCode: i } = Bh(e);
  return t.split("/").slice(1).map(rc).map((c) => parseInt(c, 10)).reduce((c, f) => Sh(c, f + n), { key: r, chainCode: i });
}, Ch = "1.21.0";
async function Ph(t) {
  return new Promise((e) => {
    setTimeout(e, t);
  });
}
var Qo = "/v1";
function Oh(t) {
  let e = `${t}`;
  return e.endsWith("/") && (e = e.substring(0, e.length - 1)), e.endsWith(Qo) || (e = `${e}${Qo}`), e;
}
var ic = 2e5, sc = 20, Rh = 20, kh = "0x1::aptos_coin::AptosCoin";
function Fi(t) {
  let e, n, r;
  return typeof t == "object" ? (e = t.hashFunction, n = t.ttlMs, r = t.tags) : e = t, (i, o, c) => {
    if (c.value != null)
      c.value = jo(c.value, e, n, r);
    else if (c.get != null)
      c.get = jo(c.get, e, n, r);
    else
      throw new Error("Only put a Memoize() decorator on a method or get accessor.");
  };
}
function oc(t, e) {
  return Fi({
    ttlMs: t,
    hashFunction: e
  });
}
var Mr = /* @__PURE__ */ new Map();
function Nh(t) {
  const e = /* @__PURE__ */ new Set();
  for (const n of t) {
    const r = Mr.get(n);
    if (r)
      for (const i of r)
        e.has(i) || (i.clear(), e.add(i));
  }
  return e.size;
}
function jo(t, e, n = 0, r) {
  const i = Symbol("__memoized_map__");
  return function(...o) {
    let c;
    const f = this;
    f.hasOwnProperty(i) || Object.defineProperty(f, i, {
      configurable: !1,
      enumerable: !1,
      writable: !1,
      value: /* @__PURE__ */ new Map()
    });
    const y = f[i];
    if (Array.isArray(r))
      for (const w of r)
        Mr.has(w) ? Mr.get(w).push(y) : Mr.set(w, [y]);
    if (e || o.length > 0 || n > 0) {
      let w;
      e === !0 ? w = o.map((I) => I.toString()).join("!") : e ? w = e.apply(f, o) : w = o[0];
      const _ = `${w}__timestamp`;
      let m = !1;
      if (n > 0)
        if (!y.has(_))
          m = !0;
        else {
          const I = y.get(_);
          m = Date.now() - I > n;
        }
      y.has(w) && !m ? c = y.get(w) : (c = t.apply(f, o), y.set(w, c), n > 0 && y.set(_, Date.now()));
    } else {
      const w = f;
      y.has(w) ? c = y.get(w) : (c = t.apply(f, o), y.set(w, c));
    }
    return c;
  };
}
var ac = class extends Error {
  constructor(t, e, n) {
    super(n), this.name = "AptosApiError", this.url = e.url, this.status = e.status, this.statusText = e.statusText, this.data = e.data, this.request = t;
  }
}, zh = {
  400: "Bad Request",
  401: "Unauthorized",
  403: "Forbidden",
  404: "Not Found",
  429: "Too Many Requests",
  500: "Internal Server Error",
  502: "Bad Gateway",
  503: "Service Unavailable"
};
async function Fh(t, e, n, r, i, o) {
  const c = {
    ...o == null ? void 0 : o.HEADERS,
    "x-aptos-client": `aptos-ts-sdk/${Ch}`,
    "content-type": r ?? "application/json"
  };
  return o != null && o.TOKEN && (c.Authorization = `Bearer ${o == null ? void 0 : o.TOKEN}`), await _h({ url: t, method: e, body: n, params: i, headers: c, overrides: o });
}
async function cc(t) {
  const { url: e, endpoint: n, method: r, body: i, contentType: o, params: c, overrides: f } = t, y = `${e}/${n ?? ""}`, w = await Fh(y, r, i, o, c, f), _ = {
    status: w.status,
    statusText: w.statusText,
    data: w.data,
    headers: w.headers,
    config: w.config,
    url: y
  };
  if (_.status >= 200 && _.status < 300)
    return _;
  const m = zh[_.status];
  throw new ac(t, _, m ?? "Generic Error");
}
async function ct(t) {
  return await cc({ ...t, method: "GET" });
}
async function Yn(t) {
  return await cc({ ...t, method: "POST" });
}
async function Go(t) {
  const e = [];
  let n;
  const r = t.params;
  for (; ; ) {
    r.start = n;
    const i = await ct({
      url: t.url,
      endpoint: t.endpoint,
      params: r,
      originMethod: t.originMethod,
      overrides: t.overrides
    });
    if (n = i.headers["x-aptos-cursor"], delete i.headers, e.push(...i.data), n == null)
      break;
  }
  return e;
}
var Dh = {
  mainnet: "https://indexer.mainnet.aptoslabs.com/v1/graphql",
  testnet: "https://indexer-testnet.staging.gcp.aptosdev.com/v1/graphql",
  devnet: "https://indexer-devnet.staging.gcp.aptosdev.com/v1/graphql",
  local: "http://127.0.0.1:8090/v1/graphql"
}, Lh = {
  mainnet: "https://fullnode.mainnet.aptoslabs.com/v1",
  testnet: "https://fullnode.testnet.aptoslabs.com/v1",
  devnet: "https://fullnode.devnet.aptoslabs.com/v1",
  local: "http://127.0.0.1:8080/v1"
}, Hr = /* @__PURE__ */ ((t) => (t.MAINNET = "mainnet", t.TESTNET = "testnet", t.DEVNET = "devnet", t.LOCAL = "local", t))(Hr || {}), J = class $r {
  /**
   * Creates new hex string from Buffer
   * @param buffer A buffer to convert
   * @returns New HexString
   */
  static fromBuffer(e) {
    return $r.fromUint8Array(e);
  }
  /**
   * Creates new hex string from Uint8Array
   * @param arr Uint8Array to convert
   * @returns New HexString
   */
  static fromUint8Array(e) {
    return new $r(ma(e));
  }
  /**
   * Ensures `hexString` is instance of `HexString` class
   * @param hexString String to check
   * @returns New HexString if `hexString` is regular string or `hexString` if it is HexString instance
   * @example
   * ```
   *  const regularString = "string";
   *  const hexString = new HexString("string"); // "0xstring"
   *  HexString.ensure(regularString); // "0xstring"
   *  HexString.ensure(hexString); // "0xstring"
   * ```
   */
  static ensure(e) {
    return typeof e == "string" ? new $r(e) : e;
  }
  /**
   * Creates new HexString instance from regular string. If specified string already starts with "0x" prefix,
   * it will not add another one
   * @param hexString String to convert
   * @example
   * ```
   *  const string = "string";
   *  new HexString(string); // "0xstring"
   * ```
   */
  constructor(e) {
    e.startsWith("0x") ? this.hexString = e : this.hexString = `0x${e}`;
  }
  /**
   * Getter for inner hexString
   * @returns Inner hex string
   */
  hex() {
    return this.hexString;
  }
  /**
   * Getter for inner hexString without prefix
   * @returns Inner hex string without prefix
   * @example
   * ```
   *  const hexString = new HexString("string"); // "0xstring"
   *  hexString.noPrefix(); // "string"
   * ```
   */
  noPrefix() {
    return this.hexString.slice(2);
  }
  /**
   * Overrides default `toString` method
   * @returns Inner hex string
   */
  toString() {
    return this.hex();
  }
  /**
   * Trimmes extra zeroes in the begining of a string
   * @returns Inner hexString without leading zeroes
   * @example
   * ```
   *  new HexString("0x000000string").toShortString(); // result = "0xstring"
   * ```
   */
  toShortString() {
    return `0x${this.hexString.replace(/^0x0*/, "")}`;
  }
  /**
   * Converts hex string to a Uint8Array
   * @returns Uint8Array from inner hexString without prefix
   */
  toUint8Array() {
    return Uint8Array.from(ba(this.noPrefix()));
  }
}, Oe = {};
zi(Oe, {
  AccountAddress: () => Ue,
  AccountAuthenticator: () => tn,
  AccountAuthenticatorEd25519: () => mc,
  AccountAuthenticatorMultiEd25519: () => Ec,
  ArgumentABI: () => $i,
  AuthenticationKey: () => xs,
  ChainId: () => eo,
  ChangeSet: () => s0,
  Ed25519PublicKey: () => gt,
  Ed25519Signature: () => zt,
  EntryFunction: () => Li,
  EntryFunctionABI: () => sr,
  FeePayerRawTransaction: () => Js,
  Identifier: () => Ze,
  Module: () => i0,
  ModuleId: () => ir,
  MultiAgentRawTransaction: () => Vs,
  MultiEd25519PublicKey: () => Di,
  MultiEd25519Signature: () => Qs,
  MultiSig: () => Qc,
  MultiSigTransactionPayload: () => $c,
  RawTransaction: () => $n,
  RawTransactionWithData: () => Ys,
  RotationProofChallenge: () => a0,
  Script: () => Ks,
  ScriptABI: () => qi,
  SignedTransaction: () => Mi,
  StructTag: () => Hn,
  Transaction: () => fu,
  TransactionArgument: () => _t,
  TransactionArgumentAddress: () => ao,
  TransactionArgumentBool: () => uo,
  TransactionArgumentU128: () => so,
  TransactionArgumentU16: () => no,
  TransactionArgumentU256: () => oo,
  TransactionArgumentU32: () => ro,
  TransactionArgumentU64: () => io,
  TransactionArgumentU8: () => to,
  TransactionArgumentU8Vector: () => co,
  TransactionAuthenticator: () => Fn,
  TransactionAuthenticatorEd25519: () => js,
  TransactionAuthenticatorFeePayer: () => xc,
  TransactionAuthenticatorMultiAgent: () => wc,
  TransactionAuthenticatorMultiEd25519: () => Gs,
  TransactionPayload: () => xr,
  TransactionPayloadEntryFunction: () => Zs,
  TransactionPayloadMultisig: () => Xc,
  TransactionPayloadScript: () => Xs,
  TransactionScriptABI: () => fo,
  TypeArgumentABI: () => Hi,
  TypeTag: () => Ye,
  TypeTagAddress: () => yn,
  TypeTagBool: () => Dn,
  TypeTagParser: () => gr,
  TypeTagParserError: () => Lc,
  TypeTagSigner: () => kc,
  TypeTagStruct: () => wn,
  TypeTagU128: () => Mn,
  TypeTagU16: () => pr,
  TypeTagU256: () => yr,
  TypeTagU32: () => Ar,
  TypeTagU64: () => Ln,
  TypeTagU8: () => nn,
  TypeTagVector: () => wr,
  UserTransaction: () => lu,
  WriteSet: () => o0,
  objectStructTag: () => e0,
  optionStructTag: () => Zh,
  stringStructTag: () => Ws
});
var Mh = {};
zi(Mh, {
  Deserializer: () => qs,
  Serializer: () => Ne,
  bcsSerializeBool: () => Vh,
  bcsSerializeBytes: () => Zt,
  bcsSerializeFixedBytes: () => Xh,
  bcsSerializeStr: () => Jh,
  bcsSerializeU128: () => Kh,
  bcsSerializeU16: () => Gh,
  bcsSerializeU256: () => Yh,
  bcsSerializeU32: () => Wh,
  bcsSerializeU8: () => As,
  bcsSerializeUint64: () => jh,
  bcsToBytes: () => $t,
  deserializeVector: () => tt,
  serializeVector: () => Ke,
  serializeVectorWithFunc: () => Qh
});
var Hh = 2 ** 8 - 1, $h = 2 ** 16 - 1, rr = 2 ** 32 - 1, uc = BigInt(2 ** 64) - BigInt(1), fc = BigInt(2 ** 128) - BigInt(1), qh = BigInt(2 ** 256) - BigInt(1), Ne = class {
  constructor() {
    this.buffer = new ArrayBuffer(64), this.offset = 0;
  }
  ensureBufferWillHandleSize(t) {
    for (; this.buffer.byteLength < this.offset + t; ) {
      const e = new ArrayBuffer(this.buffer.byteLength * 2);
      new Uint8Array(e).set(new Uint8Array(this.buffer)), this.buffer = e;
    }
  }
  serialize(t) {
    this.ensureBufferWillHandleSize(t.length), new Uint8Array(this.buffer, this.offset).set(t), this.offset += t.length;
  }
  serializeWithFunction(t, e, n) {
    this.ensureBufferWillHandleSize(e);
    const r = new DataView(this.buffer, this.offset);
    t.apply(r, [0, n, !0]), this.offset += e;
  }
  /**
   * Serializes a string. UTF8 string is supported. Serializes the string's bytes length "l" first,
   * and then serializes "l" bytes of the string content.
   *
   * BCS layout for "string": string_length | string_content. string_length is the bytes length of
   * the string that is uleb128 encoded. string_length is a u32 integer.
   *
   * @example
   * ```ts
   * const serializer = new Serializer();
   * serializer.serializeStr("çå∞≠¢õß∂ƒ∫");
   * assert(serializer.getBytes() === new Uint8Array([24, 0xc3, 0xa7, 0xc3, 0xa5, 0xe2, 0x88, 0x9e,
   * 0xe2, 0x89, 0xa0, 0xc2, 0xa2, 0xc3, 0xb5, 0xc3, 0x9f, 0xe2, 0x88, 0x82, 0xc6, 0x92, 0xe2, 0x88, 0xab]));
   * ```
   */
  serializeStr(t) {
    const e = new TextEncoder();
    this.serializeBytes(e.encode(t));
  }
  /**
   * Serializes an array of bytes.
   *
   * BCS layout for "bytes": bytes_length | bytes. bytes_length is the length of the bytes array that is
   * uleb128 encoded. bytes_length is a u32 integer.
   */
  serializeBytes(t) {
    this.serializeU32AsUleb128(t.length), this.serialize(t);
  }
  /**
   * Serializes an array of bytes with known length. Therefore length doesn't need to be
   * serialized to help deserialization.  When deserializing, the number of
   * bytes to deserialize needs to be passed in.
   */
  serializeFixedBytes(t) {
    this.serialize(t);
  }
  /**
   * Serializes a boolean value.
   *
   * BCS layout for "boolean": One byte. "0x01" for True and "0x00" for False.
   */
  serializeBool(t) {
    if (typeof t != "boolean")
      throw new Error("Value needs to be a boolean");
    const e = t ? 1 : 0;
    this.serialize(new Uint8Array([e]));
  }
  serializeU8(t) {
    this.serialize(new Uint8Array([t]));
  }
  serializeU16(t) {
    this.serializeWithFunction(DataView.prototype.setUint16, 2, t);
  }
  serializeU32(t) {
    this.serializeWithFunction(DataView.prototype.setUint32, 4, t);
  }
  serializeU64(t) {
    const e = BigInt(t.toString()) & BigInt(rr), n = BigInt(t.toString()) >> BigInt(32);
    this.serializeU32(Number(e)), this.serializeU32(Number(n));
  }
  serializeU128(t) {
    const e = BigInt(t.toString()) & uc, n = BigInt(t.toString()) >> BigInt(64);
    this.serializeU64(e), this.serializeU64(n);
  }
  serializeU256(t) {
    const e = BigInt(t.toString()) & fc, n = BigInt(t.toString()) >> BigInt(128);
    this.serializeU128(e), this.serializeU128(n);
  }
  serializeU32AsUleb128(t) {
    let e = t;
    const n = [];
    for (; e >>> 7; )
      n.push(e & 127 | 128), e >>>= 7;
    n.push(e), this.serialize(new Uint8Array(n));
  }
  /**
   * Returns the buffered bytes
   */
  getBytes() {
    return new Uint8Array(this.buffer).slice(0, this.offset);
  }
};
Be([
  gn(0, Hh)
], Ne.prototype, "serializeU8", 1);
Be([
  gn(0, $h)
], Ne.prototype, "serializeU16", 1);
Be([
  gn(0, rr)
], Ne.prototype, "serializeU32", 1);
Be([
  gn(BigInt(0), uc)
], Ne.prototype, "serializeU64", 1);
Be([
  gn(BigInt(0), fc)
], Ne.prototype, "serializeU128", 1);
Be([
  gn(BigInt(0), qh)
], Ne.prototype, "serializeU256", 1);
Be([
  gn(0, rr)
], Ne.prototype, "serializeU32AsUleb128", 1);
function gn(t, e, n) {
  return (r, i, o) => {
    const c = o.value;
    return o.value = function(y) {
      const w = BigInt(y.toString());
      if (w > BigInt(e.toString()) || w < BigInt(t.toString()))
        throw new Error(n || "Value is out of range");
      c.apply(this, [y]);
    }, o;
  };
}
var qs = class {
  constructor(t) {
    this.buffer = new ArrayBuffer(t.length), new Uint8Array(this.buffer).set(t, 0), this.offset = 0;
  }
  read(t) {
    if (this.offset + t > this.buffer.byteLength)
      throw new Error("Reached to the end of buffer");
    const e = this.buffer.slice(this.offset, this.offset + t);
    return this.offset += t, e;
  }
  /**
   * Deserializes a string. UTF8 string is supported. Reads the string's bytes length "l" first,
   * and then reads "l" bytes of content. Decodes the byte array into a string.
   *
   * BCS layout for "string": string_length | string_content. string_length is the bytes length of
   * the string that is uleb128 encoded. string_length is a u32 integer.
   *
   * @example
   * ```ts
   * const deserializer = new Deserializer(new Uint8Array([24, 0xc3, 0xa7, 0xc3, 0xa5, 0xe2, 0x88, 0x9e,
   * 0xe2, 0x89, 0xa0, 0xc2, 0xa2, 0xc3, 0xb5, 0xc3, 0x9f, 0xe2, 0x88, 0x82, 0xc6, 0x92, 0xe2, 0x88, 0xab]));
   * assert(deserializer.deserializeStr() === "çå∞≠¢õß∂ƒ∫");
   * ```
   */
  deserializeStr() {
    const t = this.deserializeBytes();
    return new TextDecoder().decode(t);
  }
  /**
   * Deserializes an array of bytes.
   *
   * BCS layout for "bytes": bytes_length | bytes. bytes_length is the length of the bytes array that is
   * uleb128 encoded. bytes_length is a u32 integer.
   */
  deserializeBytes() {
    const t = this.deserializeUleb128AsU32();
    return new Uint8Array(this.read(t));
  }
  /**
   * Deserializes an array of bytes. The number of bytes to read is already known.
   *
   */
  deserializeFixedBytes(t) {
    return new Uint8Array(this.read(t));
  }
  /**
   * Deserializes a boolean value.
   *
   * BCS layout for "boolean": One byte. "0x01" for True and "0x00" for False.
   */
  deserializeBool() {
    const t = new Uint8Array(this.read(1))[0];
    if (t !== 1 && t !== 0)
      throw new Error("Invalid boolean value");
    return t === 1;
  }
  /**
   * Deserializes a uint8 number.
   *
   * BCS layout for "uint8": One byte. Binary format in little-endian representation.
   */
  deserializeU8() {
    return new DataView(this.read(1)).getUint8(0);
  }
  /**
   * Deserializes a uint16 number.
   *
   * BCS layout for "uint16": Two bytes. Binary format in little-endian representation.
   * @example
   * ```ts
   * const deserializer = new Deserializer(new Uint8Array([0x34, 0x12]));
   * assert(deserializer.deserializeU16() === 4660);
   * ```
   */
  deserializeU16() {
    return new DataView(this.read(2)).getUint16(0, !0);
  }
  /**
   * Deserializes a uint32 number.
   *
   * BCS layout for "uint32": Four bytes. Binary format in little-endian representation.
   * @example
   * ```ts
   * const deserializer = new Deserializer(new Uint8Array([0x78, 0x56, 0x34, 0x12]));
   * assert(deserializer.deserializeU32() === 305419896);
   * ```
   */
  deserializeU32() {
    return new DataView(this.read(4)).getUint32(0, !0);
  }
  /**
   * Deserializes a uint64 number.
   *
   * BCS layout for "uint64": Eight bytes. Binary format in little-endian representation.
   * @example
   * ```ts
   * const deserializer = new Deserializer(new Uint8Array([0x00, 0xEF, 0xCD, 0xAB, 0x78, 0x56, 0x34, 0x12]));
   * assert(deserializer.deserializeU64() === 1311768467750121216);
   * ```
   */
  deserializeU64() {
    const t = this.deserializeU32(), e = this.deserializeU32();
    return BigInt(BigInt(e) << BigInt(32) | BigInt(t));
  }
  /**
   * Deserializes a uint128 number.
   *
   * BCS layout for "uint128": Sixteen bytes. Binary format in little-endian representation.
   */
  deserializeU128() {
    const t = this.deserializeU64(), e = this.deserializeU64();
    return BigInt(e << BigInt(64) | t);
  }
  /**
   * Deserializes a uint256 number.
   *
   * BCS layout for "uint256": Thirty-two bytes. Binary format in little-endian representation.
   */
  deserializeU256() {
    const t = this.deserializeU128(), e = this.deserializeU128();
    return BigInt(e << BigInt(128) | t);
  }
  /**
   * Deserializes a uleb128 encoded uint32 number.
   *
   * BCS use uleb128 encoding in two cases: (1) lengths of variable-length sequences and (2) tags of enum values
   */
  deserializeUleb128AsU32() {
    let t = BigInt(0), e = 0;
    for (; t < rr; ) {
      const n = this.deserializeU8();
      if (t |= BigInt(n & 127) << BigInt(e), !(n & 128))
        break;
      e += 7;
    }
    if (t > rr)
      throw new Error("Overflow while parsing uleb128-encoded uint32 value");
    return Number(t);
  }
};
function Ke(t, e) {
  e.serializeU32AsUleb128(t.length), t.forEach((n) => {
    n.serialize(e);
  });
}
function Qh(t, e) {
  const n = new Ne();
  n.serializeU32AsUleb128(t.length);
  const r = n[e];
  return t.forEach((i) => {
    r.call(n, i);
  }), n.getBytes();
}
function tt(t, e) {
  const n = t.deserializeUleb128AsU32(), r = [];
  for (let i = 0; i < n; i += 1)
    r.push(e.deserialize(t));
  return r;
}
function $t(t) {
  const e = new Ne();
  return t.serialize(e), e.getBytes();
}
function jh(t) {
  const e = new Ne();
  return e.serializeU64(t), e.getBytes();
}
function As(t) {
  const e = new Ne();
  return e.serializeU8(t), e.getBytes();
}
function Gh(t) {
  const e = new Ne();
  return e.serializeU16(t), e.getBytes();
}
function Wh(t) {
  const e = new Ne();
  return e.serializeU32(t), e.getBytes();
}
function Kh(t) {
  const e = new Ne();
  return e.serializeU128(t), e.getBytes();
}
function Yh(t) {
  const e = new Ne();
  return e.serializeU256(t), e.getBytes();
}
function Vh(t) {
  const e = new Ne();
  return e.serializeBool(t), e.getBytes();
}
function Jh(t) {
  const e = new Ne();
  return e.serializeStr(t), e.getBytes();
}
function Zt(t) {
  const e = new Ne();
  return e.serializeBytes(t), e.getBytes();
}
function Xh(t) {
  const e = new Ne();
  return e.serializeFixedBytes(t), e.getBytes();
}
var Vr = class wt {
  constructor(e) {
    if (e.length !== wt.LENGTH)
      throw new Error("Expected address of length 32");
    this.address = e;
  }
  /**
   * Creates AccountAddress from a hex string.
   * @param addr Hex string can be with a prefix or without a prefix,
   *   e.g. '0x1aa' or '1aa'. Hex string will be left padded with 0s if too short.
   */
  static fromHex(e) {
    let n = J.ensure(e);
    n.noPrefix().length % 2 !== 0 && (n = new J(`0${n.noPrefix()}`));
    const r = n.toUint8Array();
    if (r.length > wt.LENGTH)
      throw new Error("Hex string is too long. Address's length is 32 bytes.");
    if (r.length === wt.LENGTH)
      return new wt(r);
    const i = new Uint8Array(wt.LENGTH);
    return i.set(r, wt.LENGTH - r.length), new wt(i);
  }
  /**
   * Checks if the string is a valid AccountAddress
   * @param addr Hex string can be with a prefix or without a prefix,
   *   e.g. '0x1aa' or '1aa'. Hex string will be left padded with 0s if too short.
   */
  static isValid(e) {
    if (e === "")
      return !1;
    let n = J.ensure(e);
    return n.noPrefix().length % 2 !== 0 && (n = new J(`0${n.noPrefix()}`)), n.toUint8Array().length <= wt.LENGTH;
  }
  /**
   * Return a hex string from account Address.
   */
  toHexString() {
    return J.fromUint8Array(this.address).hex();
  }
  serialize(e) {
    e.serializeFixedBytes(this.address);
  }
  static deserialize(e) {
    return new wt(e.deserializeFixedBytes(wt.LENGTH));
  }
  /**
   * Standardizes an address to the format "0x" followed by 64 lowercase hexadecimal digits.
   */
  static standardizeAddress(e) {
    const n = e.toLowerCase();
    return `0x${(n.startsWith("0x") ? n.slice(2) : n).padStart(64, "0")}`;
  }
};
Vr.LENGTH = 32;
Vr.CORE_CODE_ADDRESS = Vr.fromHex("0x1");
var Ue = Vr, lc = class qr {
  constructor(e) {
    if (e.length !== qr.LENGTH)
      throw new Error(`Ed25519PublicKey length should be ${qr.LENGTH}`);
    this.value = e;
  }
  toBytes() {
    return this.value;
  }
  serialize(e) {
    e.serializeBytes(this.value);
  }
  static deserialize(e) {
    const n = e.deserializeBytes();
    return new qr(n);
  }
};
lc.LENGTH = 32;
var gt = lc, dc = class Qr {
  constructor(e) {
    if (this.value = e, e.length !== Qr.LENGTH)
      throw new Error(`Ed25519Signature length should be ${Qr.LENGTH}`);
  }
  serialize(e) {
    e.serializeBytes(this.value);
  }
  static deserialize(e) {
    const n = e.deserializeBytes();
    return new Qr(n);
  }
};
dc.LENGTH = 64;
var zt = dc, ys = 32, Di = class hc {
  /**
   * Public key for a K-of-N multisig transaction. A K-of-N multisig transaction means that for such a
   * transaction to be executed, at least K out of the N authorized signers have signed the transaction
   * and passed the check conducted by the chain.
   *
   * @see {@link
   * https://aptos.dev/guides/creating-a-signed-transaction#multisignature-transactions | Creating a Signed Transaction}
   *
   * @param public_keys A list of public keys
   * @param threshold At least "threshold" signatures must be valid
   */
  constructor(e, n) {
    if (this.public_keys = e, this.threshold = n, n > ys)
      throw new Error(`"threshold" cannot be larger than ${ys}`);
  }
  /**
   * Converts a MultiEd25519PublicKey into bytes with: bytes = p1_bytes | ... | pn_bytes | threshold
   */
  toBytes() {
    const e = new Uint8Array(this.public_keys.length * gt.LENGTH + 1);
    return this.public_keys.forEach((n, r) => {
      e.set(n.value, r * gt.LENGTH);
    }), e[this.public_keys.length * gt.LENGTH] = this.threshold, e;
  }
  serialize(e) {
    e.serializeBytes(this.toBytes());
  }
  static deserialize(e) {
    const n = e.deserializeBytes(), r = n[n.length - 1], i = [];
    for (let o = 0; o < n.length - 1; o += gt.LENGTH) {
      const c = o;
      i.push(new gt(n.subarray(c, c + gt.LENGTH)));
    }
    return new hc(i, r);
  }
}, pc = class Vn {
  /**
   * Signature for a K-of-N multisig transaction.
   *
   * @see {@link
   * https://aptos.dev/guides/creating-a-signed-transaction#multisignature-transactions | Creating a Signed Transaction}
   *
   * @param signatures A list of ed25519 signatures
   * @param bitmap 4 bytes, at most 32 signatures are supported. If Nth bit value is `1`, the Nth
   * signature should be provided in `signatures`. Bits are read from left to right
   */
  constructor(e, n) {
    if (this.signatures = e, this.bitmap = n, n.length !== Vn.BITMAP_LEN)
      throw new Error(`"bitmap" length should be ${Vn.BITMAP_LEN}`);
  }
  /**
   * Converts a MultiEd25519Signature into bytes with `bytes = s1_bytes | ... | sn_bytes | bitmap`
   */
  toBytes() {
    const e = new Uint8Array(this.signatures.length * zt.LENGTH + Vn.BITMAP_LEN);
    return this.signatures.forEach((n, r) => {
      e.set(n.value, r * zt.LENGTH);
    }), e.set(this.bitmap, this.signatures.length * zt.LENGTH), e;
  }
  /**
   * Helper method to create a bitmap out of the specified bit positions
   * @param bits The bitmap positions that should be set. A position starts at index 0.
   * Valid position should range between 0 and 31.
   * @example
   * Here's an example of valid `bits`
   * ```
   * [0, 2, 31]
   * ```
   * `[0, 2, 31]` means the 1st, 3rd and 32nd bits should be set in the bitmap.
   * The result bitmap should be 0b1010000000000000000000000000001
   *
   * @returns bitmap that is 32bit long
   */
  static createBitmap(e) {
    const r = new Uint8Array([0, 0, 0, 0]), i = /* @__PURE__ */ new Set();
    return e.forEach((o) => {
      if (o >= ys)
        throw new Error(`Invalid bit value ${o}.`);
      if (i.has(o))
        throw new Error("Duplicated bits detected.");
      i.add(o);
      const c = Math.floor(o / 8);
      let f = r[c];
      f |= 128 >> o % 8, r[c] = f;
    }), r;
  }
  serialize(e) {
    e.serializeBytes(this.toBytes());
  }
  static deserialize(e) {
    const n = e.deserializeBytes(), r = n.subarray(n.length - 4), i = [];
    for (let o = 0; o < n.length - r.length; o += zt.LENGTH) {
      const c = o;
      i.push(new zt(n.subarray(c, c + zt.LENGTH)));
    }
    return new Vn(i, r);
  }
};
pc.BITMAP_LEN = 4;
var Qs = pc, Fn = class {
  static deserialize(t) {
    const e = t.deserializeUleb128AsU32();
    switch (e) {
      case 0:
        return js.load(t);
      case 1:
        return Gs.load(t);
      case 2:
        return wc.load(t);
      case 3:
        return xc.load(t);
      default:
        throw new Error(`Unknown variant index for TransactionAuthenticator: ${e}`);
    }
  }
}, js = class Ac extends Fn {
  /**
   * An authenticator for single signature.
   *
   * @param public_key Client's public key.
   * @param signature Signature of a raw transaction.
   * @see {@link https://aptos.dev/guides/creating-a-signed-transaction/ | Creating a Signed Transaction}
   * for details about generating a signature.
   */
  constructor(e, n) {
    super(), this.public_key = e, this.signature = n;
  }
  serialize(e) {
    e.serializeU32AsUleb128(0), this.public_key.serialize(e), this.signature.serialize(e);
  }
  static load(e) {
    const n = gt.deserialize(e), r = zt.deserialize(e);
    return new Ac(n, r);
  }
}, Gs = class yc extends Fn {
  /**
   * An authenticator for multiple signatures.
   *
   * @param public_key
   * @param signature
   *
   */
  constructor(e, n) {
    super(), this.public_key = e, this.signature = n;
  }
  serialize(e) {
    e.serializeU32AsUleb128(1), this.public_key.serialize(e), this.signature.serialize(e);
  }
  static load(e) {
    const n = Di.deserialize(e), r = Qs.deserialize(e);
    return new yc(n, r);
  }
}, wc = class gc extends Fn {
  constructor(e, n, r) {
    super(), this.sender = e, this.secondary_signer_addresses = n, this.secondary_signers = r;
  }
  serialize(e) {
    e.serializeU32AsUleb128(2), this.sender.serialize(e), Ke(this.secondary_signer_addresses, e), Ke(this.secondary_signers, e);
  }
  static load(e) {
    const n = tn.deserialize(e), r = tt(e, Ue), i = tt(e, tn);
    return new gc(n, r, i);
  }
}, xc = class _c extends Fn {
  constructor(e, n, r, i) {
    super(), this.sender = e, this.secondary_signer_addresses = n, this.secondary_signers = r, this.fee_payer = i;
  }
  serialize(e) {
    e.serializeU32AsUleb128(3), this.sender.serialize(e), Ke(this.secondary_signer_addresses, e), Ke(this.secondary_signers, e), this.fee_payer.address.serialize(e), this.fee_payer.authenticator.serialize(e);
  }
  static load(e) {
    const n = tn.deserialize(e), r = tt(e, Ue), i = tt(e, tn), o = Ue.deserialize(e), c = tn.deserialize(e), f = { address: o, authenticator: c };
    return new _c(n, r, i, f);
  }
}, tn = class {
  static deserialize(t) {
    const e = t.deserializeUleb128AsU32();
    switch (e) {
      case 0:
        return mc.load(t);
      case 1:
        return Ec.load(t);
      default:
        throw new Error(`Unknown variant index for AccountAuthenticator: ${e}`);
    }
  }
}, mc = class bc extends tn {
  constructor(e, n) {
    super(), this.public_key = e, this.signature = n;
  }
  serialize(e) {
    e.serializeU32AsUleb128(0), this.public_key.serialize(e), this.signature.serialize(e);
  }
  static load(e) {
    const n = gt.deserialize(e), r = zt.deserialize(e);
    return new bc(n, r);
  }
}, Ec = class vc extends tn {
  constructor(e, n) {
    super(), this.public_key = e, this.signature = n;
  }
  serialize(e) {
    e.serializeU32AsUleb128(1), this.public_key.serialize(e), this.signature.serialize(e);
  }
  static load(e) {
    const n = Di.deserialize(e), r = Qs.deserialize(e);
    return new vc(n, r);
  }
}, Ze = class Tc {
  constructor(e) {
    this.value = e;
  }
  serialize(e) {
    e.serializeStr(this.value);
  }
  static deserialize(e) {
    const n = e.deserializeStr();
    return new Tc(n);
  }
}, Ye = class {
  static deserialize(t) {
    const e = t.deserializeUleb128AsU32();
    switch (e) {
      case 0:
        return Dn.load(t);
      case 1:
        return nn.load(t);
      case 2:
        return Ln.load(t);
      case 3:
        return Mn.load(t);
      case 4:
        return yn.load(t);
      case 5:
        return kc.load(t);
      case 6:
        return wr.load(t);
      case 7:
        return wn.load(t);
      case 8:
        return pr.load(t);
      case 9:
        return Ar.load(t);
      case 10:
        return yr.load(t);
      default:
        throw new Error(`Unknown variant index for TypeTag: ${e}`);
    }
  }
}, Dn = class Bc extends Ye {
  serialize(e) {
    e.serializeU32AsUleb128(0);
  }
  static load(e) {
    return new Bc();
  }
}, nn = class Sc extends Ye {
  serialize(e) {
    e.serializeU32AsUleb128(1);
  }
  static load(e) {
    return new Sc();
  }
}, pr = class Ic extends Ye {
  serialize(e) {
    e.serializeU32AsUleb128(8);
  }
  static load(e) {
    return new Ic();
  }
}, Ar = class Uc extends Ye {
  serialize(e) {
    e.serializeU32AsUleb128(9);
  }
  static load(e) {
    return new Uc();
  }
}, Ln = class Cc extends Ye {
  serialize(e) {
    e.serializeU32AsUleb128(2);
  }
  static load(e) {
    return new Cc();
  }
}, Mn = class Pc extends Ye {
  serialize(e) {
    e.serializeU32AsUleb128(3);
  }
  static load(e) {
    return new Pc();
  }
}, yr = class Oc extends Ye {
  serialize(e) {
    e.serializeU32AsUleb128(10);
  }
  static load(e) {
    return new Oc();
  }
}, yn = class Rc extends Ye {
  serialize(e) {
    e.serializeU32AsUleb128(4);
  }
  static load(e) {
    return new Rc();
  }
}, kc = class Nc extends Ye {
  serialize(e) {
    e.serializeU32AsUleb128(5);
  }
  static load(e) {
    return new Nc();
  }
}, wr = class zc extends Ye {
  constructor(e) {
    super(), this.value = e;
  }
  serialize(e) {
    e.serializeU32AsUleb128(6), this.value.serialize(e);
  }
  static load(e) {
    const n = Ye.deserialize(e);
    return new zc(n);
  }
}, wn = class Fc extends Ye {
  constructor(e) {
    super(), this.value = e;
  }
  serialize(e) {
    e.serializeU32AsUleb128(7), this.value.serialize(e);
  }
  static load(e) {
    const n = Hn.deserialize(e);
    return new Fc(n);
  }
  isStringTypeTag() {
    return this.value.module_name.value === "string" && this.value.name.value === "String" && this.value.address.toHexString() === Ue.CORE_CODE_ADDRESS.toHexString();
  }
}, Hn = class ws {
  constructor(e, n, r, i) {
    this.address = e, this.module_name = n, this.name = r, this.type_args = i;
  }
  /**
   * Converts a string literal to a StructTag
   * @param structTag String literal in format "AcountAddress::module_name::ResourceName",
   *   e.g. "0x1::aptos_coin::AptosCoin"
   * @returns
   */
  static fromString(e) {
    const n = new gr(e).parseTypeTag();
    return new ws(
      n.value.address,
      n.value.module_name,
      n.value.name,
      n.value.type_args
    );
  }
  serialize(e) {
    this.address.serialize(e), this.module_name.serialize(e), this.name.serialize(e), Ke(this.type_args, e);
  }
  static deserialize(e) {
    const n = Ue.deserialize(e), r = Ze.deserialize(e), i = Ze.deserialize(e), o = tt(e, Ye);
    return new ws(n, r, i, o);
  }
}, Ws = new Hn(
  Ue.fromHex("0x1"),
  new Ze("string"),
  new Ze("String"),
  []
);
function Zh(t) {
  return new Hn(Ue.fromHex("0x1"), new Ze("option"), new Ze("Option"), [t]);
}
function e0(t) {
  return new Hn(Ue.fromHex("0x1"), new Ze("object"), new Ze("Object"), [t]);
}
function en(t) {
  throw new Lc(t);
}
function Wo(t) {
  return !!t.match(/\s/);
}
function Ko(t) {
  return !!t.match(/[_A-Za-z0-9]/g);
}
function t0(t) {
  return !!t.match(/T\d+/g);
}
function n0(t, e) {
  const n = t[e];
  if (n === ":") {
    if (t.slice(e, e + 2) === "::")
      return [["COLON", "::"], 2];
    en("Unrecognized token.");
  } else {
    if (n === "<")
      return [["LT", "<"], 1];
    if (n === ">")
      return [["GT", ">"], 1];
    if (n === ",")
      return [["COMMA", ","], 1];
    if (Wo(n)) {
      let r = "";
      for (let i = e; i < t.length; i += 1) {
        const o = t[i];
        if (Wo(o))
          r = `${r}${o}`;
        else
          break;
      }
      return [["SPACE", r], r.length];
    } else if (Ko(n)) {
      let r = "";
      for (let i = e; i < t.length; i += 1) {
        const o = t[i];
        if (Ko(o))
          r = `${r}${o}`;
        else
          break;
      }
      return t0(r) ? [["GENERIC", r], r.length] : [["IDENT", r], r.length];
    }
  }
  throw new Error("Unrecognized token.");
}
function r0(t) {
  let e = 0;
  const n = [];
  for (; e < t.length; ) {
    const [r, i] = n0(t, e);
    r[0] !== "SPACE" && n.push(r), e += i;
  }
  return n;
}
var gr = class Dc {
  constructor(e, n) {
    this.typeTags = [], this.tokens = r0(e), this.typeTags = n || [];
  }
  consume(e) {
    const n = this.tokens.shift();
    (!n || n[1] !== e) && en("Invalid type tag.");
  }
  /**
   * Consumes all of an unused generic field, mostly applicable to object
   *
   * Note: This is recursive.  it can be problematic if there's bad input
   * @private
   */
  consumeWholeGeneric() {
    for (this.consume("<"); this.tokens[0][1] !== ">"; )
      this.tokens[0][1] === "<" ? this.consumeWholeGeneric() : this.tokens.shift();
    this.consume(">");
  }
  parseCommaList(e, n) {
    const r = [];
    for (this.tokens.length <= 0 && en("Invalid type tag."); this.tokens[0][1] !== e && (r.push(this.parseTypeTag()), !(this.tokens.length > 0 && this.tokens[0][1] === e || (this.consume(","), this.tokens.length > 0 && this.tokens[0][1] === e && n))); )
      this.tokens.length <= 0 && en("Invalid type tag.");
    return r;
  }
  parseTypeTag() {
    this.tokens.length === 0 && en("Invalid type tag.");
    const [e, n] = this.tokens.shift();
    if (n === "u8")
      return new nn();
    if (n === "u16")
      return new pr();
    if (n === "u32")
      return new Ar();
    if (n === "u64")
      return new Ln();
    if (n === "u128")
      return new Mn();
    if (n === "u256")
      return new yr();
    if (n === "bool")
      return new Dn();
    if (n === "address")
      return new yn();
    if (n === "vector") {
      this.consume("<");
      const r = this.parseTypeTag();
      return this.consume(">"), new wr(r);
    }
    if (n === "string")
      return new wn(Ws);
    if (e === "IDENT" && (n.startsWith("0x") || n.startsWith("0X"))) {
      const r = Ue.fromHex(n);
      this.consume("::");
      const [i, o] = this.tokens.shift();
      i !== "IDENT" && en("Invalid type tag."), this.consume("::");
      const [c, f] = this.tokens.shift();
      if (c !== "IDENT" && en("Invalid type tag."), Ue.CORE_CODE_ADDRESS.toHexString() === r.toHexString() && o === "object" && f === "Object")
        return this.consumeWholeGeneric(), new yn();
      let y = [];
      this.tokens.length > 0 && this.tokens[0][1] === "<" && (this.consume("<"), y = this.parseCommaList(">", !0), this.consume(">"));
      const w = new Hn(r, new Ze(o), new Ze(f), y);
      return new wn(w);
    }
    if (e === "GENERIC") {
      this.typeTags.length === 0 && en("Can't convert generic type since no typeTags were specified.");
      const r = parseInt(n.substring(1), 10);
      return new Dc(this.typeTags[r]).parseTypeTag();
    }
    throw new Error("Invalid type tag.");
  }
}, Lc = class extends Error {
  constructor(t) {
    super(t), this.name = "TypeTagParserError";
  }
}, $n = class Mc {
  /**
   * RawTransactions contain the metadata and payloads that can be submitted to Aptos chain for execution.
   * RawTransactions must be signed before Aptos chain can execute them.
   *
   * @param sender Account address of the sender.
   * @param sequence_number Sequence number of this transaction. This must match the sequence number stored in
   *   the sender's account at the time the transaction executes.
   * @param payload Instructions for the Aptos Blockchain, including publishing a module,
   *   execute a entry function or execute a script payload.
   * @param max_gas_amount Maximum total gas to spend for this transaction. The account must have more
   *   than this gas or the transaction will be discarded during validation.
   * @param gas_unit_price Price to be paid per gas unit.
   * @param expiration_timestamp_secs The blockchain timestamp at which the blockchain would discard this transaction.
   * @param chain_id The chain ID of the blockchain that this transaction is intended to be run on.
   */
  constructor(e, n, r, i, o, c, f) {
    this.sender = e, this.sequence_number = n, this.payload = r, this.max_gas_amount = i, this.gas_unit_price = o, this.expiration_timestamp_secs = c, this.chain_id = f;
  }
  serialize(e) {
    this.sender.serialize(e), e.serializeU64(this.sequence_number), this.payload.serialize(e), e.serializeU64(this.max_gas_amount), e.serializeU64(this.gas_unit_price), e.serializeU64(this.expiration_timestamp_secs), this.chain_id.serialize(e);
  }
  static deserialize(e) {
    const n = Ue.deserialize(e), r = e.deserializeU64(), i = xr.deserialize(e), o = e.deserializeU64(), c = e.deserializeU64(), f = e.deserializeU64(), y = eo.deserialize(e);
    return new Mc(
      n,
      r,
      i,
      o,
      c,
      f,
      y
    );
  }
}, Ks = class Hc {
  /**
   * Scripts contain the Move bytecodes payload that can be submitted to Aptos chain for execution.
   * @param code Move bytecode
   * @param ty_args Type arguments that bytecode requires.
   *
   * @example
   * A coin transfer function has one type argument "CoinType".
   * ```
   * public(script) fun transfer<CoinType>(from: &signer, to: address, amount: u64,)
   * ```
   * @param args Arugments to bytecode function.
   *
   * @example
   * A coin transfer function has three arugments "from", "to" and "amount".
   * ```
   * public(script) fun transfer<CoinType>(from: &signer, to: address, amount: u64,)
   * ```
   */
  constructor(e, n, r) {
    this.code = e, this.ty_args = n, this.args = r;
  }
  serialize(e) {
    e.serializeBytes(this.code), Ke(this.ty_args, e), Ke(this.args, e);
  }
  static deserialize(e) {
    const n = e.deserializeBytes(), r = tt(e, Ye), i = tt(e, _t);
    return new Hc(n, r, i);
  }
}, Li = class jr {
  /**
   * Contains the payload to run a function within a module.
   * @param module_name Fully qualified module name. ModuleId consists of account address and module name.
   * @param function_name The function to run.
   * @param ty_args Type arguments that move function requires.
   *
   * @example
   * A coin transfer function has one type argument "CoinType".
   * ```
   * public(script) fun transfer<CoinType>(from: &signer, to: address, amount: u64,)
   * ```
   * @param args Arugments to the move function.
   *
   * @example
   * A coin transfer function has three arugments "from", "to" and "amount".
   * ```
   * public(script) fun transfer<CoinType>(from: &signer, to: address, amount: u64,)
   * ```
   */
  constructor(e, n, r, i) {
    this.module_name = e, this.function_name = n, this.ty_args = r, this.args = i;
  }
  /**
   *
   * @param module Fully qualified module name in format "AccountAddress::module_name" e.g. "0x1::coin"
   * @param func Function name
   * @param ty_args Type arguments that move function requires.
   *
   * @example
   * A coin transfer function has one type argument "CoinType".
   * ```
   * public(script) fun transfer<CoinType>(from: &signer, to: address, amount: u64,)
   * ```
   * @param args Arugments to the move function.
   *
   * @example
   * A coin transfer function has three arugments "from", "to" and "amount".
   * ```
   * public(script) fun transfer<CoinType>(from: &signer, to: address, amount: u64,)
   * ```
   * @returns
   */
  static natural(e, n, r, i) {
    return new jr(ir.fromStr(e), new Ze(n), r, i);
  }
  /**
   * `natual` is deprecated, please use `natural`
   *
   * @deprecated.
   */
  static natual(e, n, r, i) {
    return jr.natural(e, n, r, i);
  }
  serialize(e) {
    this.module_name.serialize(e), this.function_name.serialize(e), Ke(this.ty_args, e), e.serializeU32AsUleb128(this.args.length), this.args.forEach((n) => {
      e.serializeBytes(n);
    });
  }
  static deserialize(e) {
    const n = ir.deserialize(e), r = Ze.deserialize(e), i = tt(e, Ye), o = e.deserializeUleb128AsU32(), c = [];
    for (let y = 0; y < o; y += 1)
      c.push(e.deserializeBytes());
    const f = c;
    return new jr(n, r, i, f);
  }
}, $c = class qc {
  /**
   * Contains the payload to run a multisig account transaction.
   * @param transaction_payload The payload of the multisig transaction. This can only be EntryFunction for now but
   * Script might be supported in the future.
   */
  constructor(e) {
    this.transaction_payload = e;
  }
  serialize(e) {
    e.serializeU32AsUleb128(0), this.transaction_payload.serialize(e);
  }
  static deserialize(e) {
    return e.deserializeUleb128AsU32(), new qc(Li.deserialize(e));
  }
}, Qc = class jc {
  /**
   * Contains the payload to run a multisig account transaction.
   * @param multisig_address The multisig account address the transaction will be executed as.
   * @param transaction_payload The payload of the multisig transaction. This is optional when executing a multisig
   *  transaction whose payload is already stored on chain.
   */
  constructor(e, n) {
    this.multisig_address = e, this.transaction_payload = n;
  }
  serialize(e) {
    this.multisig_address.serialize(e), this.transaction_payload === void 0 ? e.serializeBool(!1) : (e.serializeBool(!0), this.transaction_payload.serialize(e));
  }
  static deserialize(e) {
    const n = Ue.deserialize(e), r = e.deserializeBool();
    let i;
    return r && (i = $c.deserialize(e)), new jc(n, i);
  }
}, i0 = class Gc {
  /**
   * Contains the bytecode of a Move module that can be published to the Aptos chain.
   * @param code Move bytecode of a module.
   */
  constructor(e) {
    this.code = e;
  }
  serialize(e) {
    e.serializeBytes(this.code);
  }
  static deserialize(e) {
    const n = e.deserializeBytes();
    return new Gc(n);
  }
}, ir = class gs {
  /**
   * Full name of a module.
   * @param address The account address.
   * @param name The name of the module under the account at "address".
   */
  constructor(e, n) {
    this.address = e, this.name = n;
  }
  /**
   * Converts a string literal to a ModuleId
   * @param moduleId String literal in format "AccountAddress::module_name", e.g. "0x1::coin"
   * @returns
   */
  static fromStr(e) {
    const n = e.split("::");
    if (n.length !== 2)
      throw new Error("Invalid module id.");
    return new gs(Ue.fromHex(new J(n[0])), new Ze(n[1]));
  }
  serialize(e) {
    this.address.serialize(e), this.name.serialize(e);
  }
  static deserialize(e) {
    const n = Ue.deserialize(e), r = Ze.deserialize(e);
    return new gs(n, r);
  }
}, s0 = class {
  serialize(t) {
    throw new Error("Not implemented.");
  }
  static deserialize(t) {
    throw new Error("Not implemented.");
  }
}, o0 = class {
  serialize(t) {
    throw new Error("Not implmented.");
  }
  static deserialize(t) {
    throw new Error("Not implmented.");
  }
}, Mi = class Wc {
  /**
   * A SignedTransaction consists of a raw transaction and an authenticator. The authenticator
   * contains a client's public key and the signature of the raw transaction.
   *
   * @see {@link https://aptos.dev/guides/creating-a-signed-transaction/ | Creating a Signed Transaction}
   *
   * @param raw_txn
   * @param authenticator Contains a client's public key and the signature of the raw transaction.
   *   Authenticator has 3 flavors: single signature, multi-signature and multi-agent.
   *   @see authenticator.ts for details.
   */
  constructor(e, n) {
    this.raw_txn = e, this.authenticator = n;
  }
  serialize(e) {
    this.raw_txn.serialize(e), this.authenticator.serialize(e);
  }
  static deserialize(e) {
    const n = $n.deserialize(e), r = Fn.deserialize(e);
    return new Wc(n, r);
  }
}, Ys = class {
  static deserialize(t) {
    const e = t.deserializeUleb128AsU32();
    switch (e) {
      case 0:
        return Vs.load(t);
      case 1:
        return Js.load(t);
      default:
        throw new Error(`Unknown variant index for RawTransactionWithData: ${e}`);
    }
  }
}, Vs = class Kc extends Ys {
  constructor(e, n) {
    super(), this.raw_txn = e, this.secondary_signer_addresses = n;
  }
  serialize(e) {
    e.serializeU32AsUleb128(0), this.raw_txn.serialize(e), Ke(this.secondary_signer_addresses, e);
  }
  static load(e) {
    const n = $n.deserialize(e), r = tt(e, Ue);
    return new Kc(n, r);
  }
}, Js = class Yc extends Ys {
  constructor(e, n, r) {
    super(), this.raw_txn = e, this.secondary_signer_addresses = n, this.fee_payer_address = r;
  }
  serialize(e) {
    e.serializeU32AsUleb128(1), this.raw_txn.serialize(e), Ke(this.secondary_signer_addresses, e), this.fee_payer_address.serialize(e);
  }
  static load(e) {
    const n = $n.deserialize(e), r = tt(e, Ue), i = Ue.deserialize(e);
    return new Yc(n, r, i);
  }
}, xr = class {
  static deserialize(t) {
    const e = t.deserializeUleb128AsU32();
    switch (e) {
      case 0:
        return Xs.load(t);
      case 2:
        return Zs.load(t);
      case 3:
        return Xc.load(t);
      default:
        throw new Error(`Unknown variant index for TransactionPayload: ${e}`);
    }
  }
}, Xs = class Vc extends xr {
  constructor(e) {
    super(), this.value = e;
  }
  serialize(e) {
    e.serializeU32AsUleb128(0), this.value.serialize(e);
  }
  static load(e) {
    const n = Ks.deserialize(e);
    return new Vc(n);
  }
}, Zs = class Jc extends xr {
  constructor(e) {
    super(), this.value = e;
  }
  serialize(e) {
    e.serializeU32AsUleb128(2), this.value.serialize(e);
  }
  static load(e) {
    const n = Li.deserialize(e);
    return new Jc(n);
  }
}, Xc = class Zc extends xr {
  constructor(e) {
    super(), this.value = e;
  }
  serialize(e) {
    e.serializeU32AsUleb128(3), this.value.serialize(e);
  }
  static load(e) {
    const n = Qc.deserialize(e);
    return new Zc(n);
  }
}, eo = class eu {
  constructor(e) {
    this.value = e;
  }
  serialize(e) {
    e.serializeU8(this.value);
  }
  static deserialize(e) {
    const n = e.deserializeU8();
    return new eu(n);
  }
}, _t = class {
  static deserialize(t) {
    const e = t.deserializeUleb128AsU32();
    switch (e) {
      case 0:
        return to.load(t);
      case 1:
        return io.load(t);
      case 2:
        return so.load(t);
      case 3:
        return ao.load(t);
      case 4:
        return co.load(t);
      case 5:
        return uo.load(t);
      case 6:
        return no.load(t);
      case 7:
        return ro.load(t);
      case 8:
        return oo.load(t);
      default:
        throw new Error(`Unknown variant index for TransactionArgument: ${e}`);
    }
  }
}, to = class tu extends _t {
  constructor(e) {
    super(), this.value = e;
  }
  serialize(e) {
    e.serializeU32AsUleb128(0), e.serializeU8(this.value);
  }
  static load(e) {
    const n = e.deserializeU8();
    return new tu(n);
  }
}, no = class nu extends _t {
  constructor(e) {
    super(), this.value = e;
  }
  serialize(e) {
    e.serializeU32AsUleb128(6), e.serializeU16(this.value);
  }
  static load(e) {
    const n = e.deserializeU16();
    return new nu(n);
  }
}, ro = class ru extends _t {
  constructor(e) {
    super(), this.value = e;
  }
  serialize(e) {
    e.serializeU32AsUleb128(7), e.serializeU32(this.value);
  }
  static load(e) {
    const n = e.deserializeU32();
    return new ru(n);
  }
}, io = class iu extends _t {
  constructor(e) {
    super(), this.value = e;
  }
  serialize(e) {
    e.serializeU32AsUleb128(1), e.serializeU64(this.value);
  }
  static load(e) {
    const n = e.deserializeU64();
    return new iu(n);
  }
}, so = class su extends _t {
  constructor(e) {
    super(), this.value = e;
  }
  serialize(e) {
    e.serializeU32AsUleb128(2), e.serializeU128(this.value);
  }
  static load(e) {
    const n = e.deserializeU128();
    return new su(n);
  }
}, oo = class ou extends _t {
  constructor(e) {
    super(), this.value = e;
  }
  serialize(e) {
    e.serializeU32AsUleb128(8), e.serializeU256(this.value);
  }
  static load(e) {
    const n = e.deserializeU256();
    return new ou(n);
  }
}, ao = class au extends _t {
  constructor(e) {
    super(), this.value = e;
  }
  serialize(e) {
    e.serializeU32AsUleb128(3), this.value.serialize(e);
  }
  static load(e) {
    const n = Ue.deserialize(e);
    return new au(n);
  }
}, co = class cu extends _t {
  constructor(e) {
    super(), this.value = e;
  }
  serialize(e) {
    e.serializeU32AsUleb128(4), e.serializeBytes(this.value);
  }
  static load(e) {
    const n = e.deserializeBytes();
    return new cu(n);
  }
}, uo = class uu extends _t {
  constructor(e) {
    super(), this.value = e;
  }
  serialize(e) {
    e.serializeU32AsUleb128(5), e.serializeBool(this.value);
  }
  static load(e) {
    const n = e.deserializeBool();
    return new uu(n);
  }
}, fu = class {
  getHashSalt() {
    const t = kn.create();
    return t.update("APTOS::Transaction"), t.digest();
  }
  static deserialize(t) {
    const e = t.deserializeUleb128AsU32();
    switch (e) {
      case 0:
        return lu.load(t);
      default:
        throw new Error(`Unknown variant index for Transaction: ${e}`);
    }
  }
}, lu = class du extends fu {
  constructor(e) {
    super(), this.value = e;
  }
  hash() {
    const e = kn.create();
    return e.update(this.getHashSalt()), e.update($t(this)), e.digest();
  }
  serialize(e) {
    e.serializeU32AsUleb128(0), this.value.serialize(e);
  }
  static load(e) {
    return new du(Mi.deserialize(e));
  }
}, Hi = class hu {
  /**
   * Constructs a TypeArgumentABI instance.
   * @param name
   */
  constructor(e) {
    this.name = e;
  }
  serialize(e) {
    e.serializeStr(this.name);
  }
  static deserialize(e) {
    const n = e.deserializeStr();
    return new hu(n);
  }
}, $i = class pu {
  /**
   * Constructs an ArgumentABI instance.
   * @param name
   * @param type_tag
   */
  constructor(e, n) {
    this.name = e, this.type_tag = n;
  }
  serialize(e) {
    e.serializeStr(this.name), this.type_tag.serialize(e);
  }
  static deserialize(e) {
    const n = e.deserializeStr(), r = Ye.deserialize(e);
    return new pu(n, r);
  }
}, qi = class {
  static deserialize(t) {
    const e = t.deserializeUleb128AsU32();
    switch (e) {
      case 0:
        return fo.load(t);
      case 1:
        return sr.load(t);
      default:
        throw new Error(`Unknown variant index for TransactionPayload: ${e}`);
    }
  }
}, fo = class Au extends qi {
  /**
   * Constructs a TransactionScriptABI instance.
   * @param name Entry function name
   * @param doc
   * @param code
   * @param ty_args
   * @param args
   */
  constructor(e, n, r, i, o) {
    super(), this.name = e, this.doc = n, this.code = r, this.ty_args = i, this.args = o;
  }
  serialize(e) {
    e.serializeU32AsUleb128(0), e.serializeStr(this.name), e.serializeStr(this.doc), e.serializeBytes(this.code), Ke(this.ty_args, e), Ke(this.args, e);
  }
  static load(e) {
    const n = e.deserializeStr(), r = e.deserializeStr(), i = e.deserializeBytes(), o = tt(e, Hi), c = tt(e, $i);
    return new Au(n, r, i, o, c);
  }
}, sr = class yu extends qi {
  /**
   * Constructs a EntryFunctionABI instance
   * @param name
   * @param module_name Fully qualified module id
   * @param doc
   * @param ty_args
   * @param args
   */
  constructor(e, n, r, i, o) {
    super(), this.name = e, this.module_name = n, this.doc = r, this.ty_args = i, this.args = o;
  }
  serialize(e) {
    e.serializeU32AsUleb128(1), e.serializeStr(this.name), this.module_name.serialize(e), e.serializeStr(this.doc), Ke(this.ty_args, e), Ke(this.args, e);
  }
  static load(e) {
    const n = e.deserializeStr(), r = ir.deserialize(e), i = e.deserializeStr(), o = tt(e, Hi), c = tt(e, $i);
    return new yu(n, r, i, o, c);
  }
}, _r = class Bn {
  constructor(e) {
    if (e.length !== Bn.LENGTH)
      throw new Error("Expected a byte array of length 32");
    this.bytes = e;
  }
  /**
   * Converts a K-of-N MultiEd25519PublicKey to AuthenticationKey with:
   * `auth_key = sha3-256(p_1 | … | p_n | K | 0x01)`. `K` represents the K-of-N required for
   * authenticating the transaction. `0x01` is the 1-byte scheme for multisig.
   */
  static fromMultiEd25519PublicKey(e) {
    const n = e.toBytes(), r = new Uint8Array(n.length + 1);
    r.set(n), r.set([Bn.MULTI_ED25519_SCHEME], n.length);
    const i = kn.create();
    return i.update(r), new Bn(i.digest());
  }
  static fromEd25519PublicKey(e) {
    const n = e.value, r = new Uint8Array(n.length + 1);
    r.set(n), r.set([Bn.ED25519_SCHEME], n.length);
    const i = kn.create();
    return i.update(r), new Bn(i.digest());
  }
  /**
   * Derives an account address from AuthenticationKey. Since current AccountAddress is 32 bytes,
   * AuthenticationKey bytes are directly translated to AccountAddress.
   */
  derivedAddress() {
    return J.fromUint8Array(this.bytes);
  }
};
_r.LENGTH = 32;
_r.MULTI_ED25519_SCHEME = 1;
_r.ED25519_SCHEME = 0;
_r.DERIVE_RESOURCE_ACCOUNT_SCHEME = 255;
var xs = _r, a0 = class {
  constructor(t, e, n, r, i, o, c) {
    this.accountAddress = t, this.moduleName = e, this.structName = n, this.sequenceNumber = r, this.originator = i, this.currentAuthKey = o, this.newPublicKey = c;
  }
  serialize(t) {
    this.accountAddress.serialize(t), t.serializeStr(this.moduleName), t.serializeStr(this.structName), t.serializeU64(this.sequenceNumber), this.originator.serialize(t), this.currentAuthKey.serialize(t), t.serializeBytes(this.newPublicKey);
  }
}, wu = class Gr {
  static fromAptosAccountObject(e) {
    return new Gr(J.ensure(e.privateKeyHex).toUint8Array(), e.address);
  }
  /**
   * Check's if the derive path is valid
   */
  static isValidPath(e) {
    return /^m\/44'\/637'\/[0-9]+'\/[0-9]+'\/[0-9]+'+$/.test(e);
  }
  /**
   * Creates new account with bip44 path and mnemonics,
   * @param path. (e.g. m/44'/637'/0'/0'/0')
   * Detailed description: {@link https://github.com/bitcoin/bips/blob/master/bip-0044.mediawiki}
   * @param mnemonics.
   * @returns AptosAccount
   */
  static fromDerivePath(e, n) {
    if (!Gr.isValidPath(e))
      throw new Error("Invalid derivation path");
    const r = n.trim().split(/\s+/).map((o) => o.toLowerCase()).join(" "), { key: i } = Uh(e, ma(Kl(r)));
    return new Gr(i);
  }
  /**
   * Creates new account instance. Constructor allows passing in an address,
   * to handle account key rotation, where auth_key != public_key
   * @param privateKeyBytes  Private key from which account key pair will be generated.
   * If not specified, new key pair is going to be created.
   * @param address Account address (e.g. 0xe8012714cd17606cee7188a2a365eef3fe760be598750678c8c5954eb548a591).
   * If not specified, a new one will be generated from public key
   */
  constructor(e, n) {
    e ? this.signingKey = Sr.sign.keyPair.fromSeed(e.slice(0, 32)) : this.signingKey = Sr.sign.keyPair(), this.accountAddress = J.ensure(n || this.authKey().hex());
  }
  /**
   * This is the key by which Aptos account is referenced.
   * It is the 32-byte of the SHA-3 256 cryptographic hash
   * of the public key(s) concatenated with a signature scheme identifier byte
   * @returns Address associated with the given account
   */
  address() {
    return this.accountAddress;
  }
  authKey() {
    const e = new gt(this.signingKey.publicKey);
    return xs.fromEd25519PublicKey(e).derivedAddress();
  }
  /**
   * Takes source address and seeds and returns the resource account address
   * @param sourceAddress Address used to derive the resource account
   * @param seed The seed bytes
   * @returns The resource account address
   */
  static getResourceAccountAddress(e, n) {
    const r = $t(Ue.fromHex(e)), i = new Uint8Array([...r, ...n, xs.DERIVE_RESOURCE_ACCOUNT_SCHEME]), o = kn.create();
    return o.update(i), J.fromUint8Array(o.digest());
  }
  /**
   * Takes creator address and collection name and returns the collection id hash.
   * Collection id hash are generated as sha256 hash of (`creator_address::collection_name`)
   *
   * @param creatorAddress Collection creator address
   * @param collectionName The collection name
   * @returns The collection id hash
   */
  static getCollectionID(e, n) {
    const r = new TextEncoder().encode(`${e}::${n}`), i = Bl.create();
    return i.update(r), J.fromUint8Array(i.digest());
  }
  /**
   * This key is generated with Ed25519 scheme.
   * Public key is used to check a signature of transaction, signed by given account
   * @returns The public key for the associated account
   */
  pubKey() {
    return J.fromUint8Array(this.signingKey.publicKey);
  }
  /**
   * Signs specified `buffer` with account's private key
   * @param buffer A buffer to sign
   * @returns A signature HexString
   */
  signBuffer(e) {
    const n = Sr.sign.detached(e, this.signingKey.secretKey);
    return J.fromUint8Array(n);
  }
  /**
   * Signs specified `hexString` with account's private key
   * @param hexString A regular string or HexString to sign
   * @returns A signature HexString
   */
  signHexString(e) {
    const n = J.ensure(e).toUint8Array();
    return this.signBuffer(n);
  }
  /**
   * Verifies the signature of the message with the public key of the account
   * @param message a signed message
   * @param signature the signature of the message
   */
  verifySignature(e, n) {
    const r = J.ensure(e).toUint8Array(), i = J.ensure(n).toUint8Array();
    return Sr.sign.detached.verify(r, i, this.signingKey.publicKey);
  }
  /**
   * Derives account address, public key and private key
   * @returns AptosAccountObject instance.
   * @example An example of the returned AptosAccountObject object
   * ```
   * {
   *    address: "0xe8012714cd17606cee7188a2a365eef3fe760be598750678c8c5954eb548a591",
   *    publicKeyHex: "0xf56d8524faf79fbc0f48c13aeed3b0ce5dd376b4db93b8130a107c0a5e04ba04",
   *    privateKeyHex: `0x009c9f7c992a06cfafe916f125d8adb7a395fca243e264a8e56a4b3e6accf940
   *      d2b11e9ece3049ce60e3c7b4a1c58aebfa9298e29a30a58a67f1998646135204`
   * }
   * ```
   */
  toPrivateKeyObject() {
    return {
      address: this.address().hex(),
      publicKeyHex: this.pubKey().hex(),
      privateKeyHex: J.fromUint8Array(this.signingKey.secretKey.slice(0, 32)).hex()
    };
  }
};
Be([
  Fi()
], wu.prototype, "authKey", 1);
var Yo = wu, mr = `
    fragment CurrentTokenOwnershipFields on current_token_ownerships_v2 {
  token_standard
  token_properties_mutated_v1
  token_data_id
  table_type_v1
  storage_id
  property_version_v1
  owner_address
  last_transaction_version
  last_transaction_timestamp
  is_soulbound_v2
  is_fungible_v2
  amount
  current_token_data {
    collection_id
    description
    is_fungible_v2
    largest_property_version_v1
    last_transaction_timestamp
    last_transaction_version
    maximum
    supply
    token_data_id
    token_name
    token_properties
    token_standard
    token_uri
    current_collection {
      collection_id
      collection_name
      creator_address
      current_supply
      description
      last_transaction_timestamp
      last_transaction_version
      max_supply
      mutable_description
      mutable_uri
      table_handle_v1
      token_standard
      total_minted_v2
      uri
    }
  }
}
    `, c0 = `
    fragment TokenDataFields on current_token_datas {
  creator_address
  collection_name
  description
  metadata_uri
  name
  token_data_id_hash
  collection_data_id_hash
}
    `, u0 = `
    fragment CollectionDataFields on current_collection_datas {
  metadata_uri
  supply
  description
  collection_name
  collection_data_id_hash
  table_handle
  creator_address
}
    `, gu = `
    fragment TokenActivitiesFields on token_activities_v2 {
  after_value
  before_value
  entry_function_id_str
  event_account_address
  event_index
  from_address
  is_fungible_v2
  property_version_v1
  to_address
  token_amount
  token_data_id
  token_standard
  transaction_timestamp
  transaction_version
  type
}
    `, f0 = `
    query getAccountCoinsDataCount($address: String) {
  current_fungible_asset_balances_aggregate(
    where: {owner_address: {_eq: $address}}
  ) {
    aggregate {
      count
    }
  }
}
    `, l0 = `
    query getAccountCoinsData($where_condition: current_fungible_asset_balances_bool_exp!, $offset: Int, $limit: Int, $order_by: [current_fungible_asset_balances_order_by!]) {
  current_fungible_asset_balances(
    where: $where_condition
    offset: $offset
    limit: $limit
    order_by: $order_by
  ) {
    amount
    asset_type
    is_frozen
    is_primary
    last_transaction_timestamp
    last_transaction_version
    owner_address
    storage_id
    token_standard
    metadata {
      token_standard
      symbol
      supply_aggregator_table_key_v1
      supply_aggregator_table_handle_v1
      project_uri
      name
      last_transaction_version
      last_transaction_timestamp
      icon_uri
      decimals
      creator_address
      asset_type
    }
  }
}
    `, d0 = `
    query getAccountCurrentTokens($address: String!, $offset: Int, $limit: Int) {
  current_token_ownerships(
    where: {owner_address: {_eq: $address}, amount: {_gt: 0}}
    order_by: [{last_transaction_version: desc}, {creator_address: asc}, {collection_name: asc}, {name: asc}]
    offset: $offset
    limit: $limit
  ) {
    amount
    current_token_data {
      ...TokenDataFields
    }
    current_collection_data {
      ...CollectionDataFields
    }
    last_transaction_version
    property_version
  }
}
    ${c0}
${u0}`, h0 = `
    query getAccountTokensCount($where_condition: current_token_ownerships_v2_bool_exp, $offset: Int, $limit: Int) {
  current_token_ownerships_v2_aggregate(
    where: $where_condition
    offset: $offset
    limit: $limit
  ) {
    aggregate {
      count
    }
  }
}
    `, p0 = `
    query getAccountTransactionsCount($address: String) {
  account_transactions_aggregate(where: {account_address: {_eq: $address}}) {
    aggregate {
      count
    }
  }
}
    `, A0 = `
    query getAccountTransactionsData($where_condition: account_transactions_bool_exp!, $offset: Int, $limit: Int, $order_by: [account_transactions_order_by!]) {
  account_transactions(
    where: $where_condition
    order_by: $order_by
    limit: $limit
    offset: $offset
  ) {
    token_activities_v2 {
      ...TokenActivitiesFields
    }
    transaction_version
    account_address
  }
}
    ${gu}`, y0 = `
    query getCollectionData($where_condition: current_collections_v2_bool_exp!, $offset: Int, $limit: Int, $order_by: [current_collections_v2_order_by!]) {
  current_collections_v2(
    where: $where_condition
    offset: $offset
    limit: $limit
    order_by: $order_by
  ) {
    collection_id
    collection_name
    creator_address
    current_supply
    description
    last_transaction_timestamp
    last_transaction_version
    max_supply
    mutable_description
    mutable_uri
    table_handle_v1
    token_standard
    total_minted_v2
    uri
  }
}
    `, w0 = `
    query getCollectionsWithOwnedTokens($where_condition: current_collection_ownership_v2_view_bool_exp!, $offset: Int, $limit: Int, $order_by: [current_collection_ownership_v2_view_order_by!]) {
  current_collection_ownership_v2_view(
    where: $where_condition
    offset: $offset
    limit: $limit
    order_by: $order_by
  ) {
    current_collection {
      collection_id
      collection_name
      creator_address
      current_supply
      description
      last_transaction_timestamp
      last_transaction_version
      mutable_description
      max_supply
      mutable_uri
      table_handle_v1
      token_standard
      total_minted_v2
      uri
    }
    collection_id
    collection_name
    collection_uri
    creator_address
    distinct_tokens
    last_transaction_version
    owner_address
    single_token_uri
  }
}
    `, g0 = `
    query getCurrentObjects($where_condition: current_objects_bool_exp, $offset: Int, $limit: Int, $order_by: [current_objects_order_by!]) {
  current_objects(
    where: $where_condition
    offset: $offset
    limit: $limit
    order_by: $order_by
  ) {
    allow_ungated_transfer
    state_key_hash
    owner_address
    object_address
    last_transaction_version
    last_guid_creation_num
    is_deleted
  }
}
    `, x0 = `
    query getDelegatedStakingActivities($delegatorAddress: String, $poolAddress: String) {
  delegated_staking_activities(
    where: {delegator_address: {_eq: $delegatorAddress}, pool_address: {_eq: $poolAddress}}
  ) {
    amount
    delegator_address
    event_index
    event_type
    pool_address
    transaction_version
  }
}
    `, _0 = `
    query getIndexerLedgerInfo {
  ledger_infos {
    chain_id
  }
}
    `, m0 = `
    query getNumberOfDelegators($poolAddress: String) {
  num_active_delegator_per_pool(
    where: {pool_address: {_eq: $poolAddress}, num_active_delegator: {_gt: "0"}}
    distinct_on: pool_address
  ) {
    num_active_delegator
    pool_address
  }
}
    `, b0 = `
    query getOwnedTokens($where_condition: current_token_ownerships_v2_bool_exp!, $offset: Int, $limit: Int, $order_by: [current_token_ownerships_v2_order_by!]) {
  current_token_ownerships_v2(
    where: $where_condition
    offset: $offset
    limit: $limit
    order_by: $order_by
  ) {
    ...CurrentTokenOwnershipFields
  }
}
    ${mr}`, E0 = `
    query getOwnedTokensByTokenData($where_condition: current_token_ownerships_v2_bool_exp!, $offset: Int, $limit: Int, $order_by: [current_token_ownerships_v2_order_by!]) {
  current_token_ownerships_v2(
    where: $where_condition
    offset: $offset
    limit: $limit
    order_by: $order_by
  ) {
    ...CurrentTokenOwnershipFields
  }
}
    ${mr}`, v0 = `
    query getTokenActivities($where_condition: token_activities_v2_bool_exp!, $offset: Int, $limit: Int, $order_by: [token_activities_v2_order_by!]) {
  token_activities_v2(
    where: $where_condition
    order_by: $order_by
    offset: $offset
    limit: $limit
  ) {
    ...TokenActivitiesFields
  }
}
    ${gu}`, T0 = `
    query getTokenActivitiesCount($token_id: String) {
  token_activities_v2_aggregate(where: {token_data_id: {_eq: $token_id}}) {
    aggregate {
      count
    }
  }
}
    `, B0 = `
    query getTokenCurrentOwnerData($where_condition: current_token_ownerships_v2_bool_exp!, $offset: Int, $limit: Int, $order_by: [current_token_ownerships_v2_order_by!]) {
  current_token_ownerships_v2(
    where: $where_condition
    offset: $offset
    limit: $limit
    order_by: $order_by
  ) {
    ...CurrentTokenOwnershipFields
  }
}
    ${mr}`, S0 = `
    query getTokenData($where_condition: current_token_datas_v2_bool_exp, $offset: Int, $limit: Int, $order_by: [current_token_datas_v2_order_by!]) {
  current_token_datas_v2(
    where: $where_condition
    offset: $offset
    limit: $limit
    order_by: $order_by
  ) {
    collection_id
    description
    is_fungible_v2
    largest_property_version_v1
    last_transaction_timestamp
    last_transaction_version
    maximum
    supply
    token_data_id
    token_name
    token_properties
    token_standard
    token_uri
    current_collection {
      collection_id
      collection_name
      creator_address
      current_supply
      description
      last_transaction_timestamp
      last_transaction_version
      max_supply
      mutable_description
      mutable_uri
      table_handle_v1
      token_standard
      total_minted_v2
      uri
    }
  }
}
    `, I0 = `
    query getTokenOwnedFromCollection($where_condition: current_token_ownerships_v2_bool_exp!, $offset: Int, $limit: Int, $order_by: [current_token_ownerships_v2_order_by!]) {
  current_token_ownerships_v2(
    where: $where_condition
    offset: $offset
    limit: $limit
    order_by: $order_by
  ) {
    ...CurrentTokenOwnershipFields
  }
}
    ${mr}`, U0 = `
    query getTokenOwnersData($where_condition: current_token_ownerships_v2_bool_exp!, $offset: Int, $limit: Int, $order_by: [current_token_ownerships_v2_order_by!]) {
  current_token_ownerships_v2(
    where: $where_condition
    offset: $offset
    limit: $limit
    order_by: $order_by
  ) {
    ...CurrentTokenOwnershipFields
  }
}
    ${mr}`, C0 = `
    query getTopUserTransactions($limit: Int) {
  user_transactions(limit: $limit, order_by: {version: desc}) {
    version
  }
}
    `, P0 = `
    query getUserTransactions($where_condition: user_transactions_bool_exp!, $offset: Int, $limit: Int, $order_by: [user_transactions_order_by!]) {
  user_transactions(
    order_by: $order_by
    where: $where_condition
    limit: $limit
    offset: $offset
  ) {
    version
  }
}
    `;
function Qi(t, e, n) {
  if (!(e != null && e.includes(typeof t)))
    throw new Error(
      n || `Invalid arg: ${t} type should be ${e instanceof Array ? e.join(" or ") : e}`
    );
}
function xu(t) {
  if (Qi(t, ["boolean", "string"]), typeof t == "boolean")
    return t;
  if (t === "true")
    return !0;
  if (t === "false")
    return !1;
  throw new Error("Invalid boolean string.");
}
function Un(t) {
  if (Qi(t, ["number", "string"]), typeof t == "number")
    return t;
  const e = Number.parseInt(t, 10);
  if (Number.isNaN(e))
    throw new Error("Invalid number string.");
  return e;
}
function Cn(t) {
  return Qi(t, ["number", "bigint", "string"]), BigInt(t);
}
function O0(t, e, n) {
  lo(t, e, n);
}
function lo(t, e, n, r) {
  if (e instanceof Dn)
    n.serializeBool(xu(t));
  else if (e instanceof nn)
    n.serializeU8(Un(t));
  else if (e instanceof pr)
    n.serializeU16(Un(t));
  else if (e instanceof Ar)
    n.serializeU32(Un(t));
  else if (e instanceof Ln)
    n.serializeU64(Cn(t));
  else if (e instanceof Mn)
    n.serializeU128(Cn(t));
  else if (e instanceof yr)
    n.serializeU256(Cn(t));
  else if (e instanceof yn)
    _u(t, n);
  else if (e instanceof wr)
    R0(t, e, n);
  else if (e instanceof wn)
    k0(t, e, n);
  else
    throw new Error("Unsupported arg type.");
}
function _u(t, e) {
  let n;
  if (typeof t == "string" || t instanceof J)
    n = Ue.fromHex(t);
  else if (t instanceof Ue)
    n = t;
  else
    throw new Error("Invalid account address.");
  n.serialize(e);
}
function R0(t, e, n, r) {
  if (e.value instanceof nn) {
    if (t instanceof Uint8Array) {
      n.serializeBytes(t);
      return;
    }
    if (t instanceof J) {
      n.serializeBytes(t.toUint8Array());
      return;
    }
    if (typeof t == "string") {
      n.serializeStr(t);
      return;
    }
  }
  if (!Array.isArray(t))
    throw new Error("Invalid vector args.");
  n.serializeU32AsUleb128(t.length), t.forEach((i) => lo(i, e.value, n));
}
function k0(t, e, n, r) {
  const { address: i, module_name: o, name: c, type_args: f } = e.value, y = `${J.fromUint8Array(i.address).toShortString()}::${o.value}::${c.value}`;
  if (y === "0x1::string::String")
    Qi(t, ["string"]), n.serializeStr(t);
  else if (y === "0x1::object::Object")
    _u(t, n);
  else if (y === "0x1::option::Option") {
    if (f.length !== 1)
      throw new Error(`Option has the wrong number of type arguments ${f.length}`);
    N0(t, f[0], n);
  } else
    throw new Error("Unsupported struct type in function argument");
}
function N0(t, e, n, r) {
  t == null ? n.serializeU32AsUleb128(0) : (n.serializeU32AsUleb128(1), lo(t, e, n));
}
function z0(t, e) {
  if (e instanceof Dn)
    return new uo(xu(t));
  if (e instanceof nn)
    return new to(Un(t));
  if (e instanceof pr)
    return new no(Un(t));
  if (e instanceof Ar)
    return new ro(Un(t));
  if (e instanceof Ln)
    return new io(Cn(t));
  if (e instanceof Mn)
    return new so(Cn(t));
  if (e instanceof yr)
    return new oo(Cn(t));
  if (e instanceof yn) {
    let n;
    if (typeof t == "string" || t instanceof J)
      n = Ue.fromHex(t);
    else if (t instanceof Ue)
      n = t;
    else
      throw new Error("Invalid account address.");
    return new ao(n);
  }
  if (e instanceof wr && e.value instanceof nn) {
    if (!(t instanceof Uint8Array))
      throw new Error(`${t} should be an instance of Uint8Array`);
    return new co(t);
  }
  throw new Error("Unknown type for TransactionArgument.");
}
var F0 = "APTOS::RawTransaction", Vo = "APTOS::RawTransactionWithData", or = class {
  constructor(t, e) {
    this.rawTxnBuilder = e, this.signingFunction = t;
  }
  /**
   * Builds a RawTransaction. Relays the call to TransactionBuilderABI.build
   * @param func
   * @param ty_tags
   * @param args
   */
  build(t, e, n) {
    if (!this.rawTxnBuilder)
      throw new Error("this.rawTxnBuilder doesn't exist.");
    return this.rawTxnBuilder.build(t, e, n);
  }
  /** Generates a Signing Message out of a raw transaction. */
  static getSigningMessage(t) {
    const e = kn.create();
    if (t instanceof $n)
      e.update(F0);
    else if (t instanceof Vs)
      e.update(Vo);
    else if (t instanceof Js)
      e.update(Vo);
    else
      throw new Error("Unknown transaction type.");
    const n = e.digest(), r = $t(t), i = new Uint8Array(n.length + r.length);
    return i.set(n), i.set(r, n.length), i;
  }
}, is = class extends or {
  constructor(t, e, n) {
    super(t, n), this.publicKey = e;
  }
  rawToSigned(t) {
    const e = or.getSigningMessage(t), n = this.signingFunction(e), r = new js(
      new gt(this.publicKey),
      n
    );
    return new Mi(t, r);
  }
  /** Signs a raw transaction and returns a bcs serialized transaction. */
  sign(t) {
    return $t(this.rawToSigned(t));
  }
}, D0 = class extends or {
  constructor(t, e) {
    super(t), this.publicKey = e;
  }
  rawToSigned(t) {
    const e = or.getSigningMessage(t), n = this.signingFunction(e), r = new Gs(this.publicKey, n);
    return new Mi(t, r);
  }
  /** Signs a raw transaction and returns a bcs serialized transaction. */
  sign(t) {
    return $t(this.rawToSigned(t));
  }
}, L0 = class _s {
  /**
   * Constructs a TransactionBuilderABI instance
   * @param abis List of binary ABIs.
   * @param builderConfig Configs for creating a raw transaction.
   */
  constructor(e, n) {
    this.abiMap = /* @__PURE__ */ new Map(), e.forEach((r) => {
      const i = new qs(r), o = qi.deserialize(i);
      let c;
      if (o instanceof sr) {
        const f = o, { address: y, name: w } = f.module_name;
        c = `${J.fromUint8Array(y.address).toShortString()}::${w.value}::${f.name}`;
      } else
        c = o.name;
      if (this.abiMap.has(c))
        throw new Error("Found conflicting ABI interfaces");
      this.abiMap.set(c, o);
    }), this.builderConfig = {
      maxGasAmount: BigInt(ic),
      expSecFromNow: sc,
      ...n
    };
  }
  static toBCSArgs(e, n) {
    if (e.length !== n.length)
      throw new Error("Wrong number of args provided.");
    return n.map((r, i) => {
      const o = new Ne();
      return O0(r, e[i].type_tag, o), o.getBytes();
    });
  }
  static toTransactionArguments(e, n) {
    if (e.length !== n.length)
      throw new Error("Wrong number of args provided.");
    return n.map((r, i) => z0(r, e[i].type_tag));
  }
  setSequenceNumber(e) {
    this.builderConfig.sequenceNumber = BigInt(e);
  }
  /**
   * Builds a TransactionPayload. For dApps, chain ID and account sequence numbers are only known to the wallet.
   * Instead of building a RawTransaction (requires chainID and sequenceNumber), dApps can build a TransactionPayload
   * and pass the payload to the wallet for signing and sending.
   * @param func Fully qualified func names, e.g. 0x1::aptos_account::transfer
   * @param ty_tags TypeTag strings
   * @param args Function arguments
   * @returns TransactionPayload
   */
  buildTransactionPayload(e, n, r) {
    const i = n.map((f) => new gr(f).parseTypeTag());
    let o;
    if (!this.abiMap.has(e))
      throw new Error(`Cannot find function: ${e}`);
    const c = this.abiMap.get(e);
    if (c instanceof sr) {
      const f = c, y = _s.toBCSArgs(f.args, r);
      o = new Zs(
        new Li(f.module_name, new Ze(f.name), i, y)
      );
    } else if (c instanceof fo) {
      const f = c, y = _s.toTransactionArguments(f.args, r);
      o = new Xs(new Ks(f.code, i, y));
    } else
      throw new Error("Unknown ABI format.");
    return o;
  }
  /**
   * Builds a RawTransaction
   * @param func Fully qualified func names, e.g. 0x1::aptos_account::transfer
   * @param ty_tags TypeTag strings.
   * @example Below are valid value examples
   * ```
   * // Structs are in format `AccountAddress::ModuleName::StructName`
   * 0x1::aptos_coin::AptosCoin
   * // Vectors are in format `vector<other_tag_string>`
   * vector<0x1::aptos_coin::AptosCoin>
   * bool
   * u8
   * u16
   * u32
   * u64
   * u128
   * u256
   * address
   * ```
   * @param args Function arguments
   * @returns RawTransaction
   */
  build(e, n, r) {
    const { sender: i, sequenceNumber: o, gasUnitPrice: c, maxGasAmount: f, expSecFromNow: y, chainId: w } = this.builderConfig;
    if (!c)
      throw new Error("No gasUnitPrice provided.");
    const _ = i instanceof Ue ? i : Ue.fromHex(i), m = BigInt(Math.floor(Date.now() / 1e3) + Number(y)), I = this.buildTransactionPayload(e, n, r);
    if (I)
      return new $n(
        _,
        BigInt(o),
        I,
        BigInt(f),
        BigInt(c),
        m,
        new eo(Number(w))
      );
    throw new Error("Invalid ABI.");
  }
}, mu = class {
  // We don't want the builder to depend on the actual AptosClient. There might be circular dependencies.
  constructor(t, e) {
    this.aptosClient = t, this.builderConfig = e;
  }
  async fetchABI(t) {
    const n = (await this.aptosClient.getAccountModules(t)).map((i) => i.abi).flatMap(
      (i) => i.exposed_functions.filter((o) => o.is_entry).map(
        (o) => ({
          fullName: `${i.address}::${i.name}::${o.name}`,
          ...o
        })
      )
    ), r = /* @__PURE__ */ new Map();
    return n.forEach((i) => {
      r.set(i.fullName, i);
    }), r;
  }
  /**
   * Builds a raw transaction. Only support script function a.k.a entry function payloads
   *
   * @param func fully qualified function name in format <address>::<module>::<function>, e.g. 0x1::coin::transfer
   * @param ty_tags
   * @param args
   * @returns RawTransaction
   */
  async build(t, e, n) {
    if (t = ((Q) => Q.replace(/^0[xX]0*/g, "0x"))(t), t.split("::").length !== 3)
      throw new Error(
        // eslint-disable-next-line max-len
        "'func' needs to be a fully qualified function name in format <address>::<module>::<function>, e.g. 0x1::coin::transfer"
      );
    const [o, c] = t.split("::"), f = await this.fetchABI(o);
    if (!f.has(t))
      throw new Error(`${t} doesn't exist.`);
    const y = f.get(t), _ = y.params.filter((Q) => Q !== "signer" && Q !== "&signer").map(
      (Q, ke) => new $i(`var${ke}`, new gr(Q, e).parseTypeTag())
    ), m = new sr(
      y.name,
      ir.fromStr(`${o}::${c}`),
      "",
      // Doc string
      y.generic_type_params.map((Q, ke) => new Hi(`${ke}`)),
      _
    ), { sender: I, ...z } = this.builderConfig, k = I instanceof Ue ? J.fromUint8Array(I.address) : I, [{ sequence_number: N }, M, { gas_estimate: Z }] = await Promise.all([
      z != null && z.sequenceNumber ? Promise.resolve({ sequence_number: z == null ? void 0 : z.sequenceNumber }) : this.aptosClient.getAccount(k),
      z != null && z.chainId ? Promise.resolve(z == null ? void 0 : z.chainId) : this.aptosClient.getChainId(),
      z != null && z.gasUnitPrice ? Promise.resolve({ gas_estimate: z == null ? void 0 : z.gasUnitPrice }) : this.aptosClient.estimateGasPrice()
    ]);
    return new L0([$t(m)], {
      sender: I,
      sequenceNumber: N,
      chainId: M,
      gasUnitPrice: BigInt(Z),
      ...z
    }).build(t, e, n);
  }
};
Be([
  oc(10 * 60 * 1e3)
], mu.prototype, "fetchABI", 1);
var Le = class Sn {
  /**
   * Build a client configured to connect to an Aptos node at the given URL.
   *
   * Note: If you forget to append `/v1` to the URL, the client constructor
   * will automatically append it. If you don't want this URL processing to
   * take place, set doNotFixNodeUrl to true.
   *
   * @param nodeUrl URL of the Aptos Node API endpoint.
   * @param config Additional configuration options for the generated Axios client.
   */
  constructor(e, n, r = !1) {
    if (!e)
      throw new Error("Node URL cannot be empty.");
    r ? this.nodeUrl = e : this.nodeUrl = Oh(e), this.config = n == null ? {} : { ...n };
  }
  async getAccount(e) {
    const { data: n } = await ct({
      url: this.nodeUrl,
      endpoint: `accounts/${J.ensure(e).hex()}`,
      originMethod: "getAccount",
      overrides: { ...this.config }
    });
    return n;
  }
  async getAccountTransactions(e, n) {
    const { data: r } = await ct({
      url: this.nodeUrl,
      endpoint: `accounts/${J.ensure(e).hex()}/transactions`,
      originMethod: "getAccountTransactions",
      params: { start: n == null ? void 0 : n.start, limit: n == null ? void 0 : n.limit },
      overrides: { ...this.config }
    });
    return r;
  }
  async getAccountModules(e, n) {
    return await Go({
      url: this.nodeUrl,
      endpoint: `accounts/${e}/modules`,
      params: { ledger_version: n == null ? void 0 : n.ledgerVersion, limit: 1e3 },
      originMethod: "getAccountModules",
      overrides: { ...this.config }
    });
  }
  async getAccountModule(e, n, r) {
    const { data: i } = await ct({
      url: this.nodeUrl,
      endpoint: `accounts/${J.ensure(e).hex()}/module/${n}`,
      originMethod: "getAccountModule",
      params: { ledger_version: r == null ? void 0 : r.ledgerVersion },
      overrides: { ...this.config }
    });
    return i;
  }
  async getAccountResources(e, n) {
    return await Go({
      url: this.nodeUrl,
      endpoint: `accounts/${e}/resources`,
      params: { ledger_version: n == null ? void 0 : n.ledgerVersion, limit: 9999 },
      originMethod: "getAccountResources",
      overrides: { ...this.config }
    });
  }
  async getAccountResource(e, n, r) {
    const { data: i } = await ct({
      url: this.nodeUrl,
      endpoint: `accounts/${J.ensure(e).hex()}/resource/${n}`,
      originMethod: "getAccountResource",
      params: { ledger_version: r == null ? void 0 : r.ledgerVersion },
      overrides: { ...this.config }
    });
    return i;
  }
  /** Generates a signed transaction that can be submitted to the chain for execution. */
  static generateBCSTransaction(e, n) {
    return new is((i) => {
      const o = e.signBuffer(i);
      return new Oe.Ed25519Signature(o.toUint8Array());
    }, e.pubKey().toUint8Array()).sign(n);
  }
  /**
   * Note: Unless you have a specific reason for using this, it'll probably be simpler
   * to use `simulateTransaction`.
   *
   * Generates a BCS transaction that can be submitted to the chain for simulation.
   *
   * @param accountFrom The account that will be used to send the transaction
   * for simulation.
   * @param rawTxn The raw transaction to be simulated, likely created by calling
   * the `generateTransaction` function.
   * @returns The BCS encoded signed transaction, which you should then pass into
   * the `submitBCSSimulation` function.
   */
  static generateBCSSimulation(e, n) {
    return new is((i) => {
      const o = new Uint8Array(64);
      return new Oe.Ed25519Signature(o);
    }, e.pubKey().toUint8Array()).sign(n);
  }
  /** Generates an entry function transaction request that can be submitted to produce a raw transaction that
   * can be signed, which upon being signed can be submitted to the blockchain
   * This function fetches the remote ABI and uses it to serialized the data, therefore
   * users don't need to handle serialization by themselves.
   * @param sender Hex-encoded 32 byte Aptos account address of transaction sender
   * @param payload Entry function transaction payload type
   * @param options Options allow to overwrite default transaction options.
   * @returns A raw transaction object
   */
  async generateTransaction(e, n, r) {
    const i = { sender: e };
    if (r != null && r.sequence_number && (i.sequenceNumber = r.sequence_number), r != null && r.gas_unit_price && (i.gasUnitPrice = r.gas_unit_price), r != null && r.max_gas_amount && (i.maxGasAmount = r.max_gas_amount), r != null && r.expiration_timestamp_secs) {
      const c = Number.parseInt(r.expiration_timestamp_secs, 10);
      i.expSecFromNow = c - Math.floor(Date.now() / 1e3);
    }
    return new mu(this, i).build(n.function, n.type_arguments, n.arguments);
  }
  /**
   * Generates a fee payer transaction that can be signed and submitted to chain
   *
   * @param sender the sender's account address
   * @param payload the transaction payload
   * @param fee_payer the fee payer account
   * @param secondarySignerAccounts an optional array of the secondary signers accounts
   * @returns a fee payer raw transaction that can be signed and submitted to chain
   */
  async generateFeePayerTransaction(e, n, r, i = [], o) {
    const c = await this.generateTransaction(e, n, o), f = i.map((w) => Ue.fromHex(w));
    return new Oe.FeePayerRawTransaction(c, f, Ue.fromHex(r));
  }
  /**
   * Submits fee payer transaction to chain
   *
   * @param feePayerTransaction the raw transaction to be submitted, of type FeePayerRawTransaction
   * @param senderAuthenticator the sender account authenticator (can get from signMultiTransaction() method)
   * @param feePayerAuthenticator the feepayer account authenticator (can get from signMultiTransaction() method)
   * @param signersAuthenticators an optional array of the signer account authenticators
   * @returns The pending transaction
   */
  async submitFeePayerTransaction(e, n, r, i = []) {
    const o = new Oe.TransactionAuthenticatorFeePayer(
      n,
      e.secondary_signer_addresses,
      i,
      { address: e.fee_payer_address, authenticator: r }
    ), c = $t(
      new Oe.SignedTransaction(e.raw_txn, o)
    );
    return await this.submitSignedBCSTransaction(c);
  }
  /**
   * Signs a multi transaction type (multi agent / fee payer) and returns the
   * signer authenticator to be used to submit the transaction.
   *
   * @param signer the account to sign on the transaction
   * @param rawTxn a MultiAgentRawTransaction or FeePayerRawTransaction
   * @returns signer authenticator
   */
  // eslint-disable-next-line class-methods-use-this
  async signMultiTransaction(e, n) {
    const r = new Oe.Ed25519Signature(
      e.signBuffer(or.getSigningMessage(n)).toUint8Array()
    ), i = new Oe.AccountAuthenticatorEd25519(
      new Oe.Ed25519PublicKey(e.signingKey.publicKey),
      r
    );
    return Promise.resolve(i);
  }
  /** Converts a transaction request produced by `generateTransaction` into a properly
   * signed transaction, which can then be submitted to the blockchain
   * @param accountFrom AptosAccount of transaction sender
   * @param rawTransaction A raw transaction generated by `generateTransaction` method
   * @returns A transaction, signed with sender account
   */
  // eslint-disable-next-line class-methods-use-this
  async signTransaction(e, n) {
    return Promise.resolve(Sn.generateBCSTransaction(e, n));
  }
  async getEventsByCreationNumber(e, n, r) {
    const { data: i } = await ct({
      url: this.nodeUrl,
      endpoint: `accounts/${J.ensure(e).hex()}/events/${n}`,
      originMethod: "getEventsByCreationNumber",
      params: { start: r == null ? void 0 : r.start, limit: r == null ? void 0 : r.limit },
      overrides: { ...this.config }
    });
    return i;
  }
  async getEventsByEventHandle(e, n, r, i) {
    const { data: o } = await ct({
      url: this.nodeUrl,
      endpoint: `accounts/${J.ensure(e).hex()}/events/${n}/${r}`,
      originMethod: "getEventsByEventHandle",
      params: { start: i == null ? void 0 : i.start, limit: i == null ? void 0 : i.limit },
      overrides: { ...this.config }
    });
    return o;
  }
  /**
   * Submits a signed transaction to the transaction endpoint.
   * @param signedTxn A transaction, signed by `signTransaction` method
   * @returns Transaction that is accepted and submitted to mempool
   */
  async submitTransaction(e) {
    return this.submitSignedBCSTransaction(e);
  }
  /**
   * Generates and submits a transaction to the transaction simulation
   * endpoint. For this we generate a transaction with a fake signature.
   *
   * @param accountOrPubkey The sender or sender's public key. When private key is available, `AptosAccount` instance
   * can be used to send the transaction for simulation. If private key is not available, sender's public key can be
   * used to send the transaction for simulation.
   * @param rawTransaction The raw transaction to be simulated, likely created
   * by calling the `generateTransaction` function.
   * @param query.estimateGasUnitPrice If set to true, the gas unit price in the
   * transaction will be ignored and the estimated value will be used.
   * @param query.estimateMaxGasAmount If set to true, the max gas value in the
   * transaction will be ignored and the maximum possible gas will be used.
   * @param query.estimatePrioritizedGasUnitPrice If set to true, the transaction will use a higher price than the
   * original estimate.
   * @returns The BCS encoded signed transaction, which you should then provide
   *
   */
  async simulateTransaction(e, n, r) {
    let i;
    return e instanceof Yo ? i = Sn.generateBCSSimulation(e, n) : e instanceof Di ? i = new D0(() => {
      const { threshold: c } = e, f = [], y = [];
      for (let _ = 0; _ < c; _ += 1)
        f.push(_), y.push(new Oe.Ed25519Signature(new Uint8Array(64)));
      const w = Oe.MultiEd25519Signature.createBitmap(f);
      return new Oe.MultiEd25519Signature(y, w);
    }, e).sign(n) : i = new is(() => {
      const c = new Uint8Array(64);
      return new Oe.Ed25519Signature(c);
    }, e.toBytes()).sign(n), this.submitBCSSimulation(i, r);
  }
  async submitSignedBCSTransaction(e) {
    const { data: n } = await Yn({
      url: this.nodeUrl,
      body: e,
      endpoint: "transactions",
      originMethod: "submitSignedBCSTransaction",
      contentType: "application/x.aptos.signed_transaction+bcs",
      overrides: { ...this.config }
    });
    return n;
  }
  async submitBCSSimulation(e, n) {
    var r, i, o;
    const c = {
      estimate_gas_unit_price: (r = n == null ? void 0 : n.estimateGasUnitPrice) != null ? r : !1,
      estimate_max_gas_amount: (i = n == null ? void 0 : n.estimateMaxGasAmount) != null ? i : !1,
      estimate_prioritized_gas_unit_price: (o = n == null ? void 0 : n.estimatePrioritizedGasUnitPrice) != null ? o : !1
    }, { data: f } = await Yn({
      url: this.nodeUrl,
      body: e,
      endpoint: "transactions/simulate",
      params: c,
      originMethod: "submitBCSSimulation",
      contentType: "application/x.aptos.signed_transaction+bcs",
      overrides: { ...this.config }
    });
    return f;
  }
  async getTransactions(e) {
    var n;
    const { data: r } = await ct({
      url: this.nodeUrl,
      endpoint: "transactions",
      originMethod: "getTransactions",
      params: { start: (n = e == null ? void 0 : e.start) == null ? void 0 : n.toString(), limit: e == null ? void 0 : e.limit },
      overrides: { ...this.config }
    });
    return r;
  }
  async getTransactionByHash(e) {
    const { data: n } = await ct({
      url: this.nodeUrl,
      endpoint: `transactions/by_hash/${e}`,
      originMethod: "getTransactionByHash",
      overrides: { ...this.config }
    });
    return n;
  }
  async getTransactionByVersion(e) {
    const { data: n } = await ct({
      url: this.nodeUrl,
      endpoint: `transactions/by_version/${e}`,
      originMethod: "getTransactionByVersion",
      overrides: { ...this.config }
    });
    return n;
  }
  /**
   * Defines if specified transaction is currently in pending state
   * @param txnHash A hash of transaction
   *
   * To create a transaction hash:
   *
   * 1. Create hash message bytes: "Aptos::Transaction" bytes + BCS bytes of Transaction.
   * 2. Apply hash algorithm SHA3-256 to the hash message bytes.
   * 3. Hex-encode the hash bytes with 0x prefix.
   *
   * @returns `true` if transaction is in pending state and `false` otherwise
   */
  async transactionPending(e) {
    try {
      return (await this.getTransactionByHash(e)).type === "pending_transaction";
    } catch (n) {
      if ((n == null ? void 0 : n.status) === 404)
        return !0;
      throw n;
    }
  }
  /**
   * Wait for a transaction to move past pending state.
   *
   * There are 4 possible outcomes:
   * 1. Transaction is processed and successfully committed to the blockchain.
   * 2. Transaction is rejected for some reason, and is therefore not committed
   *    to the blockchain.
   * 3. Transaction is committed but execution failed, meaning no changes were
   *    written to the blockchain state.
   * 4. Transaction is not processed within the specified timeout.
   *
   * In case 1, this function resolves with the transaction response returned
   * by the API.
   *
   * In case 2, the function will throw an ApiError, likely with an HTTP status
   * code indicating some problem with the request (e.g. 400).
   *
   * In case 3, if `checkSuccess` is false (the default), this function returns
   * the transaction response just like in case 1, in which the `success` field
   * will be false. If `checkSuccess` is true, it will instead throw a
   * FailedTransactionError.
   *
   * In case 4, this function throws a WaitForTransactionError.
   *
   * @param txnHash The hash of a transaction previously submitted to the blockchain.
   * @param extraArgs.timeoutSecs Timeout in seconds. Defaults to 20 seconds.
   * @param extraArgs.checkSuccess See above. Defaults to false.
   * @returns See above.
   *
   * @example
   * ```
   * const rawTransaction = await this.generateRawTransaction(sender.address(), payload, extraArgs);
   * const bcsTxn = AptosClient.generateBCSTransaction(sender, rawTransaction);
   * const pendingTransaction = await this.submitSignedBCSTransaction(bcsTxn);
   * const transasction = await this.aptosClient.waitForTransactionWithResult(pendingTransaction.hash);
   * ```
   */
  async waitForTransactionWithResult(e, n) {
    var r, i;
    const o = (r = n == null ? void 0 : n.timeoutSecs) != null ? r : Rh, c = (i = n == null ? void 0 : n.checkSuccess) != null ? i : !1;
    let f = !0, y = 0, w;
    for (; f && !(y >= o); ) {
      try {
        if (w = await this.getTransactionByHash(e), f = w.type === "pending_transaction", !f)
          break;
      } catch (_) {
        const m = _ instanceof ho, I = m && _.status !== 404 && _.status >= 400 && _.status < 500;
        if (!m || I)
          throw _;
      }
      await Ph(1e3), y += 1;
    }
    if (w === void 0)
      throw new Error(`Waiting for transaction ${e} failed`);
    if (f)
      throw new M0(
        `Waiting for transaction ${e} timed out after ${o} seconds`,
        w
      );
    if (!c)
      return w;
    if (!(w != null && w.success))
      throw new H0(
        `Transaction ${e} failed with an error: ${w.vm_status}`,
        w
      );
    return w;
  }
  /**
   * This function works the same as `waitForTransactionWithResult` except it
   * doesn't return the transaction in those cases, it returns nothing. For
   * more information, see the documentation for `waitForTransactionWithResult`.
   */
  async waitForTransaction(e, n) {
    await this.waitForTransactionWithResult(e, n);
  }
  async getLedgerInfo() {
    const { data: e } = await ct({
      url: this.nodeUrl,
      originMethod: "getLedgerInfo",
      overrides: { ...this.config }
    });
    return e;
  }
  async getChainId() {
    return (await this.getLedgerInfo()).chain_id;
  }
  async getTableItem(e, n, r) {
    var i;
    return (await Yn({
      url: this.nodeUrl,
      body: n,
      endpoint: `tables/${e}/item`,
      originMethod: "getTableItem",
      params: { ledger_version: (i = r == null ? void 0 : r.ledgerVersion) == null ? void 0 : i.toString() },
      overrides: { ...this.config }
    })).data;
  }
  /**
   * Generates a raw transaction out of a transaction payload
   * @param accountFrom
   * @param payload
   * @param extraArgs
   * @returns A raw transaction object
   */
  async generateRawTransaction(e, n, r) {
    const [{ sequence_number: i }, o, { gas_estimate: c }] = await Promise.all([
      r != null && r.providedSequenceNumber ? Promise.resolve({ sequence_number: r.providedSequenceNumber }) : this.getAccount(e),
      this.getChainId(),
      r != null && r.gasUnitPrice ? Promise.resolve({ gas_estimate: r.gasUnitPrice }) : this.estimateGasPrice()
    ]), { maxGasAmount: f, gasUnitPrice: y, expireTimestamp: w } = {
      maxGasAmount: BigInt(ic),
      gasUnitPrice: BigInt(c),
      expireTimestamp: BigInt(Math.floor(Date.now() / 1e3) + sc),
      ...r
    };
    return new Oe.RawTransaction(
      Oe.AccountAddress.fromHex(e),
      BigInt(i),
      n,
      f,
      y,
      w,
      new Oe.ChainId(o)
    );
  }
  /**
   * Helper for generating, signing, and submitting a transaction.
   *
   * @param sender AptosAccount of transaction sender.
   * @param payload Transaction payload.
   * @param extraArgs Extra args for building the transaction payload.
   * @returns The transaction response from the API.
   */
  async generateSignSubmitTransaction(e, n, r) {
    const i = await this.generateRawTransaction(e.address(), n, r), o = Sn.generateBCSTransaction(e, i);
    return (await this.submitSignedBCSTransaction(o)).hash;
  }
  /**
   * Helper for signing and submitting a transaction.
   *
   * @param sender AptosAccount of transaction sender.
   * @param transaction A generated Raw transaction payload.
   * @returns The transaction response from the API.
   */
  async signAndSubmitTransaction(e, n) {
    const r = Sn.generateBCSTransaction(e, n);
    return (await this.submitSignedBCSTransaction(r)).hash;
  }
  /**
   * Publishes a move package. `packageMetadata` and `modules` can be generated with command
   * `aptos move compile --save-metadata [ --included-artifacts=<...> ]`.
   * @param sender
   * @param packageMetadata package metadata bytes
   * @param modules bytecodes of modules
   * @param extraArgs
   * @returns Transaction hash
   */
  async publishPackage(e, n, r, i) {
    const o = new Ne();
    Ke(r, o);
    const c = new Oe.TransactionPayloadEntryFunction(
      Oe.EntryFunction.natural(
        "0x1::code",
        "publish_package_txn",
        [],
        [Zt(n), o.getBytes()]
      )
    );
    return this.generateSignSubmitTransaction(e, c, i);
  }
  /**
   * Publishes a move packages by creating a resource account.
   * The package cannot be upgraded since it is deployed by resource account
   * `packageMetadata` and `modules` can be generated with command
   * `aptos move compile --save-metadata [ --included-artifacts=<...> ]`.
   * @param sender
   * @param seed seeds for creation of resource address
   * @param packageMetadata package metadata bytes
   * @param modules bytecodes of modules
   * @param extraArgs
   * @returns Transaction hash
   */
  async createResourceAccountAndPublishPackage(e, n, r, i, o) {
    const c = new Ne();
    Ke(i, c);
    const f = new Oe.TransactionPayloadEntryFunction(
      Oe.EntryFunction.natural(
        "0x1::resource_account",
        "create_resource_account_and_publish_package",
        [],
        [Zt(n), Zt(r), c.getBytes()]
      )
    );
    return this.generateSignSubmitTransaction(e, f, o);
  }
  /**
   * Helper for generating, submitting, and waiting for a transaction, and then
   * checking whether it was committed successfully. Under the hood this is just
   * `generateSignSubmitTransaction` and then `waitForTransactionWithResult`, see
   * those for information about the return / error semantics of this function.
   */
  async generateSignSubmitWaitForTransaction(e, n, r) {
    const i = await this.generateSignSubmitTransaction(e, n, r);
    return this.waitForTransactionWithResult(i, r);
  }
  async estimateGasPrice() {
    const { data: e } = await ct({
      url: this.nodeUrl,
      endpoint: "estimate_gas_price",
      originMethod: "estimateGasPrice",
      overrides: { ...this.config }
    });
    return e;
  }
  async estimateMaxGasAmount(e) {
    const n = `0x1::coin::CoinStore<${kh}>`, [{ gas_estimate: r }, i] = await Promise.all([
      this.estimateGasPrice(),
      this.getAccountResources(e)
    ]), o = i.find((f) => f.type === n);
    return BigInt(o.data.coin.value) / BigInt(r);
  }
  /**
   * Rotate an account's auth key. After rotation, only the new private key can be used to sign txns for
   * the account.
   * WARNING: You must create a new instance of AptosAccount after using this function.
   * @param forAccount Account of which the auth key will be rotated
   * @param toPrivateKeyBytes New private key
   * @param extraArgs Extra args for building the transaction payload.
   * @returns PendingTransaction
   */
  async rotateAuthKeyEd25519(e, n, r) {
    const { sequence_number: i, authentication_key: o } = await this.getAccount(
      e.address()
    ), c = new Yo(n), f = new Oe.RotationProofChallenge(
      Oe.AccountAddress.CORE_CODE_ADDRESS,
      "account",
      "RotationProofChallenge",
      BigInt(i),
      Oe.AccountAddress.fromHex(e.address()),
      new Oe.AccountAddress(new J(o).toUint8Array()),
      c.pubKey().toUint8Array()
    ), y = J.fromUint8Array($t(f)), w = e.signHexString(y), _ = c.signHexString(y), m = new Oe.TransactionPayloadEntryFunction(
      Oe.EntryFunction.natural(
        "0x1::account",
        "rotate_authentication_key",
        [],
        [
          As(0),
          // ed25519 scheme
          Zt(e.pubKey().toUint8Array()),
          As(0),
          // ed25519 scheme
          Zt(c.pubKey().toUint8Array()),
          Zt(w.toUint8Array()),
          Zt(_.toUint8Array())
        ]
      )
    ), I = await this.generateRawTransaction(e.address(), m, r), z = Sn.generateBCSTransaction(e, I);
    return this.submitSignedBCSTransaction(z);
  }
  /**
   * Lookup the original address by the current derived address
   * @param addressOrAuthKey
   * @returns original address
   */
  async lookupOriginalAddress(e) {
    const n = await this.getAccountResource("0x1", "0x1::account::OriginatingAddress"), {
      address_map: { handle: r }
    } = n.data, i = await this.getTableItem(r, {
      key_type: "address",
      value_type: "address",
      key: J.ensure(e).hex()
    });
    return new J(i);
  }
  async getBlockByHeight(e, n) {
    const { data: r } = await ct({
      url: this.nodeUrl,
      endpoint: `blocks/by_height/${e}`,
      originMethod: "getBlockByHeight",
      params: { with_transactions: n },
      overrides: { ...this.config }
    });
    return r;
  }
  async getBlockByVersion(e, n) {
    const { data: r } = await ct({
      url: this.nodeUrl,
      endpoint: `blocks/by_version/${e}`,
      originMethod: "getBlockByVersion",
      params: { with_transactions: n },
      overrides: { ...this.config }
    });
    return r;
  }
  async view(e, n) {
    const { data: r } = await Yn({
      url: this.nodeUrl,
      body: e,
      endpoint: "view",
      originMethod: "getTableItem",
      params: { ledger_version: n },
      overrides: { ...this.config }
    });
    return r;
  }
  // eslint-disable-next-line class-methods-use-this
  clearCache(e) {
    Nh(e);
  }
};
Be([
  Qe
], Le.prototype, "getAccount", 1);
Be([
  Qe
], Le.prototype, "getAccountTransactions", 1);
Be([
  Qe,
  oc(10 * 60 * 1e3)
], Le.prototype, "getAccountModules", 1);
Be([
  Qe
], Le.prototype, "getAccountModule", 1);
Be([
  Qe
], Le.prototype, "getAccountResources", 1);
Be([
  Qe
], Le.prototype, "getAccountResource", 1);
Be([
  Qe
], Le.prototype, "getEventsByCreationNumber", 1);
Be([
  Qe
], Le.prototype, "getEventsByEventHandle", 1);
Be([
  Qe
], Le.prototype, "submitSignedBCSTransaction", 1);
Be([
  Qe
], Le.prototype, "submitBCSSimulation", 1);
Be([
  Qe
], Le.prototype, "getTransactions", 1);
Be([
  Qe
], Le.prototype, "getTransactionByHash", 1);
Be([
  Qe
], Le.prototype, "getTransactionByVersion", 1);
Be([
  Qe
], Le.prototype, "getLedgerInfo", 1);
Be([
  Fi()
], Le.prototype, "getChainId", 1);
Be([
  Qe
], Le.prototype, "getTableItem", 1);
Be([
  Qe,
  Fi({
    ttlMs: 5 * 60 * 1e3,
    // cache result for 5min
    tags: ["gas_estimates"]
  })
], Le.prototype, "estimateGasPrice", 1);
Be([
  Qe
], Le.prototype, "estimateMaxGasAmount", 1);
Be([
  Qe
], Le.prototype, "getBlockByHeight", 1);
Be([
  Qe
], Le.prototype, "getBlockByVersion", 1);
Be([
  Qe
], Le.prototype, "view", 1);
var bu = Le, M0 = class extends Error {
  constructor(t, e) {
    super(t), this.lastSubmittedTransaction = e;
  }
}, H0 = class extends Error {
  constructor(t, e) {
    super(t), this.transaction = e;
  }
}, ho = class extends Error {
  constructor(t, e, n, r) {
    super(e), this.status = t, this.message = e, this.errorCode = n, this.vmErrorCode = r;
  }
};
function Qe(t, e, n) {
  const r = n.value;
  return n.value = async function(...o) {
    var c, f;
    try {
      return await r.apply(this, [...o]);
    } catch (y) {
      throw y instanceof ac ? new ho(
        y.status,
        JSON.stringify({ message: y.message, ...y.data }),
        (c = y.data) == null ? void 0 : c.error_code,
        (f = y.data) == null ? void 0 : f.vm_error_code
      ) : y;
    }
  }, n;
}
var Eu = class $e {
  /**
   * @param endpoint URL of the Aptos Indexer API endpoint.
   */
  constructor(e, n) {
    this.endpoint = e, this.config = n;
  }
  /**
   * Indexer only accepts address in the long format, i.e a 66 chars long -> 0x<64 chars>
   * This method makes sure address is 66 chars long.
   * @param address
   */
  static validateAddress(e) {
    if (e.length < 66)
      throw new Error(`${e} is less than 66 chars long.`);
  }
  /**
   * Makes axios client call to fetch data from Aptos Indexer.
   *
   * @param graphqlQuery A GraphQL query to pass in the `data` axios call.
   */
  async queryIndexer(e) {
    const n = await Yn({
      url: this.endpoint,
      body: e,
      overrides: { WITH_CREDENTIALS: !1, ...this.config }
    });
    if (n.data.errors)
      throw new ho(
        n.data.errors[0].extensions.code,
        JSON.stringify({
          message: n.data.errors[0].message,
          error_code: n.data.errors[0].extensions.code
        })
      );
    return n.data.data;
  }
  /**
   * Queries Indexer Ledger Info
   *
   * @returns GetLedgerInfoQuery response type
   */
  async getIndexerLedgerInfo() {
    const e = {
      query: _0
    };
    return this.queryIndexer(e);
  }
  // TOKENS //
  /**
   * @deprecated please use `getOwnedTokens` query
   *
   * Queries an Aptos account's NFTs by owner address
   *
   * @param ownerAddress Hex-encoded 32 byte Aptos account address
   * @returns GetAccountCurrentTokensQuery response type
   */
  async getAccountNFTs(e, n) {
    const r = J.ensure(e).hex();
    $e.validateAddress(r);
    const i = {
      query: d0,
      variables: { address: r, offset: n == null ? void 0 : n.offset, limit: n == null ? void 0 : n.limit }
    };
    return this.queryIndexer(i);
  }
  /**
   * Queries a token activities by token address (v2) or token data id (v1)
   *
   * @param idHash token address (v2) or token data id (v1)
   * @returns GetTokenActivitiesQuery response type
   */
  async getTokenActivities(e, n) {
    var r, i;
    const o = J.ensure(e).hex();
    $e.validateAddress(o);
    const c = {
      token_data_id: { _eq: o }
    };
    n != null && n.tokenStandard && (c.token_standard = { _eq: n == null ? void 0 : n.tokenStandard });
    const f = {
      query: v0,
      variables: {
        where_condition: c,
        offset: (r = n == null ? void 0 : n.options) == null ? void 0 : r.offset,
        limit: (i = n == null ? void 0 : n.options) == null ? void 0 : i.limit,
        order_by: n == null ? void 0 : n.orderBy
      }
    };
    return this.queryIndexer(f);
  }
  /**
   * Gets the count of token's activities by token address (v2) or token data id (v1)
   *
   * @param token token address (v2) or token data id (v1)
   * @returns GetTokenActivitiesCountQuery response type
   */
  async getTokenActivitiesCount(e) {
    const n = {
      query: T0,
      variables: { token_id: e }
    };
    return this.queryIndexer(n);
  }
  /**
   * Gets the count of tokens owned by an account
   *
   * @param ownerAddress Owner address
   * @returns AccountTokensCountQuery response type
   */
  async getAccountTokensCount(e, n) {
    var r, i;
    const o = {
      owner_address: { _eq: e },
      amount: { _gt: "0" }
    };
    n != null && n.tokenStandard && (o.token_standard = { _eq: n == null ? void 0 : n.tokenStandard });
    const c = J.ensure(e).hex();
    $e.validateAddress(c);
    const f = {
      query: h0,
      variables: {
        where_condition: o,
        offset: (r = n == null ? void 0 : n.options) == null ? void 0 : r.offset,
        limit: (i = n == null ? void 0 : n.options) == null ? void 0 : i.limit
      }
    };
    return this.queryIndexer(f);
  }
  /**
   * Queries token data by token address (v2) or token data id (v1)
   *
   * @param token token address (v2) or token data id (v1)
   * @returns GetTokenDataQuery response type
   */
  // :!:>getTokenData
  async getTokenData(e, n) {
    var r, i;
    const o = J.ensure(e).hex();
    $e.validateAddress(o);
    const c = {
      token_data_id: { _eq: o }
    };
    n != null && n.tokenStandard && (c.token_standard = { _eq: n == null ? void 0 : n.tokenStandard });
    const f = {
      query: S0,
      variables: {
        where_condition: c,
        offset: (r = n == null ? void 0 : n.options) == null ? void 0 : r.offset,
        limit: (i = n == null ? void 0 : n.options) == null ? void 0 : i.limit,
        order_by: n == null ? void 0 : n.orderBy
      }
    };
    return this.queryIndexer(f);
  }
  // <:!:getTokenData
  /**
   * Queries token owners data by token address (v2) or token data id (v1).
   * This query returns historical owners data.
   *
   * To fetch token v2 standard, pass in the optional `tokenStandard` parameter and
   * dont pass `propertyVersion` parameter (as propertyVersion only compatible with v1 standard)
   *
   * @param token token address (v2) or token data id (v1)
   * @param propertyVersion Property version (optional) - only compatible with token v1 standard
   * @returns GetTokenOwnersDataQuery response type
   */
  async getTokenOwnersData(e, n, r) {
    var i, o;
    const c = J.ensure(e).hex();
    $e.validateAddress(c);
    const f = {
      token_data_id: { _eq: c },
      amount: { _gt: "0" }
    };
    n && (f.property_version_v1 = { _eq: n }), r != null && r.tokenStandard && (f.token_standard = { _eq: r == null ? void 0 : r.tokenStandard });
    const y = {
      query: U0,
      variables: {
        where_condition: f,
        offset: (i = r == null ? void 0 : r.options) == null ? void 0 : i.offset,
        limit: (o = r == null ? void 0 : r.options) == null ? void 0 : o.limit,
        order_by: r == null ? void 0 : r.orderBy
      }
    };
    return this.queryIndexer(y);
  }
  /**
   * Queries current token owner data by token address (v2) or token data id (v1).
   * This query returns the current token owner data.
   *
   * To fetch token v2 standard, pass in the optional `tokenStandard` parameter and
   * dont pass `propertyVersion` parameter (as propertyVersion only compatible with v1 standard)
   *
   * @param token token address (v2) or token data id (v1)
   * @param propertyVersion Property version (optional) - only compatible with token v1 standard
   * @returns GetTokenCurrentOwnerDataQuery response type
   */
  async getTokenCurrentOwnerData(e, n, r) {
    var i, o;
    const c = J.ensure(e).hex();
    $e.validateAddress(c);
    const f = {
      token_data_id: { _eq: c },
      amount: { _gt: "0" }
    };
    n && (f.property_version_v1 = { _eq: n }), r != null && r.tokenStandard && (f.token_standard = { _eq: r == null ? void 0 : r.tokenStandard });
    const y = {
      query: B0,
      variables: {
        where_condition: f,
        offset: (i = r == null ? void 0 : r.options) == null ? void 0 : i.offset,
        limit: (o = r == null ? void 0 : r.options) == null ? void 0 : o.limit,
        order_by: r == null ? void 0 : r.orderBy
      }
    };
    return this.queryIndexer(y);
  }
  /**
   * Queries account's current owned tokens.
   * This query returns all tokens (v1 and v2 standards) an account owns, including NFTs, fungible, soulbound, etc.
   * If you want to get only the token from a specific standrd, you can pass an optional tokenStandard param
   *
   * @param ownerAddress The token owner address we want to get the tokens for
   * @returns GetOwnedTokensQuery response type
   */
  async getOwnedTokens(e, n) {
    var r, i;
    const o = J.ensure(e).hex();
    $e.validateAddress(o);
    const c = {
      owner_address: { _eq: o },
      amount: { _gt: 0 }
    };
    n != null && n.tokenStandard && (c.token_standard = { _eq: n == null ? void 0 : n.tokenStandard });
    const f = {
      query: b0,
      variables: {
        where_condition: c,
        offset: (r = n == null ? void 0 : n.options) == null ? void 0 : r.offset,
        limit: (i = n == null ? void 0 : n.options) == null ? void 0 : i.limit,
        order_by: n == null ? void 0 : n.orderBy
      }
    };
    return this.queryIndexer(f);
  }
  /**
   * Queries account's current owned tokens by token address (v2) or token data id (v1).
   *
   * @param token token address (v2) or token data id (v1)
   * @returns GetOwnedTokensByTokenDataQuery response type
   */
  async getOwnedTokensByTokenData(e, n) {
    var r, i;
    const o = J.ensure(e).hex();
    $e.validateAddress(o);
    const c = {
      token_data_id: { _eq: o },
      amount: { _gt: 0 }
    };
    n != null && n.tokenStandard && (c.token_standard = { _eq: n == null ? void 0 : n.tokenStandard });
    const f = {
      query: E0,
      variables: {
        where_condition: c,
        offset: (r = n == null ? void 0 : n.options) == null ? void 0 : r.offset,
        limit: (i = n == null ? void 0 : n.options) == null ? void 0 : i.limit,
        order_by: n == null ? void 0 : n.orderBy
      }
    };
    return this.queryIndexer(f);
  }
  /**
   * Queries all tokens of a specific collection that an account owns by the collection address
   *
   * @param ownerAddress owner address that owns the tokens
   * @param collectionAddress the collection address
   * @returns GetTokenOwnedFromCollectionQuery response type
   */
  async getTokenOwnedFromCollectionAddress(e, n, r) {
    var i, o;
    const c = J.ensure(e).hex();
    $e.validateAddress(c);
    const f = J.ensure(n).hex();
    $e.validateAddress(f);
    const y = {
      owner_address: { _eq: c },
      current_token_data: { collection_id: { _eq: f } },
      amount: { _gt: 0 }
    };
    r != null && r.tokenStandard && (y.token_standard = { _eq: r == null ? void 0 : r.tokenStandard });
    const w = {
      query: I0,
      variables: {
        where_condition: y,
        offset: (i = r == null ? void 0 : r.options) == null ? void 0 : i.offset,
        limit: (o = r == null ? void 0 : r.options) == null ? void 0 : o.limit,
        order_by: r == null ? void 0 : r.orderBy
      }
    };
    return this.queryIndexer(w);
  }
  /**
   * Queries all tokens of a specific collection that an account owns by the collection name and collection
   * creator address
   *
   * @param ownerAddress owner address that owns the tokens
   * @param collectionName the collection name
   * @param creatorAddress the collection creator address
   * @returns GetTokenOwnedFromCollectionQuery response type
   */
  async getTokenOwnedFromCollectionNameAndCreatorAddress(e, n, r, i) {
    const o = await this.getCollectionAddress(r, n, i);
    return await this.getTokenOwnedFromCollectionAddress(e, o, i);
  }
  /**
   * Queries data of a specific collection by the collection creator address and the collection name.
   *
   * if, for some reason, a creator account has 2 collections with the same name in v1 and v2,
   * can pass an optional `tokenStandard` parameter to query a specific standard
   *
   * @param creatorAddress the collection creator address
   * @param collectionName the collection name
   * @returns GetCollectionDataQuery response type
   */
  async getCollectionData(e, n, r) {
    var i, o;
    const c = J.ensure(e).hex();
    $e.validateAddress(c);
    const f = {
      collection_name: { _eq: n },
      creator_address: { _eq: c }
    };
    r != null && r.tokenStandard && (f.token_standard = { _eq: r == null ? void 0 : r.tokenStandard });
    const y = {
      query: y0,
      variables: {
        where_condition: f,
        offset: (i = r == null ? void 0 : r.options) == null ? void 0 : i.offset,
        limit: (o = r == null ? void 0 : r.options) == null ? void 0 : o.limit,
        order_by: r == null ? void 0 : r.orderBy
      }
    };
    return this.queryIndexer(y);
  }
  /**
   * Queries a collection address.
   *
   * @param creatorAddress the collection creator address
   * @param collectionName the collection name
   * @returns the collection address
   */
  async getCollectionAddress(e, n, r) {
    return (await this.getCollectionData(e, n, r)).current_collections_v2[0].collection_id;
  }
  /**
   * Queries for all collections that an account has tokens for.
   *
   * @param ownerAddress the account address that owns the tokens
   * @returns GetCollectionsWithOwnedTokensQuery response type
   */
  async getCollectionsWithOwnedTokens(e, n) {
    var r, i;
    const o = J.ensure(e).hex();
    $e.validateAddress(o);
    const c = {
      owner_address: { _eq: o }
    };
    n != null && n.tokenStandard && (c.current_collection = { token_standard: { _eq: n == null ? void 0 : n.tokenStandard } });
    const f = {
      query: w0,
      variables: {
        where_condition: c,
        offset: (r = n == null ? void 0 : n.options) == null ? void 0 : r.offset,
        limit: (i = n == null ? void 0 : n.options) == null ? void 0 : i.limit,
        order_by: n == null ? void 0 : n.orderBy
      }
    };
    return this.queryIndexer(f);
  }
  // TRANSACTIONS //
  /**
   * Gets the count of transactions submitted by an account
   *
   * @param address Account address
   * @returns GetAccountTransactionsCountQuery response type
   */
  async getAccountTransactionsCount(e) {
    const n = J.ensure(e).hex();
    $e.validateAddress(n);
    const r = {
      query: p0,
      variables: { address: n }
    };
    return this.queryIndexer(r);
  }
  /**
   * Queries an account transactions data
   *
   * @param address Account address
   * @returns GetAccountTransactionsDataQuery response type
   */
  async getAccountTransactionsData(e, n) {
    var r, i;
    const o = J.ensure(e).hex();
    $e.validateAddress(o);
    const f = {
      query: A0,
      variables: {
        where_condition: {
          account_address: { _eq: o }
        },
        offset: (r = n == null ? void 0 : n.options) == null ? void 0 : r.offset,
        limit: (i = n == null ? void 0 : n.options) == null ? void 0 : i.limit,
        order_by: n == null ? void 0 : n.orderBy
      }
    };
    return this.queryIndexer(f);
  }
  /**
   * Queries top user transactions
   *
   * @param limit
   * @returns GetTopUserTransactionsQuery response type
   */
  async getTopUserTransactions(e) {
    const n = {
      query: C0,
      variables: { limit: e }
    };
    return this.queryIndexer(n);
  }
  /**
   * Queries top user transactions
   *
   * @param startVersion optional - can be set to tell indexer what version to start from
   * @returns GetUserTransactionsQuery response type
   */
  async getUserTransactions(e) {
    var n, r;
    const i = {
      version: { _lte: e == null ? void 0 : e.startVersion }
    }, o = {
      query: P0,
      variables: {
        where_condition: i,
        offset: (n = e == null ? void 0 : e.options) == null ? void 0 : n.offset,
        limit: (r = e == null ? void 0 : e.options) == null ? void 0 : r.limit,
        order_by: e == null ? void 0 : e.orderBy
      }
    };
    return this.queryIndexer(o);
  }
  // STAKING //
  /**
   * Queries delegated staking activities
   *
   * @param delegatorAddress Delegator address
   * @param poolAddress Pool address
   * @returns GetDelegatedStakingActivitiesQuery response type
   */
  async getDelegatedStakingActivities(e, n) {
    const r = J.ensure(e).hex(), i = J.ensure(n).hex();
    $e.validateAddress(r), $e.validateAddress(i);
    const o = {
      query: x0,
      variables: {
        delegatorAddress: r,
        poolAddress: i
      }
    };
    return this.queryIndexer(o);
  }
  /**
   * Queries current number of delegators in a pool
   *
   * @returns GetNumberOfDelegatorsQuery response type
   */
  async getNumberOfDelegators(e) {
    const n = J.ensure(e).hex();
    $e.validateAddress(n);
    const r = {
      query: m0,
      variables: { poolAddress: n }
    };
    return this.queryIndexer(r);
  }
  // ACCOUNT //
  /**
   * Queries an account coin data
   *
   * @param ownerAddress Owner address
   * @returns GetAccountCoinsDataQuery response type
   */
  async getAccountCoinsData(e, n) {
    var r, i;
    const o = J.ensure(e).hex();
    $e.validateAddress(o);
    const f = {
      query: l0,
      variables: {
        where_condition: {
          owner_address: { _eq: o }
        },
        offset: (r = n == null ? void 0 : n.options) == null ? void 0 : r.offset,
        limit: (i = n == null ? void 0 : n.options) == null ? void 0 : i.limit,
        order_by: n == null ? void 0 : n.orderBy
      }
    };
    return this.queryIndexer(f);
  }
  /**
   * Queries an account coin data count
   *
   * @param ownerAddress Owner address
   * @returns GetAccountCoinsDataCountQuery response type
   */
  async getAccountCoinsDataCount(e) {
    const n = J.ensure(e).hex();
    $e.validateAddress(n);
    const r = {
      query: f0,
      variables: {
        address: n
      }
    };
    return this.queryIndexer(r);
  }
  /**
   * Queries an account owned objects
   *
   * @param ownerAddress Owner address
   * @returns GetCurrentObjectsQuery response type
   */
  async getAccountOwnedObjects(e, n) {
    var r, i;
    const o = J.ensure(e).hex();
    $e.validateAddress(o);
    const f = {
      query: g0,
      variables: {
        where_condition: {
          owner_address: { _eq: o }
        },
        offset: (r = n == null ? void 0 : n.options) == null ? void 0 : r.offset,
        limit: (i = n == null ? void 0 : n.options) == null ? void 0 : i.limit,
        order_by: n == null ? void 0 : n.orderBy
      }
    };
    return this.queryIndexer(f);
  }
}, vu = class {
  constructor(t, e, n = !1) {
    let r = null, i = null;
    if (typeof t == "object" && $0(t) ? (r = t.fullnodeUrl, i = t.indexerUrl, this.network = "CUSTOM") : (r = Lh[t], i = Dh[t], this.network = t), this.network === "CUSTOM" && !r)
      throw new Error("fullnode url is not provided");
    i && (this.indexerClient = new Eu(i, e)), this.aptosClient = new bu(r, e, n);
  }
};
function Tu(t, e, n) {
  Object.getOwnPropertyNames(e.prototype).forEach((r) => {
    const i = Object.getOwnPropertyDescriptor(e.prototype, r);
    i && (i.value = function(...o) {
      return this[n][r](...o);
    }, Object.defineProperty(t.prototype, r, i));
  }), Object.getOwnPropertyNames(e).forEach((r) => {
    const i = Object.getOwnPropertyDescriptor(e, r);
    i && (i.value = function(...o) {
      return this[n][r](...o);
    }, !t.hasOwnProperty.call(t, r) && Object.defineProperty(t, r, i));
  });
}
Tu(vu, bu, "aptosClient");
Tu(vu, Eu, "indexerClient");
function $0(t) {
  return t.fullnodeUrl !== void 0 && typeof t.fullnodeUrl == "string";
}
var Bu = class {
  constructor(t, e) {
    this.type = t, this.value = e;
  }
}, Su = class {
  constructor() {
    this.data = {};
  }
  setProperty(t, e) {
    this.data[t] = e;
  }
};
function q0(t) {
  let e;
  return t === "string" || t === "String" ? e = new wn(Ws) : e = new gr(t).parseTypeTag(), e;
}
function Iu(t) {
  const e = t.map.data, n = new Su();
  return e.forEach((r) => {
    const { key: i } = r, o = r.value.value, c = r.value.type, f = q0(c), y = Q0(f, o), w = new Bu(c, y);
    n.setProperty(i, w);
  }), n;
}
function Q0(t, e) {
  const n = new qs(new J(e).toUint8Array());
  let r = "";
  return t instanceof nn ? r = n.deserializeU8().toString() : t instanceof Ln ? r = n.deserializeU64().toString() : t instanceof Mn ? r = n.deserializeU128().toString() : t instanceof Dn ? r = n.deserializeBool() ? "true" : "false" : t instanceof yn ? r = J.fromUint8Array(n.deserializeFixedBytes(32)).hex() : t instanceof wn && t.isStringTypeTag() ? r = n.deserializeStr() : r = e, r;
}
var j0 = {};
zi(j0, {
  PropertyMap: () => Su,
  PropertyValue: () => Bu,
  Token: () => W0,
  TokenData: () => G0
});
var G0 = class {
  constructor(t, e, n, r, i, o, c, f) {
    this.collection = t, this.description = e, this.name = n, this.maximum = r, this.supply = i, this.uri = o, this.default_properties = Iu(c), this.mutability_config = f;
  }
}, W0 = class {
  constructor(t, e, n) {
    this.id = t, this.amount = e, this.token_properties = Iu(n);
  }
}, K0 = {};
zi(K0, {
  AptosErrorCode: () => Uu,
  MoveFunctionVisibility: () => Cu,
  RoleType: () => Pu
});
var Uu = /* @__PURE__ */ ((t) => (t.ACCOUNT_NOT_FOUND = "account_not_found", t.RESOURCE_NOT_FOUND = "resource_not_found", t.MODULE_NOT_FOUND = "module_not_found", t.STRUCT_FIELD_NOT_FOUND = "struct_field_not_found", t.VERSION_NOT_FOUND = "version_not_found", t.TRANSACTION_NOT_FOUND = "transaction_not_found", t.TABLE_ITEM_NOT_FOUND = "table_item_not_found", t.BLOCK_NOT_FOUND = "block_not_found", t.STATE_VALUE_NOT_FOUND = "state_value_not_found", t.VERSION_PRUNED = "version_pruned", t.BLOCK_PRUNED = "block_pruned", t.INVALID_INPUT = "invalid_input", t.INVALID_TRANSACTION_UPDATE = "invalid_transaction_update", t.SEQUENCE_NUMBER_TOO_OLD = "sequence_number_too_old", t.VM_ERROR = "vm_error", t.HEALTH_CHECK_FAILED = "health_check_failed", t.MEMPOOL_IS_FULL = "mempool_is_full", t.INTERNAL_ERROR = "internal_error", t.WEB_FRAMEWORK_ERROR = "web_framework_error", t.BCS_NOT_SUPPORTED = "bcs_not_supported", t.API_DISABLED = "api_disabled", t))(Uu || {}), Cu = /* @__PURE__ */ ((t) => (t.PRIVATE = "private", t.PUBLIC = "public", t.FRIEND = "friend", t))(Cu || {}), Pu = /* @__PURE__ */ ((t) => (t.VALIDATOR = "validator", t.FULL_NODE = "full_node", t))(Pu || {});
const At = (t) => new Promise((e, n) => {
  const r = An(), i = (o) => {
    var c, f, y, w;
    if ((c = o.data) != null && c.isRazor && ((f = o.data) == null ? void 0 : f.type) === ut.RESPONSE__WEB_TO_CONTENT_SCRIPT && ((y = o.data) == null ? void 0 : y.messageId) === r) {
      window.removeEventListener("message", i);
      const { data: _ } = o;
      (w = _.response) != null && w.error ? n(_.response.error) : e(_.response.result);
    }
  };
  window.addEventListener("message", i), window.postMessage({
    isRazor: !0,
    line: hn.APTOS,
    type: ut.REQUEST__WEB_TO_CONTENT_SCRIPT,
    messageId: r,
    message: t
  });
}), Jr = (t, e) => {
  const n = (r) => {
    var i, o, c, f, y, w, _;
    (i = r.data) != null && i.isRazor && ((o = r.data) == null ? void 0 : o.type) === t && ((c = r.data) == null ? void 0 : c.line) === "APTOS" && (t === "accountChange" && !((y = (f = r.data) == null ? void 0 : f.message) != null && y.result) ? (async () => {
      try {
        const m = await At({
          method: "aptos_account",
          params: void 0
        });
        e(m.address);
      } catch {
        e("");
      }
    })() : e((_ = (w = r.data) == null ? void 0 : w.message) == null ? void 0 : _.result));
  };
  window.addEventListener("message", n), window.razor.handlerInfos.push({
    line: "APTOS",
    eventName: t,
    originHandler: e,
    handler: n
  });
}, Xr = (t, e) => {
  const n = window.razor.handlerInfos.filter(
    (i) => i.line === "APTOS" && i.eventName === t && i.originHandler === e
  ), r = window.razor.handlerInfos.filter(
    (i) => !(i.line === "APTOS" && i.eventName === t && i.originHandler === e)
  );
  n.forEach((i) => {
    window.removeEventListener("message", i.handler);
  }), window.razor.handlerInfos = r;
}, Ou = () => At({
  method: "aptos_connect",
  params: void 0
}), Y0 = () => At({
  method: "aptos_disconnect",
  params: void 0
}), V0 = () => At({
  method: "aptos_isConnected",
  params: void 0
}), ms = () => At({
  method: "aptos_network",
  params: void 0
}), Ru = () => At({
  method: "aptos_account",
  params: void 0
}), J0 = (t) => At({
  method: "aptos_signAndSubmitTransaction",
  params: [t]
}), X0 = (t) => At({
  method: "aptos_signTransaction",
  params: [t]
}), ku = (t) => At({
  method: "aptos_signMessage",
  params: [t]
}), Z0 = (t) => {
  Jr("accountChange", t);
}, ep = (t) => {
  Xr("accountChange", t);
}, tp = (t) => {
  Jr("networkChange", t);
}, np = (t) => {
  Xr("networkChange", t);
};
var Zr, ei, ti, Ft, Dt, fr, ni, ri, ii, si, oi, ai, ci, ui, fi, li, di, Nu, hi, zu, pi, Fu, Ai, Du;
class rp {
  constructor() {
    he(this, di);
    he(this, hi);
    he(this, pi);
    he(this, Ai);
    he(this, Zr, "https://razorwallet.xyz");
    he(this, ei, "1.0.0");
    he(this, ti, "Razor Wallet");
    he(this, Ft, null);
    he(this, Dt, void 0);
    he(this, fr, void 0);
    he(this, ni, (e, n) => (te(this, Dt).on(e, n), () => te(this, Dt).off(e, n)));
    he(this, ri, async () => {
      const e = await Ru(), n = {
        address: e.address,
        publicKey: e.publicKey
      };
      return Promise.resolve(n);
    });
    he(this, ii, async () => await kt(this, hi, zu).call(this));
    he(this, si, async () => {
      try {
        const e = await Ou(), { address: n, publicKey: r } = e, o = await kt(this, di, Nu).call(this);
        if (te(this, Ft) && te(this, Ft).address === n)
          return {
            status: dn.APPROVED,
            args: {
              address: this.accounts[0].address,
              publicKey: this.accounts[0].publicKey.toString()
            }
          };
        lt(this, Ft, new Ii({
          address: n,
          publicKey: new Uint8Array(Buffer.from(r, "hex")),
          chains: [o],
          features: [
            "aptos:account",
            "aptos:connect",
            "aptos:disconnect",
            "aptos:network",
            "aptos:signTransaction",
            "aptos:signAndSubmitTransaction",
            "aptos:signMessage",
            "aptos:onAccountChange",
            "aptos:onNetworkChange"
            /* APTOS__ON__NETWORK_CHANGE */
          ]
        })), te(this, Dt).emit("change", { accounts: this.accounts });
        const c = {
          address: e.address,
          publicKey: e.publicKey
        };
        return {
          status: dn.APPROVED,
          args: c
        };
      } catch {
        return {
          status: dn.REJECTED
        };
      }
    });
    he(this, oi, async () => {
      lt(this, Ft, null), te(this, Dt).all.clear();
    });
    he(this, ai, async (e) => {
      const n = await At({
        method: "aptos_signTransaction",
        params: [e]
      });
      return Promise.resolve({
        status: dn.APPROVED,
        args: n
      });
    });
    he(this, ci, async (e) => {
      const n = await At({
        method: "aptos_signAndSubmitTransaction",
        params: [e]
      });
      return Promise.resolve({
        status: dn.APPROVED,
        args: n
      });
    });
    he(this, ui, async (e) => {
      const n = await ku({
        address: e.address,
        application: e.application,
        chainId: e.chainId,
        message: e.message,
        nonce: e.nonce
      });
      return Promise.resolve({
        status: dn.APPROVED,
        args: n
      });
    });
    he(this, fi, async () => Promise.resolve());
    he(this, li, async () => Promise.resolve());
    lt(this, Dt, oa()), lt(this, fr, new ya(
      er.DAPP,
      er.RAZOR_CONTENT,
      window.origin
    )), kt(this, pi, Fu).call(this, te(this, fr));
  }
  get version() {
    return te(this, ei);
  }
  get name() {
    return te(this, ti);
  }
  get icon() {
    return Ps;
  }
  get url() {
    return te(this, Zr);
  }
  get chains() {
    return [
      mo,
      bo,
      Eo
    ];
  }
  get accounts() {
    return te(this, Ft) ? [te(this, Ft)] : [];
  }
  get features() {
    return {
      "aptos:connect": {
        version: "1.0.0",
        connect: te(this, si)
      },
      "standard:events": {
        version: "1.0.0",
        on: te(this, ni)
      },
      "aptos:network": {
        version: "1.0.0",
        network: te(this, ii)
      },
      "aptos:disconnect": {
        version: "1.0.0",
        disconnect: te(this, oi)
      },
      "aptos:signTransaction": {
        version: "1.0.0",
        signTransaction: te(this, ai)
      },
      "aptos:signAndSubmitTransaction": {
        version: "1.0.0",
        signAndSubmitTransaction: te(this, ci)
      },
      "aptos:signMessage": {
        version: "1.0.0",
        signMessage: te(this, ui)
      },
      "aptos:onAccountChange": {
        version: "1.0.0",
        onAccountChange: te(this, fi)
      },
      "aptos:onNetworkChange": {
        version: "1.0.0",
        onNetworkChange: te(this, li)
      },
      "aptos:account": {
        version: "1.0.0",
        account: te(this, ri)
      }
    };
  }
}
Zr = new WeakMap(), ei = new WeakMap(), ti = new WeakMap(), Ft = new WeakMap(), Dt = new WeakMap(), fr = new WeakMap(), ni = new WeakMap(), ri = new WeakMap(), ii = new WeakMap(), si = new WeakMap(), oi = new WeakMap(), ai = new WeakMap(), ci = new WeakMap(), ui = new WeakMap(), fi = new WeakMap(), li = new WeakMap(), di = new WeakSet(), Nu = async function() {
  const e = await ms();
  return e.name === "M1 Devnet" ? mo : e.name === "Testnet" ? bo : Eo;
}, hi = new WeakSet(), zu = async function() {
  const e = await ms();
  return e.name === "M1 Devnet" ? {
    name: Hr.DEVNET,
    chainId: e.chainId,
    url: e.url
  } : e.name === "Testnet" ? {
    name: Hr.TESTNET,
    chainId: e.chainId,
    url: e.url
  } : {
    name: Hr.MAINNET,
    chainId: e.chainId,
    url: e.url
  };
}, pi = new WeakSet(), Fu = function(e) {
  const n = [tr.NETWORK_SWITCH];
  return e.subscribe((r) => {
    var i;
    if (n.includes((i = r == null ? void 0 : r.payload) == null ? void 0 : i.id) && r.payload.id === tr.NETWORK_SWITCH)
      return kt(this, Ai, Du).call(this, r.payload);
  });
}, Ai = new WeakSet(), Du = function(e) {
  const { network: n } = e;
  n && te(this, Dt).emit("change", {
    chains: [n]
  });
};
const Jo = {
  on: Jr,
  addListener: Jr,
  off: Xr,
  removeListener: Xr,
  request: At,
  account: Ru,
  connect: Ou,
  disconnect: Y0,
  isConnected: V0,
  signAndSubmitTransaction: J0,
  signTransaction: X0,
  signMessage: ku,
  network: ms,
  onAccountChange: Z0,
  offAccountChange: ep,
  onNetworkChange: tp,
  offNetworkChange: np
}, ip = (t) => new Promise((e, n) => {
  const r = An(), i = (o) => {
    var c, f, y, w;
    if ((c = o.data) != null && c.isRazor && ((f = o.data) == null ? void 0 : f.type) === ut.RESPONSE__WEB_TO_CONTENT_SCRIPT && ((y = o.data) == null ? void 0 : y.messageId) === r) {
      window.removeEventListener("message", i);
      const { data: _ } = o;
      (w = _.response) != null && w.error ? n(_.response.error) : e(_.response.result);
    }
  };
  window.addEventListener("message", i), window.postMessage({
    isRazor: !0,
    line: hn.COMMON,
    type: ut.REQUEST__WEB_TO_CONTENT_SCRIPT,
    messageId: r,
    message: t
  });
}), sp = {
  request: ip
}, Lu = {
  request: "eip6963:requestProvider",
  announce: "eip6963:announceProvider"
}, bs = (t) => new Promise((e, n) => {
  const r = An(), i = (o) => {
    var c, f, y, w;
    if ((c = o.data) != null && c.isRazor && ((f = o.data) == null ? void 0 : f.type) === ut.RESPONSE__WEB_TO_CONTENT_SCRIPT && ((y = o.data) == null ? void 0 : y.messageId) === r) {
      window.removeEventListener("message", i);
      const { data: _ } = o;
      (w = _.response) != null && w.error ? n(_.response.error) : e(_.response.result);
    }
  };
  window.addEventListener("message", i), window.postMessage({
    isRazor: !0,
    line: hn.ETHEREUM,
    type: ut.REQUEST__WEB_TO_CONTENT_SCRIPT,
    messageId: r,
    message: t
  });
}), Xo = (t, e) => {
  const n = (r) => {
    var i, o, c, f, y, w, _, m, I;
    (i = r.data) != null && i.isRazor && ((o = r.data) == null ? void 0 : o.type) === t && ((c = r.data) == null ? void 0 : c.line) === "ETHEREUM" && (t === "accountsChanged" && Array.isArray((y = (f = r.data) == null ? void 0 : f.message) == null ? void 0 : y.result) && ((_ = (w = r.data) == null ? void 0 : w.message) == null ? void 0 : _.result.length) === 0 ? (async () => {
      try {
        const z = await bs({
          method: "eth_requestAccounts",
          params: {}
        });
        e(z);
      } catch {
        e([]);
      }
    })() : e((I = (m = r.data) == null ? void 0 : m.message) == null ? void 0 : I.result));
  };
  return window.addEventListener("message", n), window.razor.handlerInfos.push({
    line: "ETHEREUM",
    eventName: t,
    originHandler: e,
    handler: n
  }), n;
}, Zo = (t, e) => {
  if (e === void 0)
    window.removeEventListener(
      "message",
      t
    );
  else {
    const n = window.razor.handlerInfos.filter(
      (i) => i.line === "ETHEREUM" && i.eventName === t && i.originHandler === e
    ), r = window.razor.handlerInfos.filter(
      (i) => !(i.line === "ETHEREUM" && i.eventName === t && i.originHandler === e)
    );
    n.forEach((i) => {
      window.removeEventListener("message", i.handler);
    }), window.razor.handlerInfos = r;
  }
}, Es = {
  isMetaMask: !1,
  on: Xo,
  addListener: Xo,
  off: Zo,
  removeListener: Zo,
  request: bs,
  send: (t, e) => {
    const n = An();
    if (typeof t == "string")
      return new Promise((i, o) => {
        const c = (f) => {
          var y, w, _, m;
          if ((y = f.data) != null && y.isRazor && ((w = f.data) == null ? void 0 : w.type) === ut.RESPONSE__WEB_TO_CONTENT_SCRIPT && ((_ = f.data) == null ? void 0 : _.messageId) === n) {
            window.removeEventListener("message", c);
            const { data: I } = f;
            (m = I.response) != null && m.error ? o(I.response) : i({
              result: I.response.result,
              jsonrpc: "2.0",
              id: void 0
            });
          }
        };
        window.addEventListener("message", c), window.postMessage({
          isRazor: !0,
          line: hn.ETHEREUM,
          type: ut.REQUEST__WEB_TO_CONTENT_SCRIPT,
          messageId: n,
          message: {
            method: t,
            params: e
          }
        });
      });
    const r = (i) => {
      var o, c, f, y;
      if ((o = i.data) != null && o.isRazor && ((c = i.data) == null ? void 0 : c.type) === ut.RESPONSE__WEB_TO_CONTENT_SCRIPT && ((f = i.data) == null ? void 0 : f.messageId) === n) {
        window.removeEventListener("message", r);
        const { data: w } = i;
        typeof e == "function" && ((y = w.response) != null && y.error ? e(w.response.error, {
          id: t.id,
          jsonrpc: "2.0",
          method: t.method,
          error: w.response.error
        }) : e(null, {
          id: t.id,
          jsonrpc: "2.0",
          method: t.method,
          error: w.response.error,
          result: w.response.result
        }));
      }
    };
    window.addEventListener("message", r), window.postMessage({
      isRazor: !0,
      line: hn.ETHEREUM,
      type: ut.REQUEST__WEB_TO_CONTENT_SCRIPT,
      messageId: n,
      message: {
        method: t.method,
        params: t.params
      }
    });
  },
  sendAsync: (t, e) => {
    const n = An(), r = (i) => {
      var o, c, f, y;
      if ((o = i.data) != null && o.isRazor && ((c = i.data) == null ? void 0 : c.type) === ut.RESPONSE__WEB_TO_CONTENT_SCRIPT && ((f = i.data) == null ? void 0 : f.messageId) === n) {
        window.removeEventListener("message", r);
        const { data: w } = i;
        (y = w.response) != null && y.error ? e(w.response.error, {
          id: t.id,
          jsonrpc: "2.0",
          method: t.method,
          error: w.response.error
        }) : e(null, {
          id: t.id,
          jsonrpc: "2.0",
          method: t.method,
          error: w.response.error,
          result: w.response.result
        });
      }
    };
    window.addEventListener("message", r), window.postMessage({
      isRazor: !0,
      line: hn.ETHEREUM,
      type: ut.REQUEST__WEB_TO_CONTENT_SCRIPT,
      messageId: n,
      message: {
        method: t.method,
        params: t.params
      }
    });
  },
  enable: () => bs({
    method: "eth_requestAccounts",
    params: []
  })
}, op = An(), ea = () => {
  const e = Object.freeze({
    info: {
      uuid: op,
      name: nl,
      icon: Ps,
      rdns: rl
    },
    provider: Es
  });
  window.dispatchEvent(
    new CustomEvent(Lu.announce, {
      detail: e
    })
  );
}, ap = () => {
  window.addEventListener(Lu.request, () => {
    ea();
  }), ea();
}, cp = Symbol.for("@mysten/transaction");
function vs(t) {
  return !!t && typeof t == "object" && t[cp] === !0;
}
const ta = "sui:devnet", na = "sui:testnet", ra = "sui:mainnet";
var Mu = {}, ji = {};
ji.byteLength = lp;
ji.toByteArray = hp;
ji.fromByteArray = yp;
var Tt = [], ht = [], up = typeof Uint8Array < "u" ? Uint8Array : Array, ss = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (var Tn = 0, fp = ss.length; Tn < fp; ++Tn)
  Tt[Tn] = ss[Tn], ht[ss.charCodeAt(Tn)] = Tn;
ht[45] = 62;
ht[95] = 63;
function Hu(t) {
  var e = t.length;
  if (e % 4 > 0)
    throw new Error("Invalid string. Length must be a multiple of 4");
  var n = t.indexOf("=");
  n === -1 && (n = e);
  var r = n === e ? 0 : 4 - n % 4;
  return [n, r];
}
function lp(t) {
  var e = Hu(t), n = e[0], r = e[1];
  return (n + r) * 3 / 4 - r;
}
function dp(t, e, n) {
  return (e + n) * 3 / 4 - n;
}
function hp(t) {
  var e, n = Hu(t), r = n[0], i = n[1], o = new up(dp(t, r, i)), c = 0, f = i > 0 ? r - 4 : r, y;
  for (y = 0; y < f; y += 4)
    e = ht[t.charCodeAt(y)] << 18 | ht[t.charCodeAt(y + 1)] << 12 | ht[t.charCodeAt(y + 2)] << 6 | ht[t.charCodeAt(y + 3)], o[c++] = e >> 16 & 255, o[c++] = e >> 8 & 255, o[c++] = e & 255;
  return i === 2 && (e = ht[t.charCodeAt(y)] << 2 | ht[t.charCodeAt(y + 1)] >> 4, o[c++] = e & 255), i === 1 && (e = ht[t.charCodeAt(y)] << 10 | ht[t.charCodeAt(y + 1)] << 4 | ht[t.charCodeAt(y + 2)] >> 2, o[c++] = e >> 8 & 255, o[c++] = e & 255), o;
}
function pp(t) {
  return Tt[t >> 18 & 63] + Tt[t >> 12 & 63] + Tt[t >> 6 & 63] + Tt[t & 63];
}
function Ap(t, e, n) {
  for (var r, i = [], o = e; o < n; o += 3)
    r = (t[o] << 16 & 16711680) + (t[o + 1] << 8 & 65280) + (t[o + 2] & 255), i.push(pp(r));
  return i.join("");
}
function yp(t) {
  for (var e, n = t.length, r = n % 3, i = [], o = 16383, c = 0, f = n - r; c < f; c += o)
    i.push(Ap(t, c, c + o > f ? f : c + o));
  return r === 1 ? (e = t[n - 1], i.push(
    Tt[e >> 2] + Tt[e << 4 & 63] + "=="
  )) : r === 2 && (e = (t[n - 2] << 8) + t[n - 1], i.push(
    Tt[e >> 10] + Tt[e >> 4 & 63] + Tt[e << 2 & 63] + "="
  )), i.join("");
}
var po = {};
/*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */
po.read = function(t, e, n, r, i) {
  var o, c, f = i * 8 - r - 1, y = (1 << f) - 1, w = y >> 1, _ = -7, m = n ? i - 1 : 0, I = n ? -1 : 1, z = t[e + m];
  for (m += I, o = z & (1 << -_) - 1, z >>= -_, _ += f; _ > 0; o = o * 256 + t[e + m], m += I, _ -= 8)
    ;
  for (c = o & (1 << -_) - 1, o >>= -_, _ += r; _ > 0; c = c * 256 + t[e + m], m += I, _ -= 8)
    ;
  if (o === 0)
    o = 1 - w;
  else {
    if (o === y)
      return c ? NaN : (z ? -1 : 1) * (1 / 0);
    c = c + Math.pow(2, r), o = o - w;
  }
  return (z ? -1 : 1) * c * Math.pow(2, o - r);
};
po.write = function(t, e, n, r, i, o) {
  var c, f, y, w = o * 8 - i - 1, _ = (1 << w) - 1, m = _ >> 1, I = i === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0, z = r ? 0 : o - 1, k = r ? 1 : -1, N = e < 0 || e === 0 && 1 / e < 0 ? 1 : 0;
  for (e = Math.abs(e), isNaN(e) || e === 1 / 0 ? (f = isNaN(e) ? 1 : 0, c = _) : (c = Math.floor(Math.log(e) / Math.LN2), e * (y = Math.pow(2, -c)) < 1 && (c--, y *= 2), c + m >= 1 ? e += I / y : e += I * Math.pow(2, 1 - m), e * y >= 2 && (c++, y /= 2), c + m >= _ ? (f = 0, c = _) : c + m >= 1 ? (f = (e * y - 1) * Math.pow(2, i), c = c + m) : (f = e * Math.pow(2, m - 1) * Math.pow(2, i), c = 0)); i >= 8; t[n + z] = f & 255, z += k, f /= 256, i -= 8)
    ;
  for (c = c << i | f, w += i; w > 0; t[n + z] = c & 255, z += k, c /= 256, w -= 8)
    ;
  t[n + z - k] |= N * 128;
};
/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */
(function(t) {
  const e = ji, n = po, r = typeof Symbol == "function" && typeof Symbol.for == "function" ? Symbol.for("nodejs.util.inspect.custom") : null;
  t.Buffer = f, t.SlowBuffer = ve, t.INSPECT_MAX_BYTES = 50;
  const i = 2147483647;
  t.kMaxLength = i, f.TYPED_ARRAY_SUPPORT = o(), !f.TYPED_ARRAY_SUPPORT && typeof console < "u" && typeof console.error == "function" && console.error(
    "This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."
  );
  function o() {
    try {
      const h = new Uint8Array(1), a = { foo: function() {
        return 42;
      } };
      return Object.setPrototypeOf(a, Uint8Array.prototype), Object.setPrototypeOf(h, a), h.foo() === 42;
    } catch {
      return !1;
    }
  }
  Object.defineProperty(f.prototype, "parent", {
    enumerable: !0,
    get: function() {
      if (f.isBuffer(this))
        return this.buffer;
    }
  }), Object.defineProperty(f.prototype, "offset", {
    enumerable: !0,
    get: function() {
      if (f.isBuffer(this))
        return this.byteOffset;
    }
  });
  function c(h) {
    if (h > i)
      throw new RangeError('The value "' + h + '" is invalid for option "size"');
    const a = new Uint8Array(h);
    return Object.setPrototypeOf(a, f.prototype), a;
  }
  function f(h, a, u) {
    if (typeof h == "number") {
      if (typeof a == "string")
        throw new TypeError(
          'The "string" argument must be of type string. Received type number'
        );
      return m(h);
    }
    return y(h, a, u);
  }
  f.poolSize = 8192;
  function y(h, a, u) {
    if (typeof h == "string")
      return I(h, a);
    if (ArrayBuffer.isView(h))
      return k(h);
    if (h == null)
      throw new TypeError(
        "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof h
      );
    if (at(h, ArrayBuffer) || h && at(h.buffer, ArrayBuffer) || typeof SharedArrayBuffer < "u" && (at(h, SharedArrayBuffer) || h && at(h.buffer, SharedArrayBuffer)))
      return N(h, a, u);
    if (typeof h == "number")
      throw new TypeError(
        'The "value" argument must not be of type number. Received type number'
      );
    const g = h.valueOf && h.valueOf();
    if (g != null && g !== h)
      return f.from(g, a, u);
    const b = M(h);
    if (b)
      return b;
    if (typeof Symbol < "u" && Symbol.toPrimitive != null && typeof h[Symbol.toPrimitive] == "function")
      return f.from(h[Symbol.toPrimitive]("string"), a, u);
    throw new TypeError(
      "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof h
    );
  }
  f.from = function(h, a, u) {
    return y(h, a, u);
  }, Object.setPrototypeOf(f.prototype, Uint8Array.prototype), Object.setPrototypeOf(f, Uint8Array);
  function w(h) {
    if (typeof h != "number")
      throw new TypeError('"size" argument must be of type number');
    if (h < 0)
      throw new RangeError('The value "' + h + '" is invalid for option "size"');
  }
  function _(h, a, u) {
    return w(h), h <= 0 ? c(h) : a !== void 0 ? typeof u == "string" ? c(h).fill(a, u) : c(h).fill(a) : c(h);
  }
  f.alloc = function(h, a, u) {
    return _(h, a, u);
  };
  function m(h) {
    return w(h), c(h < 0 ? 0 : Z(h) | 0);
  }
  f.allocUnsafe = function(h) {
    return m(h);
  }, f.allocUnsafeSlow = function(h) {
    return m(h);
  };
  function I(h, a) {
    if ((typeof a != "string" || a === "") && (a = "utf8"), !f.isEncoding(a))
      throw new TypeError("Unknown encoding: " + a);
    const u = Q(h, a) | 0;
    let g = c(u);
    const b = g.write(h, a);
    return b !== u && (g = g.slice(0, b)), g;
  }
  function z(h) {
    const a = h.length < 0 ? 0 : Z(h.length) | 0, u = c(a);
    for (let g = 0; g < a; g += 1)
      u[g] = h[g] & 255;
    return u;
  }
  function k(h) {
    if (at(h, Uint8Array)) {
      const a = new Uint8Array(h);
      return N(a.buffer, a.byteOffset, a.byteLength);
    }
    return z(h);
  }
  function N(h, a, u) {
    if (a < 0 || h.byteLength < a)
      throw new RangeError('"offset" is outside of buffer bounds');
    if (h.byteLength < a + (u || 0))
      throw new RangeError('"length" is outside of buffer bounds');
    let g;
    return a === void 0 && u === void 0 ? g = new Uint8Array(h) : u === void 0 ? g = new Uint8Array(h, a) : g = new Uint8Array(h, a, u), Object.setPrototypeOf(g, f.prototype), g;
  }
  function M(h) {
    if (f.isBuffer(h)) {
      const a = Z(h.length) | 0, u = c(a);
      return u.length === 0 || h.copy(u, 0, 0, a), u;
    }
    if (h.length !== void 0)
      return typeof h.length != "number" || fn(h.length) ? c(0) : z(h);
    if (h.type === "Buffer" && Array.isArray(h.data))
      return z(h.data);
  }
  function Z(h) {
    if (h >= i)
      throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + i.toString(16) + " bytes");
    return h | 0;
  }
  function ve(h) {
    return +h != h && (h = 0), f.alloc(+h);
  }
  f.isBuffer = function(a) {
    return a != null && a._isBuffer === !0 && a !== f.prototype;
  }, f.compare = function(a, u) {
    if (at(a, Uint8Array) && (a = f.from(a, a.offset, a.byteLength)), at(u, Uint8Array) && (u = f.from(u, u.offset, u.byteLength)), !f.isBuffer(a) || !f.isBuffer(u))
      throw new TypeError(
        'The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array'
      );
    if (a === u)
      return 0;
    let g = a.length, b = u.length;
    for (let T = 0, U = Math.min(g, b); T < U; ++T)
      if (a[T] !== u[T]) {
        g = a[T], b = u[T];
        break;
      }
    return g < b ? -1 : b < g ? 1 : 0;
  }, f.isEncoding = function(a) {
    switch (String(a).toLowerCase()) {
      case "hex":
      case "utf8":
      case "utf-8":
      case "ascii":
      case "latin1":
      case "binary":
      case "base64":
      case "ucs2":
      case "ucs-2":
      case "utf16le":
      case "utf-16le":
        return !0;
      default:
        return !1;
    }
  }, f.concat = function(a, u) {
    if (!Array.isArray(a))
      throw new TypeError('"list" argument must be an Array of Buffers');
    if (a.length === 0)
      return f.alloc(0);
    let g;
    if (u === void 0)
      for (u = 0, g = 0; g < a.length; ++g)
        u += a[g].length;
    const b = f.allocUnsafe(u);
    let T = 0;
    for (g = 0; g < a.length; ++g) {
      let U = a[g];
      if (at(U, Uint8Array))
        T + U.length > b.length ? (f.isBuffer(U) || (U = f.from(U)), U.copy(b, T)) : Uint8Array.prototype.set.call(
          b,
          U,
          T
        );
      else if (f.isBuffer(U))
        U.copy(b, T);
      else
        throw new TypeError('"list" argument must be an Array of Buffers');
      T += U.length;
    }
    return b;
  };
  function Q(h, a) {
    if (f.isBuffer(h))
      return h.length;
    if (ArrayBuffer.isView(h) || at(h, ArrayBuffer))
      return h.byteLength;
    if (typeof h != "string")
      throw new TypeError(
        'The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof h
      );
    const u = h.length, g = arguments.length > 2 && arguments[2] === !0;
    if (!g && u === 0)
      return 0;
    let b = !1;
    for (; ; )
      switch (a) {
        case "ascii":
        case "latin1":
        case "binary":
          return u;
        case "utf8":
        case "utf-8":
          return xn(h).length;
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return u * 2;
        case "hex":
          return u >>> 1;
        case "base64":
          return cn(h).length;
        default:
          if (b)
            return g ? -1 : xn(h).length;
          a = ("" + a).toLowerCase(), b = !0;
      }
  }
  f.byteLength = Q;
  function ke(h, a, u) {
    let g = !1;
    if ((a === void 0 || a < 0) && (a = 0), a > this.length || ((u === void 0 || u > this.length) && (u = this.length), u <= 0) || (u >>>= 0, a >>>= 0, u <= a))
      return "";
    for (h || (h = "utf8"); ; )
      switch (h) {
        case "hex":
          return Gt(this, a, u);
        case "utf8":
        case "utf-8":
          return Qt(this, a, u);
        case "ascii":
          return qn(this, a, u);
        case "latin1":
        case "binary":
          return jt(this, a, u);
        case "base64":
          return qt(this, a, u);
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return br(this, a, u);
        default:
          if (g)
            throw new TypeError("Unknown encoding: " + h);
          h = (h + "").toLowerCase(), g = !0;
      }
  }
  f.prototype._isBuffer = !0;
  function Ce(h, a, u) {
    const g = h[a];
    h[a] = h[u], h[u] = g;
  }
  f.prototype.swap16 = function() {
    const a = this.length;
    if (a % 2 !== 0)
      throw new RangeError("Buffer size must be a multiple of 16-bits");
    for (let u = 0; u < a; u += 2)
      Ce(this, u, u + 1);
    return this;
  }, f.prototype.swap32 = function() {
    const a = this.length;
    if (a % 4 !== 0)
      throw new RangeError("Buffer size must be a multiple of 32-bits");
    for (let u = 0; u < a; u += 4)
      Ce(this, u, u + 3), Ce(this, u + 1, u + 2);
    return this;
  }, f.prototype.swap64 = function() {
    const a = this.length;
    if (a % 8 !== 0)
      throw new RangeError("Buffer size must be a multiple of 64-bits");
    for (let u = 0; u < a; u += 8)
      Ce(this, u, u + 7), Ce(this, u + 1, u + 6), Ce(this, u + 2, u + 5), Ce(this, u + 3, u + 4);
    return this;
  }, f.prototype.toString = function() {
    const a = this.length;
    return a === 0 ? "" : arguments.length === 0 ? Qt(this, 0, a) : ke.apply(this, arguments);
  }, f.prototype.toLocaleString = f.prototype.toString, f.prototype.equals = function(a) {
    if (!f.isBuffer(a))
      throw new TypeError("Argument must be a Buffer");
    return this === a ? !0 : f.compare(this, a) === 0;
  }, f.prototype.inspect = function() {
    let a = "";
    const u = t.INSPECT_MAX_BYTES;
    return a = this.toString("hex", 0, u).replace(/(.{2})/g, "$1 ").trim(), this.length > u && (a += " ... "), "<Buffer " + a + ">";
  }, r && (f.prototype[r] = f.prototype.inspect), f.prototype.compare = function(a, u, g, b, T) {
    if (at(a, Uint8Array) && (a = f.from(a, a.offset, a.byteLength)), !f.isBuffer(a))
      throw new TypeError(
        'The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof a
      );
    if (u === void 0 && (u = 0), g === void 0 && (g = a ? a.length : 0), b === void 0 && (b = 0), T === void 0 && (T = this.length), u < 0 || g > a.length || b < 0 || T > this.length)
      throw new RangeError("out of range index");
    if (b >= T && u >= g)
      return 0;
    if (b >= T)
      return -1;
    if (u >= g)
      return 1;
    if (u >>>= 0, g >>>= 0, b >>>= 0, T >>>= 0, this === a)
      return 0;
    let U = T - b, oe = g - u;
    const Se = Math.min(U, oe), Te = this.slice(b, T), Pe = a.slice(u, g);
    for (let _e = 0; _e < Se; ++_e)
      if (Te[_e] !== Pe[_e]) {
        U = Te[_e], oe = Pe[_e];
        break;
      }
    return U < oe ? -1 : oe < U ? 1 : 0;
  };
  function nt(h, a, u, g, b) {
    if (h.length === 0)
      return -1;
    if (typeof u == "string" ? (g = u, u = 0) : u > 2147483647 ? u = 2147483647 : u < -2147483648 && (u = -2147483648), u = +u, fn(u) && (u = b ? 0 : h.length - 1), u < 0 && (u = h.length + u), u >= h.length) {
      if (b)
        return -1;
      u = h.length - 1;
    } else if (u < 0)
      if (b)
        u = 0;
      else
        return -1;
    if (typeof a == "string" && (a = f.from(a, g)), f.isBuffer(a))
      return a.length === 0 ? -1 : It(h, a, u, g, b);
    if (typeof a == "number")
      return a = a & 255, typeof Uint8Array.prototype.indexOf == "function" ? b ? Uint8Array.prototype.indexOf.call(h, a, u) : Uint8Array.prototype.lastIndexOf.call(h, a, u) : It(h, [a], u, g, b);
    throw new TypeError("val must be string, number or Buffer");
  }
  function It(h, a, u, g, b) {
    let T = 1, U = h.length, oe = a.length;
    if (g !== void 0 && (g = String(g).toLowerCase(), g === "ucs2" || g === "ucs-2" || g === "utf16le" || g === "utf-16le")) {
      if (h.length < 2 || a.length < 2)
        return -1;
      T = 2, U /= 2, oe /= 2, u /= 2;
    }
    function Se(Pe, _e) {
      return T === 1 ? Pe[_e] : Pe.readUInt16BE(_e * T);
    }
    let Te;
    if (b) {
      let Pe = -1;
      for (Te = u; Te < U; Te++)
        if (Se(h, Te) === Se(a, Pe === -1 ? 0 : Te - Pe)) {
          if (Pe === -1 && (Pe = Te), Te - Pe + 1 === oe)
            return Pe * T;
        } else
          Pe !== -1 && (Te -= Te - Pe), Pe = -1;
    } else
      for (u + oe > U && (u = U - oe), Te = u; Te >= 0; Te--) {
        let Pe = !0;
        for (let _e = 0; _e < oe; _e++)
          if (Se(h, Te + _e) !== Se(a, _e)) {
            Pe = !1;
            break;
          }
        if (Pe)
          return Te;
      }
    return -1;
  }
  f.prototype.includes = function(a, u, g) {
    return this.indexOf(a, u, g) !== -1;
  }, f.prototype.indexOf = function(a, u, g) {
    return nt(this, a, u, g, !0);
  }, f.prototype.lastIndexOf = function(a, u, g) {
    return nt(this, a, u, g, !1);
  };
  function rt(h, a, u, g) {
    u = Number(u) || 0;
    const b = h.length - u;
    g ? (g = Number(g), g > b && (g = b)) : g = b;
    const T = a.length;
    g > T / 2 && (g = T / 2);
    let U;
    for (U = 0; U < g; ++U) {
      const oe = parseInt(a.substr(U * 2, 2), 16);
      if (fn(oe))
        return U;
      h[u + U] = oe;
    }
    return U;
  }
  function it(h, a, u, g) {
    return un(xn(a, h.length - u), h, u, g);
  }
  function mt(h, a, u, g) {
    return un(vr(a), h, u, g);
  }
  function bt(h, a, u, g) {
    return un(cn(a), h, u, g);
  }
  function Et(h, a, u, g) {
    return un(Ot(a, h.length - u), h, u, g);
  }
  f.prototype.write = function(a, u, g, b) {
    if (u === void 0)
      b = "utf8", g = this.length, u = 0;
    else if (g === void 0 && typeof u == "string")
      b = u, g = this.length, u = 0;
    else if (isFinite(u))
      u = u >>> 0, isFinite(g) ? (g = g >>> 0, b === void 0 && (b = "utf8")) : (b = g, g = void 0);
    else
      throw new Error(
        "Buffer.write(string, encoding, offset[, length]) is no longer supported"
      );
    const T = this.length - u;
    if ((g === void 0 || g > T) && (g = T), a.length > 0 && (g < 0 || u < 0) || u > this.length)
      throw new RangeError("Attempt to write outside buffer bounds");
    b || (b = "utf8");
    let U = !1;
    for (; ; )
      switch (b) {
        case "hex":
          return rt(this, a, u, g);
        case "utf8":
        case "utf-8":
          return it(this, a, u, g);
        case "ascii":
        case "latin1":
        case "binary":
          return mt(this, a, u, g);
        case "base64":
          return bt(this, a, u, g);
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return Et(this, a, u, g);
        default:
          if (U)
            throw new TypeError("Unknown encoding: " + b);
          b = ("" + b).toLowerCase(), U = !0;
      }
  }, f.prototype.toJSON = function() {
    return {
      type: "Buffer",
      data: Array.prototype.slice.call(this._arr || this, 0)
    };
  };
  function qt(h, a, u) {
    return a === 0 && u === h.length ? e.fromByteArray(h) : e.fromByteArray(h.slice(a, u));
  }
  function Qt(h, a, u) {
    u = Math.min(h.length, u);
    const g = [];
    let b = a;
    for (; b < u; ) {
      const T = h[b];
      let U = null, oe = T > 239 ? 4 : T > 223 ? 3 : T > 191 ? 2 : 1;
      if (b + oe <= u) {
        let Se, Te, Pe, _e;
        switch (oe) {
          case 1:
            T < 128 && (U = T);
            break;
          case 2:
            Se = h[b + 1], (Se & 192) === 128 && (_e = (T & 31) << 6 | Se & 63, _e > 127 && (U = _e));
            break;
          case 3:
            Se = h[b + 1], Te = h[b + 2], (Se & 192) === 128 && (Te & 192) === 128 && (_e = (T & 15) << 12 | (Se & 63) << 6 | Te & 63, _e > 2047 && (_e < 55296 || _e > 57343) && (U = _e));
            break;
          case 4:
            Se = h[b + 1], Te = h[b + 2], Pe = h[b + 3], (Se & 192) === 128 && (Te & 192) === 128 && (Pe & 192) === 128 && (_e = (T & 15) << 18 | (Se & 63) << 12 | (Te & 63) << 6 | Pe & 63, _e > 65535 && _e < 1114112 && (U = _e));
        }
      }
      U === null ? (U = 65533, oe = 1) : U > 65535 && (U -= 65536, g.push(U >>> 10 & 1023 | 55296), U = 56320 | U & 1023), g.push(U), b += oe;
    }
    return yt(g);
  }
  const Ut = 4096;
  function yt(h) {
    const a = h.length;
    if (a <= Ut)
      return String.fromCharCode.apply(String, h);
    let u = "", g = 0;
    for (; g < a; )
      u += String.fromCharCode.apply(
        String,
        h.slice(g, g += Ut)
      );
    return u;
  }
  function qn(h, a, u) {
    let g = "";
    u = Math.min(h.length, u);
    for (let b = a; b < u; ++b)
      g += String.fromCharCode(h[b] & 127);
    return g;
  }
  function jt(h, a, u) {
    let g = "";
    u = Math.min(h.length, u);
    for (let b = a; b < u; ++b)
      g += String.fromCharCode(h[b]);
    return g;
  }
  function Gt(h, a, u) {
    const g = h.length;
    (!a || a < 0) && (a = 0), (!u || u < 0 || u > g) && (u = g);
    let b = "";
    for (let T = a; T < u; ++T)
      b += _n[h[T]];
    return b;
  }
  function br(h, a, u) {
    const g = h.slice(a, u);
    let b = "";
    for (let T = 0; T < g.length - 1; T += 2)
      b += String.fromCharCode(g[T] + g[T + 1] * 256);
    return b;
  }
  f.prototype.slice = function(a, u) {
    const g = this.length;
    a = ~~a, u = u === void 0 ? g : ~~u, a < 0 ? (a += g, a < 0 && (a = 0)) : a > g && (a = g), u < 0 ? (u += g, u < 0 && (u = 0)) : u > g && (u = g), u < a && (u = a);
    const b = this.subarray(a, u);
    return Object.setPrototypeOf(b, f.prototype), b;
  };
  function Me(h, a, u) {
    if (h % 1 !== 0 || h < 0)
      throw new RangeError("offset is not uint");
    if (h + a > u)
      throw new RangeError("Trying to access beyond buffer length");
  }
  f.prototype.readUintLE = f.prototype.readUIntLE = function(a, u, g) {
    a = a >>> 0, u = u >>> 0, g || Me(a, u, this.length);
    let b = this[a], T = 1, U = 0;
    for (; ++U < u && (T *= 256); )
      b += this[a + U] * T;
    return b;
  }, f.prototype.readUintBE = f.prototype.readUIntBE = function(a, u, g) {
    a = a >>> 0, u = u >>> 0, g || Me(a, u, this.length);
    let b = this[a + --u], T = 1;
    for (; u > 0 && (T *= 256); )
      b += this[a + --u] * T;
    return b;
  }, f.prototype.readUint8 = f.prototype.readUInt8 = function(a, u) {
    return a = a >>> 0, u || Me(a, 1, this.length), this[a];
  }, f.prototype.readUint16LE = f.prototype.readUInt16LE = function(a, u) {
    return a = a >>> 0, u || Me(a, 2, this.length), this[a] | this[a + 1] << 8;
  }, f.prototype.readUint16BE = f.prototype.readUInt16BE = function(a, u) {
    return a = a >>> 0, u || Me(a, 2, this.length), this[a] << 8 | this[a + 1];
  }, f.prototype.readUint32LE = f.prototype.readUInt32LE = function(a, u) {
    return a = a >>> 0, u || Me(a, 4, this.length), (this[a] | this[a + 1] << 8 | this[a + 2] << 16) + this[a + 3] * 16777216;
  }, f.prototype.readUint32BE = f.prototype.readUInt32BE = function(a, u) {
    return a = a >>> 0, u || Me(a, 4, this.length), this[a] * 16777216 + (this[a + 1] << 16 | this[a + 2] << 8 | this[a + 3]);
  }, f.prototype.readBigUInt64LE = dt(function(a) {
    a = a >>> 0, Pt(a, "offset");
    const u = this[a], g = this[a + 7];
    (u === void 0 || g === void 0) && an(a, this.length - 8);
    const b = u + this[++a] * 2 ** 8 + this[++a] * 2 ** 16 + this[++a] * 2 ** 24, T = this[++a] + this[++a] * 2 ** 8 + this[++a] * 2 ** 16 + g * 2 ** 24;
    return BigInt(b) + (BigInt(T) << BigInt(32));
  }), f.prototype.readBigUInt64BE = dt(function(a) {
    a = a >>> 0, Pt(a, "offset");
    const u = this[a], g = this[a + 7];
    (u === void 0 || g === void 0) && an(a, this.length - 8);
    const b = u * 2 ** 24 + this[++a] * 2 ** 16 + this[++a] * 2 ** 8 + this[++a], T = this[++a] * 2 ** 24 + this[++a] * 2 ** 16 + this[++a] * 2 ** 8 + g;
    return (BigInt(b) << BigInt(32)) + BigInt(T);
  }), f.prototype.readIntLE = function(a, u, g) {
    a = a >>> 0, u = u >>> 0, g || Me(a, u, this.length);
    let b = this[a], T = 1, U = 0;
    for (; ++U < u && (T *= 256); )
      b += this[a + U] * T;
    return T *= 128, b >= T && (b -= Math.pow(2, 8 * u)), b;
  }, f.prototype.readIntBE = function(a, u, g) {
    a = a >>> 0, u = u >>> 0, g || Me(a, u, this.length);
    let b = u, T = 1, U = this[a + --b];
    for (; b > 0 && (T *= 256); )
      U += this[a + --b] * T;
    return T *= 128, U >= T && (U -= Math.pow(2, 8 * u)), U;
  }, f.prototype.readInt8 = function(a, u) {
    return a = a >>> 0, u || Me(a, 1, this.length), this[a] & 128 ? (255 - this[a] + 1) * -1 : this[a];
  }, f.prototype.readInt16LE = function(a, u) {
    a = a >>> 0, u || Me(a, 2, this.length);
    const g = this[a] | this[a + 1] << 8;
    return g & 32768 ? g | 4294901760 : g;
  }, f.prototype.readInt16BE = function(a, u) {
    a = a >>> 0, u || Me(a, 2, this.length);
    const g = this[a + 1] | this[a] << 8;
    return g & 32768 ? g | 4294901760 : g;
  }, f.prototype.readInt32LE = function(a, u) {
    return a = a >>> 0, u || Me(a, 4, this.length), this[a] | this[a + 1] << 8 | this[a + 2] << 16 | this[a + 3] << 24;
  }, f.prototype.readInt32BE = function(a, u) {
    return a = a >>> 0, u || Me(a, 4, this.length), this[a] << 24 | this[a + 1] << 16 | this[a + 2] << 8 | this[a + 3];
  }, f.prototype.readBigInt64LE = dt(function(a) {
    a = a >>> 0, Pt(a, "offset");
    const u = this[a], g = this[a + 7];
    (u === void 0 || g === void 0) && an(a, this.length - 8);
    const b = this[a + 4] + this[a + 5] * 2 ** 8 + this[a + 6] * 2 ** 16 + (g << 24);
    return (BigInt(b) << BigInt(32)) + BigInt(u + this[++a] * 2 ** 8 + this[++a] * 2 ** 16 + this[++a] * 2 ** 24);
  }), f.prototype.readBigInt64BE = dt(function(a) {
    a = a >>> 0, Pt(a, "offset");
    const u = this[a], g = this[a + 7];
    (u === void 0 || g === void 0) && an(a, this.length - 8);
    const b = (u << 24) + // Overflow
    this[++a] * 2 ** 16 + this[++a] * 2 ** 8 + this[++a];
    return (BigInt(b) << BigInt(32)) + BigInt(this[++a] * 2 ** 24 + this[++a] * 2 ** 16 + this[++a] * 2 ** 8 + g);
  }), f.prototype.readFloatLE = function(a, u) {
    return a = a >>> 0, u || Me(a, 4, this.length), n.read(this, a, !0, 23, 4);
  }, f.prototype.readFloatBE = function(a, u) {
    return a = a >>> 0, u || Me(a, 4, this.length), n.read(this, a, !1, 23, 4);
  }, f.prototype.readDoubleLE = function(a, u) {
    return a = a >>> 0, u || Me(a, 8, this.length), n.read(this, a, !0, 52, 8);
  }, f.prototype.readDoubleBE = function(a, u) {
    return a = a >>> 0, u || Me(a, 8, this.length), n.read(this, a, !1, 52, 8);
  };
  function Ge(h, a, u, g, b, T) {
    if (!f.isBuffer(h))
      throw new TypeError('"buffer" argument must be a Buffer instance');
    if (a > b || a < T)
      throw new RangeError('"value" argument is out of bounds');
    if (u + g > h.length)
      throw new RangeError("Index out of range");
  }
  f.prototype.writeUintLE = f.prototype.writeUIntLE = function(a, u, g, b) {
    if (a = +a, u = u >>> 0, g = g >>> 0, !b) {
      const oe = Math.pow(2, 8 * g) - 1;
      Ge(this, a, u, g, oe, 0);
    }
    let T = 1, U = 0;
    for (this[u] = a & 255; ++U < g && (T *= 256); )
      this[u + U] = a / T & 255;
    return u + g;
  }, f.prototype.writeUintBE = f.prototype.writeUIntBE = function(a, u, g, b) {
    if (a = +a, u = u >>> 0, g = g >>> 0, !b) {
      const oe = Math.pow(2, 8 * g) - 1;
      Ge(this, a, u, g, oe, 0);
    }
    let T = g - 1, U = 1;
    for (this[u + T] = a & 255; --T >= 0 && (U *= 256); )
      this[u + T] = a / U & 255;
    return u + g;
  }, f.prototype.writeUint8 = f.prototype.writeUInt8 = function(a, u, g) {
    return a = +a, u = u >>> 0, g || Ge(this, a, u, 1, 255, 0), this[u] = a & 255, u + 1;
  }, f.prototype.writeUint16LE = f.prototype.writeUInt16LE = function(a, u, g) {
    return a = +a, u = u >>> 0, g || Ge(this, a, u, 2, 65535, 0), this[u] = a & 255, this[u + 1] = a >>> 8, u + 2;
  }, f.prototype.writeUint16BE = f.prototype.writeUInt16BE = function(a, u, g) {
    return a = +a, u = u >>> 0, g || Ge(this, a, u, 2, 65535, 0), this[u] = a >>> 8, this[u + 1] = a & 255, u + 2;
  }, f.prototype.writeUint32LE = f.prototype.writeUInt32LE = function(a, u, g) {
    return a = +a, u = u >>> 0, g || Ge(this, a, u, 4, 4294967295, 0), this[u + 3] = a >>> 24, this[u + 2] = a >>> 16, this[u + 1] = a >>> 8, this[u] = a & 255, u + 4;
  }, f.prototype.writeUint32BE = f.prototype.writeUInt32BE = function(a, u, g) {
    return a = +a, u = u >>> 0, g || Ge(this, a, u, 4, 4294967295, 0), this[u] = a >>> 24, this[u + 1] = a >>> 16, this[u + 2] = a >>> 8, this[u + 3] = a & 255, u + 4;
  };
  function st(h, a, u, g, b) {
    on(a, g, b, h, u, 7);
    let T = Number(a & BigInt(4294967295));
    h[u++] = T, T = T >> 8, h[u++] = T, T = T >> 8, h[u++] = T, T = T >> 8, h[u++] = T;
    let U = Number(a >> BigInt(32) & BigInt(4294967295));
    return h[u++] = U, U = U >> 8, h[u++] = U, U = U >> 8, h[u++] = U, U = U >> 8, h[u++] = U, u;
  }
  function ot(h, a, u, g, b) {
    on(a, g, b, h, u, 7);
    let T = Number(a & BigInt(4294967295));
    h[u + 7] = T, T = T >> 8, h[u + 6] = T, T = T >> 8, h[u + 5] = T, T = T >> 8, h[u + 4] = T;
    let U = Number(a >> BigInt(32) & BigInt(4294967295));
    return h[u + 3] = U, U = U >> 8, h[u + 2] = U, U = U >> 8, h[u + 1] = U, U = U >> 8, h[u] = U, u + 8;
  }
  f.prototype.writeBigUInt64LE = dt(function(a, u = 0) {
    return st(this, a, u, BigInt(0), BigInt("0xffffffffffffffff"));
  }), f.prototype.writeBigUInt64BE = dt(function(a, u = 0) {
    return ot(this, a, u, BigInt(0), BigInt("0xffffffffffffffff"));
  }), f.prototype.writeIntLE = function(a, u, g, b) {
    if (a = +a, u = u >>> 0, !b) {
      const Se = Math.pow(2, 8 * g - 1);
      Ge(this, a, u, g, Se - 1, -Se);
    }
    let T = 0, U = 1, oe = 0;
    for (this[u] = a & 255; ++T < g && (U *= 256); )
      a < 0 && oe === 0 && this[u + T - 1] !== 0 && (oe = 1), this[u + T] = (a / U >> 0) - oe & 255;
    return u + g;
  }, f.prototype.writeIntBE = function(a, u, g, b) {
    if (a = +a, u = u >>> 0, !b) {
      const Se = Math.pow(2, 8 * g - 1);
      Ge(this, a, u, g, Se - 1, -Se);
    }
    let T = g - 1, U = 1, oe = 0;
    for (this[u + T] = a & 255; --T >= 0 && (U *= 256); )
      a < 0 && oe === 0 && this[u + T + 1] !== 0 && (oe = 1), this[u + T] = (a / U >> 0) - oe & 255;
    return u + g;
  }, f.prototype.writeInt8 = function(a, u, g) {
    return a = +a, u = u >>> 0, g || Ge(this, a, u, 1, 127, -128), a < 0 && (a = 255 + a + 1), this[u] = a & 255, u + 1;
  }, f.prototype.writeInt16LE = function(a, u, g) {
    return a = +a, u = u >>> 0, g || Ge(this, a, u, 2, 32767, -32768), this[u] = a & 255, this[u + 1] = a >>> 8, u + 2;
  }, f.prototype.writeInt16BE = function(a, u, g) {
    return a = +a, u = u >>> 0, g || Ge(this, a, u, 2, 32767, -32768), this[u] = a >>> 8, this[u + 1] = a & 255, u + 2;
  }, f.prototype.writeInt32LE = function(a, u, g) {
    return a = +a, u = u >>> 0, g || Ge(this, a, u, 4, 2147483647, -2147483648), this[u] = a & 255, this[u + 1] = a >>> 8, this[u + 2] = a >>> 16, this[u + 3] = a >>> 24, u + 4;
  }, f.prototype.writeInt32BE = function(a, u, g) {
    return a = +a, u = u >>> 0, g || Ge(this, a, u, 4, 2147483647, -2147483648), a < 0 && (a = 4294967295 + a + 1), this[u] = a >>> 24, this[u + 1] = a >>> 16, this[u + 2] = a >>> 8, this[u + 3] = a & 255, u + 4;
  }, f.prototype.writeBigInt64LE = dt(function(a, u = 0) {
    return st(this, a, u, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
  }), f.prototype.writeBigInt64BE = dt(function(a, u = 0) {
    return ot(this, a, u, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
  });
  function ye(h, a, u, g, b, T) {
    if (u + g > h.length)
      throw new RangeError("Index out of range");
    if (u < 0)
      throw new RangeError("Index out of range");
  }
  function et(h, a, u, g, b) {
    return a = +a, u = u >>> 0, b || ye(h, a, u, 4), n.write(h, a, u, g, 23, 4), u + 4;
  }
  f.prototype.writeFloatLE = function(a, u, g) {
    return et(this, a, u, !0, g);
  }, f.prototype.writeFloatBE = function(a, u, g) {
    return et(this, a, u, !1, g);
  };
  function Qn(h, a, u, g, b) {
    return a = +a, u = u >>> 0, b || ye(h, a, u, 8), n.write(h, a, u, g, 52, 8), u + 8;
  }
  f.prototype.writeDoubleLE = function(a, u, g) {
    return Qn(this, a, u, !0, g);
  }, f.prototype.writeDoubleBE = function(a, u, g) {
    return Qn(this, a, u, !1, g);
  }, f.prototype.copy = function(a, u, g, b) {
    if (!f.isBuffer(a))
      throw new TypeError("argument should be a Buffer");
    if (g || (g = 0), !b && b !== 0 && (b = this.length), u >= a.length && (u = a.length), u || (u = 0), b > 0 && b < g && (b = g), b === g || a.length === 0 || this.length === 0)
      return 0;
    if (u < 0)
      throw new RangeError("targetStart out of bounds");
    if (g < 0 || g >= this.length)
      throw new RangeError("Index out of range");
    if (b < 0)
      throw new RangeError("sourceEnd out of bounds");
    b > this.length && (b = this.length), a.length - u < b - g && (b = a.length - u + g);
    const T = b - g;
    return this === a && typeof Uint8Array.prototype.copyWithin == "function" ? this.copyWithin(u, g, b) : Uint8Array.prototype.set.call(
      a,
      this.subarray(g, b),
      u
    ), T;
  }, f.prototype.fill = function(a, u, g, b) {
    if (typeof a == "string") {
      if (typeof u == "string" ? (b = u, u = 0, g = this.length) : typeof g == "string" && (b = g, g = this.length), b !== void 0 && typeof b != "string")
        throw new TypeError("encoding must be a string");
      if (typeof b == "string" && !f.isEncoding(b))
        throw new TypeError("Unknown encoding: " + b);
      if (a.length === 1) {
        const U = a.charCodeAt(0);
        (b === "utf8" && U < 128 || b === "latin1") && (a = U);
      }
    } else
      typeof a == "number" ? a = a & 255 : typeof a == "boolean" && (a = Number(a));
    if (u < 0 || this.length < u || this.length < g)
      throw new RangeError("Out of range index");
    if (g <= u)
      return this;
    u = u >>> 0, g = g === void 0 ? this.length : g >>> 0, a || (a = 0);
    let T;
    if (typeof a == "number")
      for (T = u; T < g; ++T)
        this[T] = a;
    else {
      const U = f.isBuffer(a) ? a : f.from(a, b), oe = U.length;
      if (oe === 0)
        throw new TypeError('The value "' + a + '" is invalid for argument "value"');
      for (T = 0; T < g - u; ++T)
        this[T + u] = U[T % oe];
    }
    return this;
  };
  const Ct = {};
  function Wt(h, a, u) {
    Ct[h] = class extends u {
      constructor() {
        super(), Object.defineProperty(this, "message", {
          value: a.apply(this, arguments),
          writable: !0,
          configurable: !0
        }), this.name = `${this.name} [${h}]`, this.stack, delete this.name;
      }
      get code() {
        return h;
      }
      set code(b) {
        Object.defineProperty(this, "code", {
          configurable: !0,
          enumerable: !0,
          value: b,
          writable: !0
        });
      }
      toString() {
        return `${this.name} [${h}]: ${this.message}`;
      }
    };
  }
  Wt(
    "ERR_BUFFER_OUT_OF_BOUNDS",
    function(h) {
      return h ? `${h} is outside of buffer bounds` : "Attempt to access memory outside buffer bounds";
    },
    RangeError
  ), Wt(
    "ERR_INVALID_ARG_TYPE",
    function(h, a) {
      return `The "${h}" argument must be of type number. Received type ${typeof a}`;
    },
    TypeError
  ), Wt(
    "ERR_OUT_OF_RANGE",
    function(h, a, u) {
      let g = `The value of "${h}" is out of range.`, b = u;
      return Number.isInteger(u) && Math.abs(u) > 2 ** 32 ? b = sn(String(u)) : typeof u == "bigint" && (b = String(u), (u > BigInt(2) ** BigInt(32) || u < -(BigInt(2) ** BigInt(32))) && (b = sn(b)), b += "n"), g += ` It must be ${a}. Received ${b}`, g;
    },
    RangeError
  );
  function sn(h) {
    let a = "", u = h.length;
    const g = h[0] === "-" ? 1 : 0;
    for (; u >= g + 4; u -= 3)
      a = `_${h.slice(u - 3, u)}${a}`;
    return `${h.slice(0, u)}${a}`;
  }
  function Er(h, a, u) {
    Pt(a, "offset"), (h[a] === void 0 || h[a + u] === void 0) && an(a, h.length - (u + 1));
  }
  function on(h, a, u, g, b, T) {
    if (h > u || h < a) {
      const U = typeof a == "bigint" ? "n" : "";
      let oe;
      throw T > 3 ? a === 0 || a === BigInt(0) ? oe = `>= 0${U} and < 2${U} ** ${(T + 1) * 8}${U}` : oe = `>= -(2${U} ** ${(T + 1) * 8 - 1}${U}) and < 2 ** ${(T + 1) * 8 - 1}${U}` : oe = `>= ${a}${U} and <= ${u}${U}`, new Ct.ERR_OUT_OF_RANGE("value", oe, h);
    }
    Er(g, b, T);
  }
  function Pt(h, a) {
    if (typeof h != "number")
      throw new Ct.ERR_INVALID_ARG_TYPE(a, "number", h);
  }
  function an(h, a, u) {
    throw Math.floor(h) !== h ? (Pt(h, u), new Ct.ERR_OUT_OF_RANGE(u || "offset", "an integer", h)) : a < 0 ? new Ct.ERR_BUFFER_OUT_OF_BOUNDS() : new Ct.ERR_OUT_OF_RANGE(
      u || "offset",
      `>= ${u ? 1 : 0} and <= ${a}`,
      h
    );
  }
  const Gi = /[^+/0-9A-Za-z-_]/g;
  function Wi(h) {
    if (h = h.split("=")[0], h = h.trim().replace(Gi, ""), h.length < 2)
      return "";
    for (; h.length % 4 !== 0; )
      h = h + "=";
    return h;
  }
  function xn(h, a) {
    a = a || 1 / 0;
    let u;
    const g = h.length;
    let b = null;
    const T = [];
    for (let U = 0; U < g; ++U) {
      if (u = h.charCodeAt(U), u > 55295 && u < 57344) {
        if (!b) {
          if (u > 56319) {
            (a -= 3) > -1 && T.push(239, 191, 189);
            continue;
          } else if (U + 1 === g) {
            (a -= 3) > -1 && T.push(239, 191, 189);
            continue;
          }
          b = u;
          continue;
        }
        if (u < 56320) {
          (a -= 3) > -1 && T.push(239, 191, 189), b = u;
          continue;
        }
        u = (b - 55296 << 10 | u - 56320) + 65536;
      } else
        b && (a -= 3) > -1 && T.push(239, 191, 189);
      if (b = null, u < 128) {
        if ((a -= 1) < 0)
          break;
        T.push(u);
      } else if (u < 2048) {
        if ((a -= 2) < 0)
          break;
        T.push(
          u >> 6 | 192,
          u & 63 | 128
        );
      } else if (u < 65536) {
        if ((a -= 3) < 0)
          break;
        T.push(
          u >> 12 | 224,
          u >> 6 & 63 | 128,
          u & 63 | 128
        );
      } else if (u < 1114112) {
        if ((a -= 4) < 0)
          break;
        T.push(
          u >> 18 | 240,
          u >> 12 & 63 | 128,
          u >> 6 & 63 | 128,
          u & 63 | 128
        );
      } else
        throw new Error("Invalid code point");
    }
    return T;
  }
  function vr(h) {
    const a = [];
    for (let u = 0; u < h.length; ++u)
      a.push(h.charCodeAt(u) & 255);
    return a;
  }
  function Ot(h, a) {
    let u, g, b;
    const T = [];
    for (let U = 0; U < h.length && !((a -= 2) < 0); ++U)
      u = h.charCodeAt(U), g = u >> 8, b = u % 256, T.push(b), T.push(g);
    return T;
  }
  function cn(h) {
    return e.toByteArray(Wi(h));
  }
  function un(h, a, u, g) {
    let b;
    for (b = 0; b < g && !(b + u >= a.length || b >= h.length); ++b)
      a[b + u] = h[b];
    return b;
  }
  function at(h, a) {
    return h instanceof a || h != null && h.constructor != null && h.constructor.name != null && h.constructor.name === a.name;
  }
  function fn(h) {
    return h !== h;
  }
  const _n = function() {
    const h = "0123456789abcdef", a = new Array(256);
    for (let u = 0; u < 16; ++u) {
      const g = u * 16;
      for (let b = 0; b < 16; ++b)
        a[g + b] = h[u] + h[b];
    }
    return a;
  }();
  function dt(h) {
    return typeof BigInt > "u" ? mn : h;
  }
  function mn() {
    throw new Error("BigInt not supported");
  }
})(Mu);
class wp extends Error {
  constructor(n, r = {}, i = "BizError", o = -1) {
    super(n);
    Gn(this, "name");
    Gn(this, "code");
    Gn(this, "details");
    this.name = i, this.code = o, this.details = r;
  }
  toString() {
    return `${this.message} | (${this.name}:${this.code})`;
  }
}
class Ao extends wp {
  constructor(e = "User rejection", n) {
    super(
      e,
      n,
      Ao.name,
      -4005
      /* USER_REJECTION */
    );
  }
}
function gp(t) {
  return Array.from(t);
}
const xt = (t) => new Promise((e, n) => {
  const r = An(), i = (o) => {
    var c, f, y, w;
    if ((c = o.data) != null && c.isRazor && ((f = o.data) == null ? void 0 : f.type) === ut.RESPONSE__WEB_TO_CONTENT_SCRIPT && ((y = o.data) == null ? void 0 : y.messageId) === r) {
      window.removeEventListener("message", i);
      const { data: _ } = o;
      (w = _.response) != null && w.error ? n(_.response.error) : e(_.response.result);
    }
  };
  window.addEventListener("message", i), window.postMessage({
    isRazor: !0,
    line: hn.SUI,
    type: ut.REQUEST__WEB_TO_CONTENT_SCRIPT,
    messageId: r,
    message: t
  });
}), $u = async () => [(await xt({
  method: "sui_getAccount",
  params: void 0
})).address], qu = async () => (await xt({
  method: "sui_getAccount",
  params: void 0
})).publicKey, Qu = async () => await xt({
  method: "sui_getChain",
  params: void 0
}), ju = async (t = ["suggestTransactions", "viewAccount"]) => {
  try {
    return await xt({ method: "sui_connect", params: t }), !0;
  } catch {
    return !1;
  }
}, Gu = ju, xp = () => xt({
  method: "sui_disconnect",
  params: void 0
}), Wu = async (t = ["suggestTransactions", "viewAccount"]) => {
  try {
    const e = await xt({
      method: "sui_getPermissions",
      params: void 0
    });
    return t.every(
      (n) => e.includes(n)
    );
  } catch {
    return !1;
  }
}, _p = (t) => {
  if (!vs(t.transactionBlock))
    throw new Error(
      "Unexpect transaction format found. Ensure that you are using the `TransactionBlock` class."
    );
  return xt({
    method: "sui_signAndExecuteTransactionBlock",
    // @ts-ignore:next-line
    params: [
      {
        ...t,
        transactionBlockSerialized: t.transactionBlock.serialize(),
        // @ts-ignore
        transactionBlock: void 0
      }
    ]
  });
}, Ts = (t, e) => {
  const n = window.razor.handlerInfos.filter(
    (i) => i.line === "SUI" && i.eventName === t && i.originHandler === e
  ), r = window.razor.handlerInfos.filter(
    (i) => !(i.line === "SUI" && i.eventName === t && i.originHandler === e)
  );
  n.forEach((i) => {
    window.removeEventListener("message", i.handler);
  }), window.razor.handlerInfos = r;
}, ia = (t, e) => {
  const n = (r) => {
    var i, o, c, f, y, w, _;
    (i = r.data) != null && i.isRazor && ((o = r.data) == null ? void 0 : o.type) === t && ((c = r.data) == null ? void 0 : c.line) === "SUI" && (t === "accountChange" && !((y = (f = r.data) == null ? void 0 : f.message) != null && y.result) ? e("") : e((_ = (w = r.data) == null ? void 0 : w.message) == null ? void 0 : _.result));
  };
  return window.addEventListener("message", n), window.razor.handlerInfos.push({
    line: "SUI",
    eventName: t,
    originHandler: e,
    handler: n
  }), () => Ts(t, e);
};
var yi, wi, Lt, Mt, lr, gi, xi, _i, mi, bi, Ei, vi, Ku, Ti, Yu, Bi, Vu, Si, Ju;
class mp {
  constructor() {
    he(this, vi);
    he(this, Ti);
    he(this, Bi);
    he(this, Si);
    he(this, yi, "Razor Wallet");
    he(this, wi, "1.0.0");
    he(this, Lt, null);
    he(this, Mt, void 0);
    he(this, lr, void 0);
    Gn(this, "hasPermissions", Wu);
    he(this, gi, (e, n) => (te(this, Mt).on(e, n), () => te(this, Mt).off(e, n)));
    he(this, xi, async () => {
      if (!await Gu())
        throw new Ao();
      const { address: n, publicKey: r } = await kt(this, vi, Ku).call(this), o = await kt(this, Ti, Yu).call(this);
      return te(this, Lt) && te(this, Lt).address === n ? { accounts: this.accounts } : (lt(this, Lt, new Ii({
        address: n,
        publicKey: new Uint8Array(Mu.Buffer.from(r.substring(2), "hex")),
        chains: [o],
        features: [
          "standard:connect",
          "sui:signAndExecuteTransactionBlock",
          "sui:signTransactionBlock",
          "sui:signPersonalMessage"
          /* SUI__SIGN_PERSONAL_MESSAGE */
        ]
      })), te(this, Mt).emit("change", { accounts: this.accounts }), { accounts: this.accounts });
    });
    he(this, _i, async () => {
      lt(this, Lt, null), te(this, Mt).all.clear();
    });
    he(this, mi, async (e) => {
      if (!vs(e.transactionBlock))
        throw new Error(
          "Unexpect transaction format found. Ensure that you are using the `TransactionBlock` class."
        );
      return await xt({
        method: "sui_signAndExecuteTransactionBlock",
        params: [
          {
            ...e,
            transactionBlockSerialized: e.transactionBlock.serialize(),
            // @ts-ignore
            transactionBlock: void 0
          }
        ]
      });
    });
    he(this, bi, async (e) => {
      if (!vs(e.transactionBlock))
        throw new Error(
          "Unexpect transaction format found. Ensure that you are using the `TransactionBlock` class."
        );
      return await xt({
        method: "sui_signTransactionBlock",
        params: [
          {
            ...e,
            transactionBlockSerialized: e.transactionBlock.serialize(),
            // @ts-ignore
            transactionBlock: void 0
          }
        ]
      });
    });
    he(this, Ei, async (e) => {
      const n = gp(e.message);
      return await xt({
        method: "sui_signPersonalMessage",
        params: [
          {
            ...e,
            message: n
          }
        ]
      });
    });
    lt(this, Mt, oa()), lt(this, lr, new ya(
      er.DAPP,
      er.RAZOR_CONTENT,
      window.origin
    )), kt(this, Bi, Vu).call(this, te(this, lr));
  }
  get features() {
    return {
      "standard:connect": {
        version: "1.0.0",
        connect: te(this, xi)
      },
      "standard:disconnect": {
        version: "1.0.0",
        disconnect: te(this, _i)
      },
      "standard:events": {
        version: "1.0.0",
        on: te(this, gi)
      },
      "sui:signAndExecuteTransactionBlock": {
        version: "1.0.0",
        signAndExecuteTransactionBlock: te(this, mi)
      },
      "sui:signTransactionBlock": {
        version: "1.0.0",
        signTransactionBlock: te(this, bi)
      },
      "sui:signPersonalMessage": {
        version: "1.0.0",
        signPersonalMessage: te(this, Ei)
      }
    };
  }
  get version() {
    return te(this, wi);
  }
  get name() {
    return te(this, yi);
  }
  get icon() {
    return Ps;
  }
  get chains() {
    return [
      ta,
      na,
      ra
    ];
  }
  get accounts() {
    return te(this, Lt) ? [te(this, Lt)] : [];
  }
}
yi = new WeakMap(), wi = new WeakMap(), Lt = new WeakMap(), Mt = new WeakMap(), lr = new WeakMap(), gi = new WeakMap(), xi = new WeakMap(), _i = new WeakMap(), mi = new WeakMap(), bi = new WeakMap(), Ei = new WeakMap(), vi = new WeakSet(), Ku = async function() {
  const e = await $u(), n = await qu();
  return { address: e[0], publicKey: n };
}, Ti = new WeakSet(), Yu = async function() {
  const e = await Qu();
  return e === "M2 Devnet" ? ta : e === "M2 Testnet" ? na : ra;
}, Bi = new WeakSet(), Vu = function(e) {
  const n = [tr.NETWORK_SWITCH];
  return e.subscribe((r) => {
    var i;
    if (n.includes((i = r == null ? void 0 : r.payload) == null ? void 0 : i.id) && r.payload.id === tr.NETWORK_SWITCH)
      return kt(this, Si, Ju).call(this, r.payload);
  });
}, Si = new WeakSet(), Ju = function(e) {
  const { networkId: n } = e;
  n && te(this, Mt).emit("change", {
    chains: [`movement:${n}`]
  });
};
const sa = {
  connect: Gu,
  disconnect: xp,
  getAccounts: $u,
  getPublicKey: qu,
  getChain: Qu,
  hasPermissions: Wu,
  off: Ts,
  removeListener: Ts,
  on: ia,
  addListener: ia,
  request: xt,
  requestPermissions: ju,
  signAndExecuteTransactionBlock: _p
}, bp = "wallet", Ep = "1.2.5", vp = "module", Tp = {
  dev: "run-s build:inject dev:ext",
  "dev:ext": "vite --mode development",
  builddev: "run-s build:inject clean builddev:ext",
  "builddev:ext": "vite build --mode development",
  build: "run-s build:inject clean build:ext",
  "build:ext": "vite build",
  "build:inject": "vite build --config inject.config.ts",
  lint: "eslint . --ext ts,tsx --report-unused-disable-directives --max-warnings 0",
  format: 'prettier --write "**/*.{ts,tsx,md,css,scss}"',
  preview: "vite preview",
  clean: "rimraf dist/"
}, Bp = {
  "@crxjs/vite-plugin": "2.0.0-beta.23",
  "@emoji-mart/data": "^1.2.1",
  "@emotion/react": "^11.11.4",
  "@emotion/styled": "^11.11.5",
  "@ethereumjs/common": "2.6.5",
  "@ethereumjs/tx": "3.5.2",
  "@ethersproject/abi": "5.7.0",
  "@floating-ui/react": "^0.26.13",
  "@heroicons/react": "^2.1.3",
  "@hookform/resolvers": "^3.3.4",
  "@internationalized/number": "^3.5.2",
  "@ledgerhq/hw-app-eth": "^6.35.4",
  "@ledgerhq/hw-transport": "^6.30.3",
  "@ledgerhq/hw-transport-webhid": "^6.28.3",
  "@ledgerhq/hw-transport-webusb": "^6.28.3",
  "@metamask/eth-sig-util": "4.0.1",
  "@mui/icons-material": "^5.15.15",
  "@mui/material": "^5.15.15",
  "@mui/system": "^5.15.15",
  "@mysten/bcs": "^0.11.1",
  "@mysten/ledgerjs-hw-app-sui": "^0.3.1",
  "@mysten/sui.js": "0.52.0",
  "@mysten/wallet-standard": "^0.11.2",
  "@noble/hashes": "1.4.0",
  "@noble/secp256k1": "1.7.0",
  "@razorlabs/wallet-standard": "^0.2.4",
  "@tanstack/react-query": "5.49.2",
  "@types/js-yaml": "^4.0.9",
  "@wallet-standard/core": "^1.0.3",
  ahooks: "3.7.8",
  aptos: "^1.21.0",
  axios: "^1.6.7",
  "big.js": "^6.2.1",
  "bignumber.js": "^9.1.2",
  bip32: "^4.0.0",
  bip39: "^3.1.0",
  "class-variance-authority": "^0.7.0",
  classnames: "^2.5.1",
  "copy-to-clipboard": "^3.3.3",
  "create-hash": "^1.2.0",
  "create-hmac": "^1.1.7",
  "crypto-js": "^4.2.0",
  "date-fns": "^3.6.0",
  elliptic: "^6.5.5",
  "emoji-mart": "^5.6.0",
  "ethereumjs-util": "7.1.5",
  ethers: "6.11.1",
  "framer-motion": "^11.1.7",
  "immutability-helper": "^3.1.1",
  "is-mobile": "^4.0.0",
  joi: "^17.12.3",
  "js-yaml": "^4.1.0",
  lodash: "^4.17.21",
  mitt: "^3.0.1",
  process: "^0.11.10",
  "qrcode.react": "^3.1.0",
  react: "^18.2.0",
  "react-dnd": "^16.0.1",
  "react-dnd-html5-backend": "^16.0.1",
  "react-dom": "^18.2.0",
  "react-error-boundary": "^4.0.12",
  "react-helmet-async": "^2.0.4",
  "react-hook-form": "^7.50.1",
  "react-loading": "^2.0.3",
  "react-loading-skeleton": "^3.4.0",
  "react-router-dom": "^6.22.0",
  "react-tabs": "^6.0.2",
  "react-toastify": "9.1.3",
  recoil: "^0.7.7",
  rxjs: "^7.8.1",
  "string-to-color": "^2.2.2",
  swr: "^2.2.4",
  tweetnacl: "1.0.3",
  "use-debounce": "^10.0.0",
  uuid: "^9.0.1",
  web3: "1.7.3",
  "web3-core": "1.7.3",
  "web3-eth-contract": "1.7.3",
  "web3-utils": "1.7.3"
}, Sp = {
  "@types/big.js": "^6.2.2",
  "@types/chrome": "^0.0.267",
  "@types/create-hash": "^1.2.6",
  "@types/create-hmac": "^1.1.3",
  "@types/crypto-js": "^4.2.2",
  "@types/elliptic": "^6.4.18",
  "@types/lodash": "^4.14.202",
  "@types/react": "^18.2.74",
  "@types/react-dom": "^18.2.24",
  "@types/uuid": "^9.0.8",
  "@typescript-eslint/eslint-plugin": "^7.5.0",
  "@typescript-eslint/parser": "^7.5.0",
  "@vitejs/plugin-react": "^4.2.1",
  autoprefixer: "^10.4.17",
  buffer: "^6.0.3",
  eslint: "^8.57.0",
  "eslint-plugin-react-hooks": "^4.6.0",
  "eslint-plugin-react-refresh": "^0.4.5",
  "npm-run-all": "^4.1.5",
  postcss: "^8.4.35",
  prettier: "^3.2.5",
  rimraf: "^5.0.5",
  "safe-buffer": "^5.2.1",
  sass: "^1.74.1",
  tailwindcss: "^3.4.1",
  typescript: "^5.4.4",
  vite: "^5.2.8",
  "vite-plugin-node-polyfills": "^0.17.0",
  "vite-plugin-svgr": "^4.2.0",
  "vite-tsconfig-paths": "^4.3.1"
}, Ip = {
  name: bp,
  private: !0,
  version: Ep,
  type: vp,
  scripts: Tp,
  dependencies: Bp,
  devDependencies: Sp
}, Up = Ip.version;
window.razor = {
  version: Up,
  providers: { metamask: Es },
  handlerInfos: [],
  common: sp,
  ethereum: Es,
  aptos: Jo,
  sui: sa,
  isRazor: !0
}, window.razorWallet = sa, xo(new mp()), xo(new rp()), ap(), (async () => {
  var r;
  const t = await window.razor.ethereum.request({
    method: "eth_chainId",
    params: []
  });
  window.razor.ethereum.chainId = t, window.razor.ethereum.networkVersion = `${parseInt(t, 16)}`, window.razor.ethereum.on("chainChanged", (i) => {
    window.razor.ethereum.chainId = i, window.razor.ethereum.networkVersion = `${parseInt(i, 16)}`;
  });
  const e = new CustomEvent("razor_keystorechange", {
    cancelable: !0
  });
  window.addEventListener(
    "message",
    (i) => {
      var o, c;
      (o = i.data) != null && o.isRazor && ((c = i.data) == null ? void 0 : c.type) === "accountsChanged" && window.dispatchEvent(e);
    }
  );
  const n = await window.razor.common.request({
    method: "com_providers"
  });
  n.metamask && !((r = window.ethereum) != null && r.isMetaMask) && (window.razor.ethereum.isMetaMask = !0, window.ethereum = window.razor.providers.metamask), n.aptos && (window.aptos = Jo);
})();
